# 🚀 BUNNY TEAM — Public deploy guide

Ye app **ek Node server + ek encrypted data file** hai. Isliye hosting aisi chahiye jahan
**`var/` folder permanent rahe** (warna har redeploy par keys ud jayengi).

> ⚠️ Jo trycloudflare link maine diya hai wo **temporary** hai — us sandbox ke band hote hi mar jayega.
> Permanent public link ke liye neeche ke koi ek option se deploy karo (10–15 min).

---

## Option 1 — VPS (best, sabse sasta & control) ⭐

Koi bhi VPS (DigitalOcean / Contabo / Hetzner / AWS Lightsail), Ubuntu 22+:

```bash
# 1) server me node 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs git

# 2) project upload (zip/scp/git)
mkdir -p /opt/bunny && cd /opt/bunny
# bunny-team-deploy.zip ko yahan upload karke:
unzip bunny-team-deploy.zip && cd bunny-team

# 3) install + env
npm ci --omit=dev
cp .env.example .env
nano .env      # ADMIN_KEY, ADMIN_PATH, SESSION_SECRET, DATA_SECRET bharo
# secrets: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# 4) test
node src/index.js
```

### systemd (auto restart + boot par start)

```bash
sudo tee /etc/systemd/system/bunny.service >/dev/null <<'EOF'
[Unit]
Description=BUNNY TEAM
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/bunny/bunny-team
EnvironmentFile=/opt/bunny/bunny-team/.env
ExecStart=/usr/bin/node src/index.js
Restart=always
RestartSec=3
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

sudo chown -R www-data:www-data /opt/bunny/bunny-team
sudo systemctl daemon-reload
sudo systemctl enable --now bunny
sudo systemctl status bunny --no-pager
```

### HTTPS (Caddy — 2 line me free SSL)

```bash
sudo apt install -y caddy
sudo tee /etc/caddy/Caddyfile >/dev/null <<'EOF'
your-domain.com {
    reverse_proxy 127.0.0.1:3000
    encode gzip
}
EOF
sudo systemctl reload caddy
```

Domain ka A record VPS IP par point karo → `https://your-domain.com` live.
Console: `https://your-domain.com/<ADMIN_PATH>`.

**Backup (roz):**
```bash
0 3 * * * cp /opt/bunny/bunny-team/var/bunny-vault.enc /root/bunny-backup-$(date +\%F).enc
```

---

## Option 2 — Railway (volume ke saath, panel-based)

1. [railway.app](https://railway.app) → **New Project → Deploy from repo / Upload** (ya `railway up` CLI).
2. Service → **Variables** me `.env` ki saari values add karo (`ADMIN_KEY`, `ADMIN_PATH`, `SESSION_SECRET`, `DATA_SECRET`, `ALLOW_SYNTHETIC_FEED=true`).
3. Service → **Settings → Volumes** → *New Volume* → mount path: **`/app/var`** ← ye zaroori hai.
4. Deploy hone ke baad **Settings → Networking → Generate Domain** → public URL mil jayega.

---

## Option 3 — Fly.io (volume, free-ish)

```bash
fly launch --no-deploy        # fly.toml already included
fly volumes create bunny_data --size 1
fly secrets set ADMIN_KEY='RUP@ADHIKARY' ADMIN_PATH='/apna-secret-path' \
  SESSION_SECRET='...' DATA_SECRET='...' ALLOW_SYNTHETIC_FEED=true
fly deploy
```

`fly.toml` me mount already set hai: `source = "bunny_data" → /app/var`.

---

## Option 4 — Docker (kisi bhi VPS / NAS par)

```bash
docker build -t bunny-team .
docker run -d --name bunny --restart unless-stopped \
  --env-file .env -p 3000:3000 -v bunny-data:/app/var bunny-team
```

---

## ❌ Render free tier par mat karo

Render free web service ka disk **ephemeral** hota hai — har restart/redeploy par `var/` wipe.
Agar Render hi chahiye to **paid instance + Persistent Disk** lo, mount path `/app/var`.

---

## Deploy ke baad checklist

- [ ] `https://domain` par login screen khul raha hai
- [ ] `/bunny-console-9x7` (ya apna path) par console khulta hai, master key kaam kar rahi hai
- [ ] **Keys → Generate** se pehla key banao, app me login karo, prediction dikh raha hai
- [ ] `ADMIN_KEY` badal do (console → Security) kyunki `RUP@ADHIKARY` chat me likhi ja chuki hai
- [ ] `ADMIN_PATH` bhi apna private phrase rakho
- [ ] Console → **App tab** → `🔐 VAULT BACKUP` download karke safe rakho
- [ ] Console → **Overview** me feed mode dekho: `LIVE` chahiye to `FEED_PROXY` set karo (neeche)

## Live feed (SIM ke bajaye)

Datacenter IPs par `draw.ar-lottery01.com` 403 deta hai. Do options:

```env
# a) egress proxy
FEED_PROXY=https://api.allorigins.win/raw?url={url}

# b) apna relay (residential IP / chhota VPS se)
FEED_BASE=https://your-relay.com
```

Verify: console → Overview → per-timeframe mode `live` dikhna chahiye (app me `● LIVE` badge).
