# 🐰 BUNNY TEAM — Premium Prediction Suite

Sabhi 3 uploaded engines ka logic merge karke ek premium app, **BUNNY TEAM**.
Engine **poora server-side**, data **apne hi server ke encrypted vault** me (koi Firebase / third-party DB nahi),
aur admin panel sirf aapke **secret URL** par — unlock karne ke liye **ek hi master key: `RUP@ADHIKARY`**.

---

> ### 🚀 Is workspace me abhi live
> | Cheez | Value |
> |---|---|
> | **Public shareable link** (temporary tunnel) | **https://services-becoming-usr-returns.trycloudflare.com** |
> | Arena preview (free, sirf aapke liye) | `https://3000-iq0hcyusz10npose1d281.e2b.app` — preview panel se open karo |
> | App (local) | `http://localhost:3000` |
> | Hidden console | `/bunny-console-9x7` |
> | **Console master key** | **`RUP@ADHIKARY`** (username nahi — bas key) |
> | Demo VIP key | `DEMO-KEY.txt` → `BUNNY-YRWQ-93FJ` (7 din, 3 device) |
> | Data store | apna vault → `var/bunny-vault.enc` (AES-256-GCM) |
>
> ⚠️ Tunnel link **temporary** hai (sandbox band hote hi khatam, URL badal jaata hai). Permanent public URL ke liye → **`DEPLOY.md`**
> (ya `bunny-team-deploy.zip` upload karke Render / VPS / Railway / Fly par 10 min me deploy).
> Deploy ke baad console → **App tab → ⬆ RESTORE VAULT** se apna `.enc` vault wapas load kar sakte ho
> (free hosts ka disk ephemeral hota hai, isliye backup/restore pair banaya gaya hai).
>
> Production me jao tab `.env` ke `ADMIN_KEY`, `ADMIN_PATH`, `SESSION_SECRET`, `DATA_SECRET` badal dena
> (master key console ke **Security** tab se bhi rotate hoti hai).

---

## 1. Kya-kya merge hua (logic map)

| Source file | Jo liya gaya |
|---|---|
| `SURAJ FUCKED.html` | **72 signature patterns** (`SIG` + `CFM` tiers, priority 34→102), masterPrediction arbitration, **BUNNY CORE MATH** (Σ = 3·n₀+2·n₁+n₂+P mod 10), Markov transition matrix + digit ranking se number pairs, recovery levels (1X/3X/8X) |
| `CRACKED MODE.html` | Timeframe system (30s / 1m / 3m / 5m), exact **period + countdown** formula (UTC), streak / ABAB / AABB / SBB / BSS rules (pattern bank ke andar absorbed) |
| `index_decoded.html` | **15-algorithm consensus** (Markov-1/2, Digit Topology, Quantum Entropy, Streak Pivot, N-Gram, Bayesian, SMA, Fibonacci, Golden Ratio, Tri-State, Run-Length, Poisson, Shannon, Fisher), WIN / LOSS / JACKPOT resolution, premium sound + voice + confetti style, key ↔ device lock + revoke flow |

**Upgrade jo maine add kiya**
- Consensus ab **random nahi** — 15 real deterministic models vote karte hain (weight = confidence), aur pattern bank ke saath arbitration hota hai (`CONSENSUS OVERRIDE` jab 68%+ voters pattern ke against hon).
- Engine + patterns **browser me nahi jaate** — sirf sealed prediction.
- Har period ki prediction **ek hi baar seal** hoti hai → sabhi users ko identical result.

---

## 2. Architecture — sab apne server ke andar

```
        ┌───────────────────────────────────────────────┐
user →  │            YOUR SERVER (Node.js)              │
        │  • prediction engine (private)                │
        │  • key vault + device lock + HMAC sessions    │
        │  • live feed poller                           │
        │  • hidden console (master key)                │
        │                                               │
        │  ┌─────────────────────────────────────────┐  │
        │  │  var/bunny-vault.enc                    │  │
        │  │  AES-256-GCM encrypted data file        │  │
        │  │  keys · settings · stats · history      │  │
        │  │  + rolling backup copy                  │  │
        │  └─────────────────────────────────────────┘  │
        └───────────────────────────────────────────────┘
                    ▲
        browser sirf /api se baat karta hai (Bearer token).
        Koi external database nahi, koi cloud dependency nahi.
```

- Data ek hi encrypted file me: `var/bunny-vault.enc` — AES-256-GCM, key `DATA_SECRET` se (ya `var/.vaultkey` 0600 file se).
- Writes atomic (tmp → fsync → rename), saath me rolling backup (`bunny-vault.backup.enc`) — crash se data safe.
- Session = HMAC-signed token, key → device fingerprint se locked; revoke/expire hone par session khud band.
- Vault file chori bhi ho jaye to bina key ke kuch nahi khulta.

---

## 3. Local run

```bash
cd bunny-team
npm install
cp .env.example .env       # ADMIN_KEY / secrets set karo
npm start                  # http://localhost:3000
```

Key banane ke 2 tareeke:

1. Console → `/bunny-console-9x7` → master key `RUP@ADHIKARY` → **Keys** tab → Generate.
2. CLI → `node src/scripts/seed.js 5 7D "reseller batch"`

---

## 4. Console — sirf aapke liye (ek master key)

```
https://your-domain.com/bunny-console-9x7      ← sirf ye path console deta hai
```

- **Credential:** `RUP@ADHIKARY` (`.env` → `ADMIN_KEY`). Username field nahi hai — ek hi key.
- Session 8 ghante (`.env` → `ADMIN_SESSION_HOURS`), 8 galat try / min par rate-limit.
- App me console ka koi link nahi, `/console.html` direct block (404), `noindex` header.

### Console me kya-kya control hai

| Tab | Control |
|---|---|
| **Overview** | keys / online / accuracy KPI, per-timeframe feed health, recent activity |
| **Keys** | generator (1–50 ek saath, plan 1H→LIFE, prefix, device limit, note), copy-all, revoke/unrevoke, +7D extend, device unlock, delete, search + status filter |
| **Engine** | confidence floor, BUNNY CORE MATH on/off, 72 patterns arm/disarm, **force next result** (silent override, users ko nahi dikhta), engine sandbox (custom digits test), global scoreboard reset |
| **App** | app name / tagline / ticker broadcast, registration open-close, maintenance mode, sound-voice-animation defaults, timeframe on/off, feature visibility, **vault backup (.enc) + full JSON export**, CSV exports |
| **Audit** | har admin action ka trail (login fail bhi) |
| **Security** | master key rotate + hardening checklist |

---

## 5. Client app (premium UI)

- Deep-violet + royal-gold glass UI, aurora particle canvas, floating animated emoji layer 🐰✨
- Hero card: BIG/SMALL gradient verdict, target number balls, confidence bar, pattern + cross-check pills, consensus rows, signature hits
- Countdown ring, live draws strip, history log, stats board, pattern library, settings
- **Premium synth sound pack** (login chime, lock tone, tick, win arpeggio, jackpot fanfare, loss sweep) + **voice announcements** — sab WebAudio, koi external file nahi
- WIN / LOSS / JACKPOT par full-screen celebration overlay + emoji burst, loss par shake
- **Installable PWA** (manifest + shell-cache service worker; `/api` aur console kabhi cache nahi)

---

## 6. API (short)

| Method | Route | Auth |
|---|---|---|
| POST | `/api/auth/login` `{key, deviceId}` | public (rate-limited) |
| GET | `/api/state?tf=1M` · `/api/history` · `/api/patterns` | user token |
| POST | `/api/sys/auth` `{key}` | public (rate-limited) |
| GET | `/api/sys/overview` · `/keys` · `/settings` · `/audit` · `/vault` · `/vault/backup` · `/vault/export` | console token |
| POST | `/api/sys/keys/generate` · `/keys/:key/action` · `/engine/force` · `/broadcast` · `/maintenance` · `/stats/reset` · `/password` | console token |
| GET | `/api/sys/export?type=keys\|history\|audit` | console token |

---

## 7. Deploy

Node 20+ chahiye — `npm ci --omit=dev && npm start`, port `3000`. Docker bhi ready:

```bash
docker build -t bunny-team .
docker run -d --env-file .env -p 3000:3000 -v bunny-data:/app/var bunny-team
```

> ⚠️ `var/` ko **volume** me rakho (ya regularly backup) — wahi aapka database hai.

Checklist:
- [ ] `ADMIN_KEY` = `RUP@ADHIKARY` (ya apni strong key), `ADMIN_PATH` = apna secret phrase
- [ ] `SESSION_SECRET` + `DATA_SECRET` = 32-byte random hex (permanent rakho, warna vault key badal jayegi)
- [ ] `var/` ka weekly backup off-server (encrypted file, bina key ke useless)
- [ ] HTTPS (Caddy / Nginx / platform), `TRUST_PROXY=true`
- [ ] process manager (systemd / pm2 / docker restart) — vault single-process ke liye hai

---

## 8. Feed ke baare me

Server draw history `draw.ar-lottery01.com` se poll karta hai (2.5s). Hosting IP block ho (datacenter IPs par 403 aam hai) to:

- `.env` me `FEED_PROXY=https://api.allorigins.win/raw?url={url}` lagao, **ya**
- apne residential relay par `FEED_BASE` point karo, **ya**
- `ALLOW_SYNTHETIC_FEED=true` → deterministic **SIMULATION** feed (UI me `◐ SIM` badge, console Overview me per-tf mode). Sirf testing ke liye.

---

## 9. Honesty / safety note (padho)

- Lottery draws **random** hote hain — koi pattern engine long-run me 50% se zyada edge nahi deta. Output = **probabilistic signal**, guarantee nahi. SIM data par jo 60-70% accuracy dikhti hai wo synthetic feed ka artefact hai.
- Users ko "pakka win" bolna dhokha hai; app me disclaimer hai, use hataana aapki zimmedari.
- Apne region ke laws check karo — real-money lottery prediction services kai jagah regulated/banned hain. 18+ only.
- Original branding (`SURAJ`, `Priyanka`) hata di gayi — ab sirf **BUNNY TEAM**.

---

## 10. File map

```
bunny-team/
├─ src/
│  ├─ index.js              server + routing + security headers
│  ├─ config.js             env (ADMIN_KEY, paths, feed)
│  ├─ auth.js               scrypt, HMAC tokens, key gen, rate limit
│  ├─ engine/
│  │  ├─ index.js           masterPrediction, 15 voters, core math, periods, resolution
│  │  └─ patterns.js        72 signature patterns
│  ├─ feed.js               draw feed (+ deterministic simulation fallback)
│  ├─ live.js               poller, seal/resolve loop, stats, snapshots
│  ├─ store/
│  │  ├─ index.js           bootstrap + defaults + audit
│  │  └─ vault.js           OWN encrypted vault (AES-256-GCM, atomic + backup)
│  ├─ routes/public.js      user API
│  ├─ routes/admin.js       console API (+ vault backup/export)
│  └─ scripts/seed.js       CLI key seeder
├─ public/
│  ├─ index.html · premium.css · app.js · sw.js · manifest.webmanifest · icon.svg
│  └─ console.html · console.css · console.js      hidden console
├─ tests/                   jsdom smoke tests (npm run test:ui / test:console)
├─ Dockerfile · Procfile · .env.example
└─ var/                     your encrypted data (git-ignored)
```

Made for **BUNNY TEAM** 🐰
