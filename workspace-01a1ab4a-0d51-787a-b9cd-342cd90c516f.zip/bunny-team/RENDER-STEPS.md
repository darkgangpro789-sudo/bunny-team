# 🐰 BUNNY TEAM → Render deploy: STEP BY STEP (bilkul shuru se)

Har step ke saath **"kya dikhega"** bhi likha hai, taaki pata chale aap sahi raaste par ho.
Total time: **~12 minute**. Kuch bhi install karne ki zarurat nahi (browser hi kaafi hai).

---

## 🧾 Phase 0 — Pehle ye 4 cheezein ready rakho

| # | Cheez | Kahan se |
|---|---|---|
| 1 | `bunny-team-deploy.zip` | is workspace se download karo |
| 2 | GitHub account | github.com (free, 2 min) |
| 3 | Render account | render.com (ban gaya ✅) |
| 4 | Neeche wale 2 secret codes | copy karke notepad me rakh lo |

```
SESSION_SECRET = 06f316529da293b416a805398208984ecdb6dce457cf7f0b2460d5fdd6e62352
DATA_SECRET    = 1bf13c5f15b6638a6ed31ff12bb38c84256e20c9713f1e52c6a8a54287f15bbd
```

🔴 `DATA_SECRET` = vault ki chaabi. Ise **kabhi na badlo**, na kisi ko do. Iske bina backup nahi khulega.

---

## 📦 Phase 1 — ZIP extract karo (1 min)

1. `bunny-team-deploy.zip` par right click → **Extract All** (Windows) / double-click (Mac).
2. Ek folder milega jiske andar ye cheezein hongi:

```
bunny-team/
├── src/            ← engine + server
├── public/         ← app UI + console
├── tests/
├── package.json
├── package-lock.json
├── render.yaml
├── run.sh
├── README.md · DEPLOY.md · RENDER.md · RENDER-STEPS.md
└── .env.example · Dockerfile · Procfile
```

✅ Checkpoint: `package.json` aur `src` folder **folder ke andar hi** hone chahiye
(agar ek extra `bunny-team/bunny-team/src` jaisa nested ho jaye to andar wala folder upload karna).

---

## 🐙 Phase 2 — GitHub par code upload (4 min)

**2.1** Browser me `github.com` → login.

**2.2** Top-right **`+`** → **New repository**

**2.3** Form bharo:
| Field | Value |
|---|---|
| Repository name | `bunny-team` |
| Description | *(khaali chhod do)* |
| Visibility | **Private** ✓ |
| Initialize with README | **tick mat karo** (khaali repo chahiye) |

→ **Create repository**

**2.4** Ab jo page khulega usme **"uploading an existing file"** ka blue link hai (ya
`quick setup` box me) — us par click karo.

**2.5** Extracted folder kholo → **andar ka saara content select karo** (Ctrl+A) → GitHub ke
drag-drop box me **drag karo**.

⚠️ Sirf ye 3 cheezein **mat** daalo: `node_modules` folder, `var` folder, `.env` file.
(`.env.example` daalna hai, `.env` nahi.)

**2.6** Neeche **Commit changes** → **Commit changes** (green button).

✅ Checkpoint: repo page par file list dikhegi — `src`, `public`, `package.json`, `render.yaml` etc.
Branch name **`main`** hona chahiye (agar `master` hai to Render me baad me branch `master` select karna).

---

## 🚀 Phase 3 — Render par service banao (3 min)

### Option A — Blueprint se (sabse aasan, 4 click) ⭐

1. Render dashboard → **New +** → **Blueprint**
2. Repo list me **`bunny-team`** → **Connect**
3. Render `render.yaml` padh lega. 3 values maangega (`sync: false` wale):
   - `ADMIN_PATH` → `/rup-secret-9x7`
   - `ADMIN_KEY` → `RUP@ADHIKARY`
   - `VAULT_BOOTSTRAP_B64` → **khaali chhod do** (Enter/Create dabao)
4. **Apply** → deploy shuru.

### Option B — Manual Web Service (agar Blueprint na dikhe)

1. **New +** → **Web Service** → repo `bunny-team` → **Connect**
2. Ye fields exactly bharo:

| Field | Value |
|---|---|
| Name | `bunny-team` |
| Region | **Singapore** |
| Branch | `main` |
| Root Directory | *(khaali)* |
| Runtime | **Node** |
| Build Command | `npm ci --omit=dev` |
| Start Command | `node src/index.js` |
| Instance Type | **Free** |
| Health Check Path | `/healthz` |

3. **Create Web Service**.

✅ Checkpoint: **Logs** tab me build chalega (`Installing dependencies…`), phir ye banner aayega:

```
  ╔══════════════════════════════════════════════════════╗
  ║            🐰  B U N N Y   T E A M  🐰               ║
  ╚══════════════════════════════════════════════════════╝
   app        : http://0.0.0.0:10000
   console    : http://0.0.0.0:10000/rup-secret-9x7   (hidden)
   vault      : vault (AES-256-GCM, self-hosted)
```

Aur upar status **`Live`** (green) ho jayega.

---

## 🔐 Phase 4 — Environment variables (2 min)

Service page → left menu **Environment** → **Add Environment Variable** — ek-ek karke ye 8 daalo
(Option A/Blueprint use kiya to sirf pehle 3 chhut rahe honge):

| Key | Value |
|---|---|
| `NODE_VERSION` | `20` |
| `NODE_ENV` | `production` |
| `ADMIN_PATH` | `/rup-secret-9x7` |
| `ADMIN_KEY` | `RUP@ADHIKARY` |
| `SESSION_SECRET` | `06f31652…e62352` (Phase 0 wala) |
| `DATA_SECRET` | `1bf13c5f…f15bbd` (Phase 0 wala) |
| `ALLOW_SYNTHETIC_FEED` | `true` |
| `TRUST_PROXY` | `true` |

→ **Save Changes** → Render khud redeploy karega (~1 min).

---

## 🔗 Phase 5 — Link ready

Service page ke top par URL milega:

```
https://bunny-team-xxxx.onrender.com
```

Test karo:

| Kya kholna hai | URL |
|---|---|
| Customer app | `https://bunny-team-xxxx.onrender.com` |
| Aapka console | `https://bunny-team-xxxx.onrender.com/rup-secret-9x7` |
| Health check | `https://bunny-team-xxxx.onrender.com/healthz` → `{"ok":true,...}` |

⏳ **Pehla open 30–50 sec** le sakta hai (free instance so raha hota hai). Uske baad fast.

✅ Checkpoint: app me golden **BUNNY TEAM** login screen dikhni chahiye (bunny orb + "UNLOCK ENGINE").

---

## 🔑 Phase 6 — Pehla key banao aur test karo (2 min)

1. Console kholo → **MASTER KEY** field me `RUP@ADHIKARY` → **UNLOCK CONSOLE**
   ✅ Checkpoint: Overview dashboard + `● LIVE FEED`/`◐ SIM FEED` badge.
2. **Keys** tab → Quantity `1`, Plan `7D`, Max devices `2`, Note `demo` → **⚡ GENERATE KEYS**
   ✅ Checkpoint: neeche golden key chip dikhega, jaise `BT-XXXX-XXXX` (click = copy).
3. Naya tab → app URL → key paste → **UNLOCK ENGINE**
   ✅ Checkpoint: BIG/SMALL verdict, countdown ring, numbers, sounds.
4. Console → **Keys** tab me wahi key ka status **`IN USE`** + green dot (online) dikhega.

---

## 🛡️ Phase 7 — Apna karo (2 min, zaroori)

1. Console → **Security** tab → *Current master key* `RUP@ADHIKARY`, *New* me apni strong key →
   **🔐 UPDATE MASTER KEY** → dobara login.
2. `ADMIN_PATH` badalna hai to Render → Environment → value badlo (jaise `/rup-darwaza-42`) → Save.
   Purana path usi waqt band ho jayega.
3. Console → **App** tab → **⬆ VAULT BACKUP (.enc)** → file download → phone/Drive me rakho.

---

## 💾 Phase 8 — Free tier par data bachana (ek baar, 1 min)

Render **free** instance ka disk sleep/redeploy par reset ho jaata hai → keys ud sakti hain.
Iska fix app me built-in hai:

1. Console → **App** tab → **`⧉ BOOTSTRAP ENV`** dabao
   → clipboard me ~2 KB ka string aa jayega (keys + settings + master key).
2. Render → **Environment** → `VAULT_BOOTSTRAP_B64` → **paste** → **Save Changes**.
3. Ab har restart par data khud restore hoga ✅
4. **Naye keys banane ke baad** ye string dobara copy karke env me update kar dena
   (ya `.enc` backup ko **⬆ RESTORE VAULT** se upload kar dena).

💡 Jab customers aane lage → Render **Instance Type → Starter ($7/mo)** + **Disk 1GB** mount path
`/app/var` → permanent, phir bootstrap ki zarurat nahi.

---

## 🆘 Kuch atka? — ye table dekho

| Dikh raha hai | Matlab | Fix |
|---|---|---|
| Build fail: `npm ci` / `lockfile` | `package-lock.json` upload nahi hua | Build Command ko `npm install --omit=dev` karo |
| Build ok, status `Live` nahi / `502` | Start command galat | Start Command exactly `node src/index.js` |
| `Cannot find module 'express'` | deps install nahi hue | Build Command `npm install --omit=dev` |
| Console par `404 Not Found` | `ADMIN_PATH` mismatch | Env value ke aage `/` ke saath exactly same daalo |
| App me "❌ Invalid access key" | key galat/expired | Console → Keys me status dekho, copy button use karo |
| "🔒 locked to 2 devices" | device limit | Console → Keys → **unlock** |
| App `◐ SIM` dikhata hai | datacenter IP block | Env me `FEED_PROXY=https://api.allorigins.win/raw?url={url}` |
| Restart ke baad keys gayab | free disk reset | Phase 8 karo |
| Sab kuch blank/white | JS error | Browser console (F12) ka error bhej do |

---

## ✅ Final checklist

- [ ] `https://bunny-team-xxxx.onrender.com` → login screen
- [ ] `/rup-secret-9x7` → console, master key kaam kar rahi
- [ ] Keys → Generate → app me login → prediction dikh raha
- [ ] Master key rotate ho gayi
- [ ] `.enc` backup download ho gaya
- [ ] `VAULT_BOOTSTRAP_B64` set (free tier)

Sab tick? 🎉 Bas ho gaya — link customers ko de sakte ho.
Kuch bhi atke to Render ke **Logs** ka last 15 line paste kar dena, main turant bata dunga.
