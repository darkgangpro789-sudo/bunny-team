# 🐰 Render par BUNNY TEAM — step by step (free)

Aapke paas Render account ban gaya. Ab 3 hisse hain: **code upload → Render service → env vars**.

---

## STEP 1 — Code GitHub par daalo (5 min)

Render zip upload nahi karta, **git repo** chahiye. GitHub account free hai.

**Aasan tareeka (bina terminal):**
1. `bunny-team-deploy.zip` download karo aur apne laptop me **extract** karo.
2. github.com → **New repository** → name: `bunny-team` → **Private** ✓ → Create.
3. Repo page par **"uploading an existing file"** link kholo.
4. Extracted folder ke **andar** ke saare files/folders drag-drop karo
   (`src`, `public`, `tests`, `package.json`, `package-lock.json`, `.env.example`, `Dockerfile`, `render.yaml`, `run.sh`, `README.md`, `DEPLOY.md`, `RENDER.md`).
   ⚠️ `node_modules`, `var`, `.env` mat upload karo.
5. **Commit changes** dabao.

---

## STEP 2 — Render par service banao (3 min)

1. dashboard.render.com → **New +** → **Web Service**
2. **Connect** GitHub → `bunny-team` repo → **Connect**
3. Settings exactly ye rakho:

| Field | Value |
|---|---|
| Name | `bunny-team` |
| Region | **Singapore** (India ke sabse paas) |
| Branch | `main` |
| Root Directory | *(blank)* |
| Runtime | **Node** |
| Build Command | `npm ci --omit=dev` |
| Start Command | `node src/index.js` |
| Instance Type | **Free** |
| Health Check Path | `/healthz` |

4. **Create Web Service** → build chalega (~2 min).

---

## STEP 3 — Environment variables (yehi sabse important)

Service → **Environment** → **Add Environment Variable** (ek-ek karke):

```
NODE_VERSION              = 20
NODE_ENV                  = production
ADMIN_PATH                = /rup-secret-9x7        ← apna private phrase
ADMIN_KEY                 = RUP@ADHIKARY
SESSION_SECRET            = <A value>
DATA_SECRET               = <B value>
ALLOW_SYNTHETIC_FEED      = true
TRUST_PROXY               = true
VAULT_BOOTSTRAP_B64       = (abhi khaali chhodo, STEP 6 me)
```

> ⚠️ `DATA_SECRET` **kabhi na badlo** — vault isi key se encrypt hota hai. Badla to purana backup nahi khulega.

**Save** → service auto redeploy karegi.

---

## STEP 4 — Link ready

Upar `https://bunny-team-xxxx.onrender.com` milega:

| | |
|---|---|
| App | `https://bunny-team-xxxx.onrender.com` |
| Console | `https://bunny-team-xxxx.onrender.com/rup-secret-9x7` |
| Master key | `RUP@ADHIKARY` |

⚠️ Free instance **15 min idle** ke baad so jaata hai — pehla open 30–50s slow hoga. Uske baad normal speed.

---

## STEP 5 — Pehli baar setup

1. Console kholo → master key se login.
2. **Security** tab → master key rotate kar lo (accept karo purani `RUP@ADHIKARY`).
3. **Keys** tab → 1 demo key banao → app me login karke test karo.
4. **App** tab → `🔐 VAULT BACKUP (.enc)` download karke apne phone/laptop me safe rakho.

---

## STEP 6 — Free tier par data safe rakhna (important)

Render **free** instance ka disk **redeploy/sleep par reset** ho jaata hai → keys ud sakti hain.
Iske liye maine app me **cold-boot restore** daala hai:

1. Console → **App** tab → **`⧉ BOOTSTRAP ENV (free hosts)`** dabao
   (vault ka gzip+base64 string clipboard me copy ho jayega, ~30–55 KB).
2. Render → **Environment** → `VAULT_BOOTSTRAP_B64` me paste karo → **Save**.
3. Ab har boot par app khud hi keys restore kar lega — data safe. ✅
4. Jab bhi naye keys banao, ye string dobara copy karke env me update kar dena
   (ya `RESTORE VAULT` se `.enc` file manually upload karo).

**Permanent solution (recommended jab customers aayenge):**
Render → Settings → **Instance Type → Starter ($7/mo)** → **Disks → Add Disk**
→ Name `bunny-data`, Mount Path **`/app/var`**, Size 1GB → Save.
Ab vault permanently disk par rahega, bootstrap ki zarurat nahi.
(Ya ₹300–400/mo ka VPS — `DEPLOY.md` me poora systemd + Caddy setup hai.)

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Build fail: `npm ci` error | `package-lock.json` upload hua hai na? Nahi to Build Command `npm install --omit=dev` karo |
| 502 / "Application failed to respond" | Start Command `node src/index.js` hai na? Logs me dekho |
| Login "Invalid access key" | Console → Keys me key `UNUSED` hai? Spelling/caps check karo |
| Console 404 | `ADMIN_PATH` ki value exact waise hi URL me daalo (leading `/` ke saath) |
| App kholte hi keys gayab | STEP 6 karo (bootstrap env / disk) |
| Feed `◐ SIM` dikh raha | Datacenter IP block — `FEED_PROXY` env add karo |
