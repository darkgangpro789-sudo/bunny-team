/* ═══════════════════════════════════════════════════════════════
   BUNNY TEAM — client (engine stays on the server)
   ═══════════════════════════════════════════════════════════════ */

/* ───────── tiny storage bridge (works even in sandboxed frames) ───────── */
const mem = new Map();
const store = {
  get(k, d = null) {
    try { const v = localStorage.getItem(k); return v === null ? (mem.has(k) ? mem.get(k) : d) : v; }
    catch { return mem.has(k) ? mem.get(k) : d; }
  },
  set(k, v) { mem.set(k, v); try { localStorage.setItem(k, v); } catch { /* ignore */ } },
  del(k) { mem.delete(k); try { localStorage.removeItem(k); } catch { /* ignore */ } }
};

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const el = (tag, cls, html) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html !== undefined) n.innerHTML = html;
  return n;
};

/* ══════════════════════ AUDIO — premium synth pack ══════════════════════ */
class SoundEngine {
  constructor() {
    this.ctx = null;
    this.on = store.get('bt_sound', '1') === '1';
    this.voice = store.get('bt_voice', '1') === '1';
  }
  ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }
  tone({ f = 440, to = null, type = 'sine', at = 0, dur = 0.2, gain = 0.16, filter = null }) {
    const ctx = this.ensure();
    if (!ctx) return;
    const t0 = ctx.currentTime + at;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f, t0);
    if (to) osc.frequency.exponentialRampToValueAtTime(Math.max(20, to), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    let node = g;
    if (filter) {
      const bq = ctx.createBiquadFilter();
      bq.type = 'lowpass';
      bq.frequency.setValueAtTime(filter, t0);
      g.connect(bq);
      node = bq;
    }
    osc.connect(g);
    node.connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.03);
  }
  shimmer({ at = 0, dur = 0.55, gain = 0.07 }) {
    const ctx = this.ensure();
    if (!ctx) return;
    const len = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 2.2;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const bq = ctx.createBiquadFilter();
    bq.type = 'bandpass';
    bq.frequency.value = 5200;
    bq.Q.value = 0.9;
    const g = ctx.createGain();
    g.gain.value = gain;
    src.connect(bq).connect(g).connect(ctx.destination);
    src.start(ctx.currentTime + at);
  }
  play(name) {
    if (!this.on) return;
    const ctx = this.ensure();
    if (!ctx) return;
    switch (name) {
      case 'tap':
        this.tone({ f: 1180, to: 900, type: 'triangle', dur: 0.06, gain: 0.05 });
        break;
      case 'login':
        [523.25, 659.25, 783.99, 1046.5].forEach((f, i) =>
          this.tone({ f, type: 'sine', at: i * 0.085, dur: 0.34, gain: 0.13 }));
        this.shimmer({ at: 0.24, dur: 0.7 });
        break;
      case 'lock':
        this.tone({ f: 220, to: 440, type: 'sine', at: 0, dur: 0.22, gain: 0.12 });
        this.tone({ f: 660, type: 'triangle', at: 0.18, dur: 0.16, gain: 0.1 });
        this.tone({ f: 990, type: 'sine', at: 0.3, dur: 0.2, gain: 0.08 });
        break;
      case 'win':
        [659.25, 880, 1108.73, 1318.51].forEach((f, i) =>
          this.tone({ f, type: 'triangle', at: i * 0.075, dur: 0.4, gain: 0.14 }));
        this.shimmer({ at: 0.1, dur: 0.8, gain: 0.09 });
        break;
      case 'jackpot':
        [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98].forEach((f, i) =>
          this.tone({ f, type: 'square', at: i * 0.075, dur: 0.34, gain: 0.1 }));
        [1046.5, 1318.51, 1567.98].forEach((f, i) =>
          this.tone({ f, type: 'sine', at: 0.5 + i * 0.09, dur: 0.5, gain: 0.13 }));
        this.shimmer({ at: 0.45, dur: 1.4, gain: 0.12 });
        break;
      case 'loss':
        this.tone({ f: 320, to: 90, type: 'sawtooth', dur: 0.55, gain: 0.11, filter: 900 });
        this.tone({ f: 180, to: 60, type: 'sine', at: 0.12, dur: 0.6, gain: 0.1 });
        break;
      case 'tick':
        this.tone({ f: 1320, type: 'sine', dur: 0.05, gain: 0.04 });
        break;
      case 'error':
        this.tone({ f: 240, to: 150, type: 'sawtooth', dur: 0.24, gain: 0.1 });
        break;
      default:
        break;
    }
  }
  say(text) {
    if (!this.on || !this.voice || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-IN';
      u.rate = 1.02;
      u.pitch = 1.06;
      u.volume = 0.95;
      window.speechSynthesis.speak(u);
    } catch { /* ignore */ }
  }
}
const SFX = new SoundEngine();

/* ══════════════════════ ambient aurora + emoji layer ══════════════════════ */
(function aurora() {
  const c = $('#aurora');
  const ctx = c.getContext('2d');
  let w = 0, h = 0, parts = [];
  const resize = () => {
    w = c.width = window.innerWidth;
    h = c.height = window.innerHeight;
    parts = Array.from({ length: 42 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: 0.6 + Math.random() * 2.1,
      vy: -(0.12 + Math.random() * 0.5),
      vx: (Math.random() - 0.5) * 0.22,
      a: 0.14 + Math.random() * 0.4,
      hue: Math.random() > 0.55 ? 42 : 268
    }));
  };
  resize();
  window.addEventListener('resize', resize);
  const draw = () => {
    ctx.clearRect(0, 0, w, h);
    for (const p of parts) {
      p.x += p.vx; p.y += p.vy;
      if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
      if (p.x < -10) p.x = w + 10;
      if (p.x > w + 10) p.x = -10;
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 6);
      const col = p.hue === 42 ? '255,199,90' : '170,125,255';
      g.addColorStop(0, `rgba(${col},${p.a})`);
      g.addColorStop(1, `rgba(${col},0)`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * 6, 0, Math.PI * 2);
      ctx.fill();
    }
    requestAnimationFrame(draw);
  };
  draw();
})();

const EMOJIS = {
  float: ['🐰', '✨', '🥕', '💎', '🌟', '🎯', '🍀', '⚡', '👑'],
  win: ['🎉', '🥳', '💰', '🚀', '🏆', '💸', '🤑', '🎊', '🌟', '💯', '🍾', '🥂'],
  loss: ['💔', '😢', '📉', '⚠️', '🫠', '🥲', '🌧️', '🔻'],
  jackpot: ['💎', '👑', '🐉', '🦄', '🎰', '🌌', '🔮', '🪙', '🏆', '⚡', '🪩']
};
function spawnFloatEmoji() {
  const layer = $('#emojiLayer');
  if (!layer || document.hidden) return;
  const n = el('div', 'float-emoji');
  n.textContent = EMOJIS.float[Math.floor(Math.random() * EMOJIS.float.length)];
  n.style.left = 6 + Math.random() * 88 + '%';
  n.style.bottom = '-10px';
  n.style.fontSize = 12 + Math.random() * 16 + 'px';
  n.style.animationDuration = 5 + Math.random() * 4 + 's';
  layer.appendChild(n);
  setTimeout(() => n.remove(), 9500);
}
function burstEmojis(kind = 'win', count = 18) {
  const layer = $('#emojiLayer');
  if (!layer) return;
  const pool = EMOJIS[kind] || EMOJIS.win;
  for (let i = 0; i < count; i++) {
    const n = el('div', 'float-emoji');
    n.textContent = pool[Math.floor(Math.random() * pool.length)];
    n.style.left = 8 + Math.random() * 84 + '%';
    n.style.bottom = 12 + Math.random() * 26 + '%';
    n.style.fontSize = 16 + Math.random() * 22 + 'px';
    n.style.animationDuration = 1.6 + Math.random() * 1.8 + 's';
    layer.appendChild(n);
    setTimeout(() => n.remove(), 3600);
  }
}
let floatTimer = null;
function startFloatEmojis(animations = true) {
  if (floatTimer) clearInterval(floatTimer);
  if (!animations) return;
  floatTimer = setInterval(spawnFloatEmoji, 1500);
  for (let i = 0; i < 3; i++) setTimeout(spawnFloatEmoji, i * 400);
}

/* ══════════════════════ API ══════════════════════ */
let token = store.get('bt_token', '');
let deviceId = store.get('bt_device', '');
if (!deviceId) {
  deviceId = 'DEV-' + Math.random().toString(36).slice(2, 11).toUpperCase();
  store.set('bt_device', deviceId);
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {})
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    cache: 'no-store'
  });
  let json = {};
  try { json = await res.json(); } catch { /* ignore */ }
  if (!res.ok) {
    const err = new Error(json.message || 'Request failed');
    err.code = json.code || res.status;
    err.status = res.status;
    throw err;
  }
  return json;
}

/* ══════════════════════ toasts ══════════════════════ */
function toast(msg, kind = '') {
  const root = $('#toastRoot');
  const t = el('div', 'toast ' + kind, msg);
  root.appendChild(t);
  setTimeout(() => {
    t.style.transition = 'opacity .3s, transform .3s';
    t.style.opacity = '0';
    t.style.transform = 'translateY(-10px)';
    setTimeout(() => t.remove(), 320);
  }, 2900);
}

/* ══════════════════════ app state ══════════════════════ */
const App = {
  page: 'home',
  tf: store.get('bt_tf', '1M'),
  state: null,
  lastPredPeriod: null,
  lastResolved: store.get('bt_lastResolved', ''),
  countdownLocal: 0,
  fetchedAt: 0,
  animations: store.get('bt_anim', '1') === '1',
  patternsLoaded: false,
  patterns: []
};

/* ══════════════════════ rendering helpers ══════════════════════ */
const ballClass = (n) => (n >= 5 ? 'ball big' : 'ball small');
const fmtTime = (ts) => {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

function ringSVG() {
  return `<div class="ring-wrap">
    <svg viewBox="0 0 70 70">
      <defs>
        <linearGradient id="gradRing" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#a678ff"/><stop offset="60%" stop-color="#ffd76e"/><stop offset="100%" stop-color="#fff3cc"/>
        </linearGradient>
      </defs>
      <circle class="ring-track" cx="35" cy="35" r="30" fill="none" stroke-width="5"/>
      <circle class="ring-fill" id="ringFill" cx="35" cy="35" r="30" fill="none" stroke-width="5"
        stroke-dasharray="188.5" stroke-dashoffset="0"/>
    </svg>
    <span class="ring-time" id="ringTime">--</span>
  </div>`;
}

function renderHome() {
  const s = App.state;
  const view = $('#view');
  const p = s.prediction;
  const tf = s.tf;

  view.innerHTML = `
    <section class="card hero">
      <div class="hero-head">
        <div class="hero-period"><span>TARGET PERIOD</span>#${(s.period || '').slice(-6)}</div>
        ${ringSVG()}
      </div>
      <div class="hero-body">
        <div class="pred-sub">ENGINE VERDICT · ${tf.label.toUpperCase()}</div>
        <div class="pred-size ${p && p.size === 'SMALL' ? 'small' : ''}" id="predSize">${p ? (p.size === 'BIG' ? 'BIG' : 'SMALL') : 'SYNC'}</div>
        <div class="ball-row" id="predBalls">
          ${p ? `
            <div class="ball ${p.size === 'BIG' ? 'big' : 'small'}">${p.favNum}</div>
            <span class="ball-sep">+</span>
            <div class="ball ${p.oppNum >= 5 ? 'big' : 'small'}">${p.oppNum}</div>
          ` : '<span class="ball-sep">waiting for feed…</span>'}
        </div>
        <div class="metrics">
          <div class="metric gold"><b>${p ? p.confidence + '%' : '--'}</b><small>SIGNAL</small></div>
          <div class="metric mint"><b>${p && p.level ? p.level.multiplier : '1X'}</b><small>LEVEL</small></div>
          <div class="metric violet"><b>${p ? (p.matchCount || 0) : 0}</b><small>MATCHES</small></div>
        </div>
        <div class="conf-bar">
          <div class="conf-top"><span>CONFIDENCE</span><span>${p ? p.confidence + ' / 99' : '—'}</span></div>
          <div class="conf-track"><div class="conf-fill" id="confFill"></div></div>
        </div>
        <div class="pattern-pill">
          ${p ? `
            <span class="pill gold">${(p.patternName || 'SIGNATURE').replace(/[<>]/g, '')}</span>
            <span class="pill ${(p.crossCheck || '').includes('AGREE') ? 'mint' : p.crossCheck === 'CONFLICT' ? 'gold' : 'dim'}">${gradeLabel(p.crossCheck)}</span>
            ${p.votes ? `<span class="pill">VOTES ${p.votes.big}B / ${p.votes.small}S</span>` : ''}
            <span class="pill dim">LOCKED ${fmtTime(p.lockedAt)}</span>
          ` : '<span class="pill dim">AWAITING SEAL</span>'}
        </div>
        <div class="scan-anim"></div>
      </div>
    </section>

    <section class="card">
      <div class="card-title"><span>LIVE DRAWS</span><span class="right">LAST ${Math.min(12, s.results.length)}</span></div>
      <div class="strip" id="strip">
        ${s.results.slice(0, 12).map((r, i) => `
          <div class="mini ${r.size}" style="animation-delay:${i * 25}ms">
            <div class="n">${r.number}</div>
            <div class="s" style="color:${r.size === 'BIG' ? '#ffd76e' : '#61d6ff'}">${r.size === 'BIG' ? 'BIG' : 'SMALL'}</div>
            <div class="p">${r.outcome ? `<span class="${r.outcome === 'LOSS' ? 'miss' : 'hit'}">${r.outcome === 'JACKPOT' ? '♦' : r.outcome === 'WIN' ? '✓' : '✕'}</span>` : '·'}</div>
          </div>`).join('') || '<div class="empty">No draws yet</div>'}
      </div>
    </section>

    ${p && p.votes ? `
    <section class="card">
      <div class="card-title"><span>CONSENSUS ENGINE</span><span class="right">${p.votes.share}% SHARE</span></div>
      <div class="vote-row"><span class="vn">BIG signals</span><span class="vote-meta">${p.votes.big} voters</span><span class="vs BIG">BIG</span></div>
      <div class="vote-row"><span class="vn">SMALL signals</span><span class="vote-meta">${p.votes.small} voters</span><span class="vs SMALL">SMALL</span></div>
      ${(p.votes.list || []).slice(0, 8).map((v) => `
        <div class="vote-row"><span class="vn">${v.name}</span><span class="vote-meta">${v.conf}%</span><span class="vs ${v.size}">${v.size}</span></div>
      `).join('')}
    </section>` : ''}

    ${p && p.matches && p.matches.length ? `
    <section class="card">
      <div class="card-title"><span>SIGNATURE HITS</span><span class="right">${p.matches.length} ACTIVE</span></div>
      ${p.matches.map((m) => `
        <div class="vote-row">
          <span class="vn">${m.name}</span>
          <span class="vote-meta">PRI ${m.pri} · ${m.conf}%</span>
          <span class="vs ${m.size}">${m.size}</span>
        </div>`).join('')}
    </section>` : ''}
  `;

  // animate confidence bar + ring
  requestAnimationFrame(() => {
    const f = $('#confFill');
    if (f && p) f.style.width = p.confidence + '%';
    paintRing();
  });
}

const gradeLabel = (g) =>
  g === 'TRIPLE AGREE' ? '💎 TRIPLE AGREE'
  : g === 'AGREE' ? '✓ DUAL AGREE'
  : g === 'CONFLICT' ? '⚔ SPLIT SIGNAL'
  : '· SINGLE';

function paintRing() {
  const s = App.state;
  if (!s) return;
  const total = s.tf.seconds;
  const left = Math.max(0, Math.min(total, App.countdownLocal));
  const C = 188.5;
  const fill = $('#ringFill');
  const time = $('#ringTime');
  if (fill) {
    fill.style.strokeDasharray = C;
    fill.style.strokeDashoffset = C * (1 - left / total);
    fill.classList.toggle('danger', left <= 5);
  }
  if (time) {
    const m = Math.floor(left / 60);
    const sec = left % 60;
    time.textContent = (m > 0 ? m + ':' : '') + String(sec).padStart(2, '0');
    time.classList.toggle('danger', left <= 5);
  }
}

function renderHistory() {
  const view = $('#view');
  view.innerHTML = `
    <div class="section-label">Tactical log</div>
    <div id="histList"><div class="loader"><i></i><i></i><i></i></div></div>
    <div class="section-label">Session scoreboard</div>
    <div class="stat-grid" id="histStats"></div>
  `;
  loadHistory();
}

async function loadHistory() {
  try {
    const { items, stats } = await api(`/history?tf=${App.tf}&limit=60`);
    const list = $('#histList');
    if (!list) return;
    list.innerHTML = items.length
      ? items.map((h, i) => `
        <div class="hist-item ${h.outcome === 'LOSS' ? 'loss' : h.outcome === 'JACKPOT' ? 'jackpot' : 'win'}" style="animation-delay:${Math.min(i * 22, 400)}ms">
          <div class="hist-num ball ${h.number >= 5 ? 'big' : 'small'}">${h.number}</div>
          <div class="hist-main">
            <div class="p">#${h.period.slice(-6)} · ${h.size}</div>
            <div class="d">PRED ${h.predSize || '—'} · ${h.pattern || 'engine'} ${h.confidence ? '· ' + h.confidence + '%' : ''}</div>
          </div>
          <span class="hist-tag tag-${h.outcome}">${h.outcome === 'JACKPOT' ? '💎 JACKPOT' : h.outcome === 'WIN' ? '✓ WIN' : '✕ LOSS'}</span>
        </div>`).join('')
      : `<div class="empty"><span class="e">📜</span>No resolved draws in your session yet.</div>`;

    const st = $('#histStats');
    if (st) {
      st.innerHTML = `
        <div class="stat win"><div class="e">🏆</div><b>${stats.wins}</b><small>WINS</small></div>
        <div class="stat loss"><div class="e">💔</div><b>${stats.losses}</b><small>LOSSES</small></div>
        <div class="stat jackpot"><div class="e">💎</div><b>${stats.jackpots}</b><small>JACKPOTS</small></div>
        <div class="stat acc"><div class="e">🎯</div><b>${stats.accuracy}%</b><small>ACCURACY</small></div>`;
    }
  } catch (e) {
    const list = $('#histList');
    if (list) list.innerHTML = `<div class="empty"><span class="e">⚠️</span>${e.message}</div>`;
  }
}

function renderStats() {
  const s = App.state;
  const st = s.stats || {};
  const view = $('#view');
  const total = (st.wins || 0) + (st.losses || 0);
  view.innerHTML = `
    <div class="section-label">Global engine performance</div>
    <div class="stat-grid">
      <div class="stat win"><div class="e">🏆</div><b>${st.wins || 0}</b><small>TOTAL WINS</small></div>
      <div class="stat loss"><div class="e">💔</div><b>${st.losses || 0}</b><small>TOTAL LOSSES</small></div>
      <div class="stat jackpot"><div class="e">💎</div><b>${st.jackpots || 0}</b><small>JACKPOTS</small></div>
      <div class="stat acc"><div class="e">🎯</div><b>${st.accuracy || 0}%</b><small>ACCURACY</small></div>
    </div>
    <div class="section-label">Current streak</div>
    <section class="card">
      <div class="card-title"><span>${st.streakType === 'LOSS' ? 'RECOVERY' : 'MOMENTUM'}</span><span class="right">${total} SETTLED</span></div>
      <div class="metrics">
        <div class="metric ${st.streakType === 'LOSS' ? '' : 'mint'}"><b>${st.streak || 0}</b><small>${st.streakType === 'NONE' ? 'NO STREAK' : st.streakType + ' STREAK'}</small></div>
        <div class="metric gold"><b>${s.prediction && s.prediction.level ? s.prediction.level.current : 1}</b><small>RECOVERY LEVEL</small></div>
        <div class="metric violet"><b>${s.prediction ? s.prediction.confidence : '--'}%</b><small>NEXT SIGNAL</small></div>
      </div>
      <div class="scan-anim"></div>
    </section>
    <div class="section-label">Engine roster</div>
    <section class="card">
      <div class="card-title"><span>ACTIVE MODULES</span><span class="right">SERVER-SIDE</span></div>
      <div class="vote-row"><span class="vn">🐉 Signature bank</span><span class="vote-meta">72 patterns</span><span class="vs BIG">ARMED</span></div>
      <div class="vote-row"><span class="vn">🧠 Consensus voters</span><span class="vote-meta">15 models</span><span class="vs SMALL">ARMED</span></div>
      <div class="vote-row"><span class="vn">🐰 Bunny core math</span><span class="vote-meta">Σ + period</span><span class="vs BIG">ARMED</span></div>
      <div class="vote-row"><span class="vn">📈 Markov trend</span><span class="vote-meta">fallback</span><span class="vs SMALL">ARMED</span></div>
    </section>
  `;
}

async function renderPatterns() {
  const view = $('#view');
  view.innerHTML = `
    <div class="section-label">Signature bank</div>
    <section class="card">
      <div class="card-title"><span>PATTERN LIBRARY</span><span class="right" id="patCount">…</span></div>
      <div id="patList"><div class="loader"><i></i><i></i><i></i></div></div>
    </section>`;
  try {
    if (!App.patternsLoaded) {
      const { patterns, count } = await api('/patterns');
      App.patterns = patterns;
      App.patternsLoaded = true;
      const c = $('#patCount');
      if (c) c.textContent = count + ' SIGNATURES';
    }
    const list = $('#patList');
    if (list) {
      list.innerHTML = App.patterns.map((p) => `
        <div class="pat-row">
          <div><div class="nm">${p.name}</div><div class="id">${p.id} · PRI ${p.priority}</div></div>
          <span class="pat-tier ${p.tier}">${p.tier === 'SIG' ? 'SIGNAL' : 'CONFIRM'}</span>
        </div>`).join('');
    }
  } catch (e) {
    const list = $('#patList');
    if (list) list.innerHTML = `<div class="empty"><span class="e">⚠️</span>${e.message}</div>`;
  }
}

function renderSettings() {
  const s = App.state;
  const view = $('#view');
  const anim = store.get('bt_anim', '1') === '1';
  view.innerHTML = `
    <div class="section-label">Experience</div>
    <section class="card">
      <div class="set-row">
        <div><div class="t">🔊 Premium sound pack</div><div class="s">Chimes, lock tones, win fanfare</div></div>
        <div class="switch ${SFX.on ? 'on' : ''}" id="swSound"></div>
      </div>
      <div class="set-row">
        <div><div class="t">🗣️ Voice announcement</div><div class="s">Spoken win / loss / jackpot calls</div></div>
        <div class="switch ${SFX.voice ? 'on' : ''}" id="swVoice"></div>
      </div>
      <div class="set-row">
        <div><div class="t">✨ Animated emojis</div><div class="s">Floating bunny energy layer</div></div>
        <div class="switch ${anim ? 'on' : ''}" id="swAnim"></div>
      </div>
    </section>

    <div class="section-label">Account</div>
    <section class="card">
      <div class="set-row"><div><div class="t">🔑 Access key</div><div class="s">${store.get('bt_keyMask', '••••••')}</div></div><span class="pill mint">VIP</span></div>
      <div class="set-row"><div><div class="t">📡 Feed status</div><div class="s">${s.feed.health} · ${new Date(s.feed.at || Date.now()).toLocaleTimeString()}</div></div><span class="pill ${s.feed.health === 'LIVE' ? 'mint' : 'gold'}">${s.feed.health}</span></div>
      <div class="set-row"><div><div class="t">🖥️ Device</div><div class="s">${deviceId}</div></div><span class="pill dim">LOCKED</span></div>
      <div class="set-row">
        <div><div class="t">⏻ Sign out</div><div class="s">Clears this device session</div></div>
        <button class="icon-btn" id="btnLogout2" style="width:auto;padding:0 14px;height:32px;font-size:10px;letter-spacing:1px;font-weight:800">EXIT</button>
      </div>
    </section>

    <div class="section-label">About</div>
    <section class="card">
      <div class="card-title"><span>BUNNY TEAM</span><span class="right">v3.0 · CLOUD</span></div>
      <p style="font-size:10.5px;line-height:1.75;color:var(--muted);margin:0;letter-spacing:.3px">
        Predictions are generated, sealed and stored on the secure server — never in this browser.
        Engine outputs are probabilistic signals, not guarantees. Play responsibly, 18+ only.
      </p>
    </section>
  `;

  $('#swSound').onclick = (e) => {
    SFX.on = !SFX.on;
    store.set('bt_sound', SFX.on ? '1' : '0');
    e.currentTarget.classList.toggle('on', SFX.on);
    syncSoundBtn();
    if (SFX.on) SFX.play('tap');
  };
  $('#swVoice').onclick = (e) => {
    SFX.voice = !SFX.voice;
    store.set('bt_voice', SFX.voice ? '1' : '0');
    e.currentTarget.classList.toggle('on', SFX.voice);
    if (SFX.voice) SFX.say('Voice enabled');
  };
  $('#swAnim').onclick = (e) => {
    const next = store.get('bt_anim', '1') !== '1';
    store.set('bt_anim', next ? '1' : '0');
    App.animations = next;
    e.currentTarget.classList.toggle('on', next);
    startFloatEmojis(next);
  };
  $('#btnLogout2').onclick = logout;
}

/* ══════════════════════ page router ══════════════════════ */
function go(page) {
  App.page = page;
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.page === page));
  const view = $('#view');
  view.style.animation = 'none';
  void view.offsetWidth;
  view.style.animation = '';
  if (page === 'home') renderHome();
  else if (page === 'history') renderHistory();
  else if (page === 'stats') renderStats();
  else if (page === 'patterns') renderPatterns();
  else if (page === 'settings') renderSettings();
}

function renderTFRail() {
  const s = App.state;
  const rail = $('#tfRail');
  rail.innerHTML = s.timeframes.map((t) => `
    <button class="tf-chip ${t.id === App.tf ? 'active' : ''} ${t.enabled ? '' : 'disabled'}" data-tf="${t.id}">
      ${t.emoji} ${t.short}
    </button>`).join('');
  $$('.tf-chip', rail).forEach((b) => {
    b.onclick = () => {
      SFX.play('tap');
      App.tf = b.dataset.tf;
      store.set('bt_tf', App.tf);
      App.state = null;
      $('#view').innerHTML = '<div class="loader"><i></i><i></i><i></i></div>';
      refreshState(true);
    };
  });
}

function syncSoundBtn() {
  const b = $('#soundBtn');
  if (!b) return;
  b.textContent = SFX.on ? '🔊' : '🔇';
  b.classList.toggle('muted', !SFX.on);
}

/* ══════════════════════ state loop ══════════════════════ */
async function refreshState(force = false) {
  try {
    const { state } = await api('/state?tf=' + App.tf);
    const prev = App.state;
    App.state = state;
    App.countdownLocal = state.countdown;
    App.fetchedAt = Date.now();

    if (state.maintenance) {
      $('#maintenance').hidden = false;
      $('#mMsg').textContent = state.maintenanceMsg || 'Upgrading the engine.';
      return;
    }
    $('#maintenance').hidden = true;

    /* header */
    $('#tfLabel').textContent = state.tf.label;
    const badge = $('#feedBadge');
    badge.textContent = (state.feed.health === 'LIVE' ? '● LIVE' : '◐ SIM') + ' · ' + state.period.slice(-4);
    badge.classList.toggle('sim', state.feed.health !== 'LIVE');

    /* ticker */
    if (state.announcement) {
      const tick = $('#ticker');
      tick.hidden = false;
      const track = $('#tickerTrack');
      if (track.dataset.msg !== state.announcement) {
        track.dataset.msg = state.announcement;
        track.innerHTML = `<span style="padding:0 26px">${state.announcement.replace(/[<>]/g, '')}</span><span style="padding:0 26px">${state.announcement.replace(/[<>]/g, '')}</span>`;
      }
    } else {
      $('#ticker').hidden = true;
    }

    if (!prev || force) {
      renderTFRail();
      go(App.page);
    } else {
      /* in-page live refresh */
      const predChangedPeriod = state.prediction && state.prediction.period !== App.lastPredPeriod;
      if (predChangedPeriod) {
        App.lastPredPeriod = state.prediction.period;
        SFX.play('lock');
        if (App.page === 'home') renderHome();
        else toast('🔒 New signal sealed · #' + state.prediction.period.slice(-6), 'ok');
      } else if (App.page === 'home' && JSON.stringify(state.results.slice(0, 3)) !== JSON.stringify((prev.results || []).slice(0, 3))) {
        renderHome();
      }
    }

    /* resolve celebration */
    const latest = state.results.find((r) => r.outcome);
    if (latest && latest.period !== App.lastResolved) {
      App.lastResolved = latest.period;
      store.set('bt_lastResolved', latest.period);
      if (prev) celebrate(latest);
    }
  } catch (e) {
    if (e.code === 'SESSION' || e.code === 'REVOKED' || e.code === 'EXPIRED' || e.status === 401 || e.status === 403) {
      const msg = e.message || 'Session ended.';
      logout(msg);
    }
  }
}

function celebrate(result) {
  const kind = result.outcome === 'JACKPOT' ? 'jackpot' : result.outcome === 'WIN' ? 'win' : 'loss';
  SFX.play(kind === 'jackpot' ? 'jackpot' : kind);
  if (kind === 'jackpot') {
    burstEmojis('jackpot', 30);
    burstEmojis('win', 16);
    SFX.say('Hurrah! Mega jackpot hit. Exact number ' + result.number);
  } else if (kind === 'win') {
    burstEmojis('win', 20);
    SFX.say('Win! Result size ' + result.size);
  } else {
    burstEmojis('loss', 12);
    document.body.classList.add('shake');
    setTimeout(() => document.body.classList.remove('shake'), 480);
    SFX.say('Loss. Recovery level recalculating.');
  }
  showOverlay(kind, result);
  if (App.page === 'history') loadHistory();
  if (App.page === 'stats') renderStats();
}

function showOverlay(kind, result) {
  const root = $('#overlayRoot');
  const title = kind === 'jackpot' ? 'MEGA JACKPOT' : kind === 'win' ? 'WINNER' : 'LOSS DETECTED';
  const emoji = kind === 'jackpot' ? '👑' : kind === 'win' ? '🏆' : '💔';
  const desc = kind === 'jackpot'
    ? 'Exact number locked. Maximum payout tier.'
    : kind === 'win'
      ? 'Size call verified by the engine.'
      : 'Variance spike — recovery level engaged.';
  root.innerHTML = `
    <div class="overlay" id="ov">
      <div class="overlay-card">
        <div class="overlay-emoji">${emoji}</div>
        <div class="overlay-title ${kind.toUpperCase()}">${title}</div>
        <div class="overlay-desc">${desc}</div>
        <div class="overlay-nums">
          <div class="ball ${result.number >= 5 ? 'big' : 'small'}">${result.number}</div>
          <div class="ball ${result.size === 'BIG' ? 'big' : 'small'}">${result.size === 'BIG' ? 'B' : 'S'}</div>
        </div>
        <div class="overlay-desc" style="margin-bottom:14px">PERIOD #${(result.period || '').slice(-6)} · ${result.size}</div>
        <button class="overlay-close" id="ovClose">CONTINUE</button>
      </div>
    </div>`;
  const close = () => {
    const ov = $('#ov');
    if (!ov) return;
    ov.style.transition = 'opacity .25s';
    ov.style.opacity = '0';
    setTimeout(() => { root.innerHTML = ''; }, 260);
  };
  $('#ovClose').onclick = close;
  setTimeout(() => { if ($('#ov')) close(); }, kind === 'loss' ? 4200 : 6000);
}

/* ══════════════════════ auth ══════════════════════ */
async function login() {
  const input = $('#keyInput');
  const status = $('#loginStatus');
  const btn = $('#loginBtn');
  const key = input.value.trim().toUpperCase();
  if (!key) {
    status.textContent = 'Please enter your access key.';
    status.className = 'login-status';
    SFX.play('error');
    return;
  }
  btn.disabled = true;
  status.className = 'login-status';
  status.textContent = 'Authenticating with the secure server…';
  try {
    const res = await api('/auth/login', { method: 'POST', body: { key, deviceId } });
    token = res.token;
    store.set('bt_token', token);
    store.set('bt_keyMask', res.profile.key + ' · ' + (res.profile.plan || 'VIP'));
    if (res.adminToken) store.set('bt_admin_token', res.adminToken);
    status.className = 'login-status ok';
    status.textContent = '✅ Access granted. Booting the engine…';
    SFX.ensure();
    SFX.play('login');
    SFX.say('Access granted. Welcome to Bunny Team.');
    setTimeout(boot, 620);
  } catch (e) {
    status.className = 'login-status';
    status.textContent = e.message;
    SFX.play('error');
    if (e.code === 'DEVICE_LIMIT') {
      status.textContent = e.message;
    }
  } finally {
    btn.disabled = false;
  }
}

function logout(msg) {
  token = '';
  store.del('bt_token');
  store.del('bt_lastResolved');
  App.state = null;
  App.lastPredPeriod = null;
  $('#app').hidden = true;
  $('#loginScreen').hidden = false;
  $('#overlayRoot').innerHTML = '';
  document.body.classList.remove('locked');
  const status = $('#loginStatus');
  if (status) {
    status.className = 'login-status';
    status.textContent = msg || '';
  }
  if (msg) toast(msg, 'err');
}

/* ══════════════════════ boot ══════════════════════ */
async function boot() {
  try {
    const { state } = await api('/state?tf=' + App.tf);
    App.state = state;
    App.countdownLocal = state.countdown;
    App.fetchedAt = Date.now();
    App.lastPredPeriod = state.prediction ? state.prediction.period : null;
    const latest = (state.results || []).find((r) => r.outcome);
    if (latest) {
      App.lastResolved = latest.period;
      store.set('bt_lastResolved', latest.period);
    }
  } catch (e) {
    logout(e.message);
    return;
  }

  $('#loginScreen').hidden = true;
  $('#app').hidden = false;
  startFloatEmojis(App.animations);
  syncSoundBtn();
  renderTFRail();
  go('home');

  /* local countdown ticker */
  setInterval(() => {
    if (!App.state || document.hidden) return;
    const elapsed = Math.floor((Date.now() - App.fetchedAt) / 1000);
    const left = App.state.countdown - elapsed;
    App.countdownLocal = left > 0 ? left : 0;
    paintRing();
    if (left <= 5 && left > 0 && $('#ringTime') && !$('#ringTime').dataset.ticked?.includes(String(left))) {
      const t = $('#ringTime');
      const seen = (t.dataset.ticked || '').split(',');
      if (!seen.includes(String(left))) {
        t.dataset.ticked = [...seen, String(left)].slice(-6).join(',');
        SFX.play('tick');
      }
    }
    if (left <= 0 && !App._refetching) {
      App._refetching = true;
      setTimeout(() => { App._refetching = false; }, 2500);
      refreshState();
    }
  }, 1000);

  /* server sync */
  setInterval(() => refreshState(), 2600);

  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshState(); });
}

/* ══════════════════════ wiring ══════════════════════ */
$('#loginBtn').addEventListener('click', login);
$('#keyInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
$('#keyInput').addEventListener('input', (e) => {
  e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
});
$('#soundBtn').addEventListener('click', () => {
  SFX.on = !SFX.on;
  store.set('bt_sound', SFX.on ? '1' : '0');
  syncSoundBtn();
  SFX.play('tap');
});
$('#logoutBtn').addEventListener('click', () => {
  SFX.play('tap');
  logout('Signed out.');
});
$$('.nav-btn').forEach((b) => {
  b.addEventListener('click', () => {
    SFX.play('tap');
    go(b.dataset.page);
  });
});
document.addEventListener('pointerdown', () => SFX.ensure(), { once: true });

/* installable app shell */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}

/* auto-login with stored token */
if (token) {
  boot();
} else {
  setTimeout(() => $('#keyInput') && $('#keyInput').focus(), 400);
}
