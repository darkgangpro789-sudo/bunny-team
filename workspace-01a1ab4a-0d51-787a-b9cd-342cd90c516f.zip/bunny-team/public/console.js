/* ═══════════════════════════════════════════════════════════
   BUNNY TEAM — control console client
   talks only to /api/sys/* with a signed admin session
   ═══════════════════════════════════════════════════════════ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const mem = new Map();
const store = {
  get(k, d = null) { try { const v = localStorage.getItem(k); return v === null ? (mem.get(k) ?? d) : v; } catch { return mem.get(k) ?? d; } },
  set(k, v) { mem.set(k, v); try { localStorage.setItem(k, v); } catch { /* ignore */ } },
  del(k) { mem.delete(k); try { localStorage.removeItem(k); } catch { /* ignore */ } }
};

let ADMIN = store.get('bt_admin', '');
let ME = { username: '' };
let CACHE = { overview: null, settings: null, patterns: null, keys: [], force: {} };
let TAB = 'overview';

/* ───────── api ───────── */
async function sys(path, opts = {}) {
  const res = await fetch('/api/sys' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(ADMIN ? { Authorization: 'Bearer ' + ADMIN } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    cache: 'no-store'
  });
  let json = {};
  try { json = await res.json(); } catch { /* ignore */ }
  if (!res.ok) {
    if (res.status === 401 && path !== '/auth') {
      exitConsole('Session expired — authenticate again.');
    }
    const err = new Error(json.message || 'Request failed');
    err.code = json.code;
    throw err;
  }
  return json;
}

function toast(msg, kind = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 2600);
}
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const dt = (ts) => (ts ? new Date(ts).toLocaleString([], { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');
const left = (ts, exp) => {
  if (exp === null || exp === undefined) return 'LIFETIME';
  const d = exp - Date.now();
  if (d <= 0) return 'expired';
  const h = Math.floor(d / 3600000);
  if (h >= 24) return Math.floor(h / 24) + 'd ' + (h % 24) + 'h';
  if (h >= 1) return h + 'h ' + Math.floor((d % 3600000) / 60000) + 'm';
  return Math.max(1, Math.floor(d / 60000)) + 'm';
};
const copy = async (text) => {
  try { await navigator.clipboard.writeText(text); toast('Copied ✓', 'ok'); }
  catch {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Copied ✓', 'ok'); } catch { toast('Copy blocked', 'err'); }
    ta.remove();
  }
};

/* ───────── gate ───────── */
async function login() {
  const key = $('#ap').value.trim();
  const msg = $('#gateMsg');
  if (!key) { msg.textContent = 'Enter the master key.'; return; }
  msg.textContent = 'Verifying master key…';
  try {
    const r = await sys('/auth', { method: 'POST', body: { key } });
    ADMIN = r.token;
    store.set('bt_admin', ADMIN);
    ME = { label: r.label, usingDefault: r.usingDefault };
    msg.textContent = '';
    openConsole();
    if (r.usingDefault) toast('⚠ Built-in master key in use — rotate it in Security.', 'err');
  } catch (e) {
    msg.textContent = e.message;
    $('#ap').value = '';
  }
}

function exitConsole(reason) {
  ADMIN = '';
  store.del('bt_admin');
  $('#sys').hidden = true;
  $('#gate').hidden = false;
  if (reason) $('#gateMsg').textContent = reason;
}

async function openConsole() {
  $('#gate').hidden = true;
  $('#sys').hidden = false;
  $('#sysWho').textContent = (ME.label || 'RUP') + ' · full control';
  await refreshAll();
  render(TAB);
}

/* ───────── data ───────── */
async function refreshAll() {
  try {
    const ov = await sys('/overview');
    CACHE.overview = ov;
    CACHE.settings = ov.settings;
    const feed = ov.feed || {};
    const any = Object.values(feed)[0];
    $('#sysFeed').textContent = any ? (any.mode === 'live' ? '● LIVE FEED' : '◐ SIM FEED · ' + any.mode) : 'feed …';
  } catch (e) {
    toast(e.message, 'err');
  }
  if (TAB === 'keys') await loadKeys();
  if (TAB === 'engine' || TAB === 'app') await loadSettings();
}

async function loadKeys(q = '', status = 'all') {
  const r = await sys(`/keys?q=${encodeURIComponent(q)}&status=${encodeURIComponent(status)}`);
  CACHE.keys = r.keys;
  return r;
}
async function loadSettings() {
  const r = await sys('/settings');
  CACHE.settings = r.settings;
  CACHE.patterns = r.patterns;
  CACHE.timeframes = r.timeframes;
  return r;
}

/* ══════════════════════ panes ══════════════════════ */
function render(tab) {
  TAB = tab;
  $$('.sys-tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
  const pane = $('#pane');
  if (tab === 'overview') pane.innerHTML = paneOverview();
  if (tab === 'keys') { pane.innerHTML = paneKeys(); bindKeys(); loadKeys().then((r) => paintKeyTable(r.keys)); }
  if (tab === 'engine') { pane.innerHTML = paneLoading(); loadSettings().then(() => { pane.innerHTML = paneEngine(); bindEngine(); }); }
  if (tab === 'app') { pane.innerHTML = paneLoading(); loadSettings().then(() => { pane.innerHTML = paneApp(); bindApp(); }); }
  if (tab === 'audit') { pane.innerHTML = paneLoading(); loadAudit().then(() => { pane.innerHTML = paneAudit(); bindAudit(); }); }
  if (tab === 'security') pane.innerHTML = paneSecurity();
  if (tab === 'security') bindSecurity();
}
const paneLoading = () => `<div class="panel"><div class="loader"><i></i><i></i><i></i></div></div>`;

function paneOverview() {
  const o = CACHE.overview || { counts: {}, stats: {}, boot: {}, feed: {} };
  const c = o.counts || {}, st = o.stats || {};
  const feedRows = Object.entries(o.feed || {}).map(([tf, f]) => `
    <tr>
      <td class="mono-x">${tf}</td>
      <td><span class="st ${f.mode === 'live' ? 'ACTIVE' : 'UNUSED'}">${f.mode === 'live' ? 'LIVE' : String(f.mode).toUpperCase()}</span></td>
      <td>${f.results} draws</td><td>${f.predictions} sealed</td>
      <td style="color:var(--dim)">${f.at ? dt(f.at) : '—'}</td>
    </tr>`).join('');
  return `
    <div class="grid-4">
      <div class="kpi gold"><div class="k">Access keys</div><div class="v">${c.keys ?? 0}</div><div class="s">${c.active ?? 0} active · ${c.unused ?? ''}${c.revoked ?? 0} revoked</div></div>
      <div class="kpi mint"><div class="k">Online now</div><div class="v">${c.online ?? 0}</div><div class="s">last 5 minutes</div></div>
      <div class="kpi violet"><div class="k">Accuracy</div><div class="v">${st.total ? Math.round((st.wins / st.total) * 100) : 0}%</div><div class="s">${st.wins || 0}W · ${st.losses || 0}L · ${st.jackpots || 0}J</div></div>
      <div class="kpi pink"><div class="k">Signatures</div><div class="v">${c.patterns ?? 72}</div><div class="s">armed on server</div></div>
    </div>

    <div class="panel">
      <h3>Feed health <span class="hint">engine ${o.engineLive ? 'running' : 'stopped'} · store ${esc(o.store)}</span></h3>
      <div class="tbl-wrap"><table class="kt">
        <thead><tr><th>TF</th><th>Mode</th><th>Draws</th><th>Sealed</th><th>Last poll</th></tr></thead>
        <tbody>${feedRows || '<tr><td colspan="5" style="color:var(--dim)">booting…</td></tr>'}</tbody>
      </table></div>
    </div>

    <div class="grid-4">
      <div class="kpi"><div class="k">Node</div><div class="v" style="font-size:16px">${esc(o.boot?.node || '')}</div><div class="s">uptime ${o.boot?.uptime || 0}s</div></div>
      <div class="kpi"><div class="k">Store mode</div><div class="v" style="font-size:16px">${esc(o.store || '—')}</div><div class="s">server-side only</div></div>
      <div class="kpi"><div class="k">Expired keys</div><div class="v">${c.expired ?? 0}</div><div class="s">auto-blocked</div></div>
      <div class="kpi"><div class="k">Registry age</div><div class="v" style="font-size:16px">${o.boot?.createdAt ? dt(o.boot.createdAt) : '—'}</div><div class="s">created</div></div>
    </div>

    <div class="panel">
      <h3>Recent activity <span class="hint">latest 10 events</span></h3>
      ${(o.audits || []).slice(0, 10).map((a) => `
        <div class="audit-row"><span class="when">${dt(a.ts)}</span><span class="kind">${esc(a.kind)}</span><span class="det">${esc(JSON.stringify(a).slice(0, 120))}</span></div>
      `).join('') || '<div class="empty">No events yet.</div>'}
    </div>
  `;
}

function paneKeys() {
  const plans = ['1H', '6H', '1D', '7D', '30D', '1Y', 'LIFE'];
  return `
    <div class="panel">
      <h3>Key vault · generator <span class="hint">keys are created server-side and stored encrypted/cloud</span></h3>
      <div class="frow">
        <div class="field"><label>Quantity</label><input id="gCount" type="number" min="1" max="50" value="1" /></div>
        <div class="field"><label>Plan</label><select id="gPlan">${plans.map((p) => `<option value="${p}" ${p === '7D' ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
        <div class="field"><label>Prefix</label><input id="gPrefix" value="BT" maxlength="6" /></div>
        <div class="field"><label>Max devices</label><input id="gDev" type="number" min="1" max="5" value="1" /></div>
      </div>
      <div class="frow">
        <div class="field" style="grid-column:1/-1"><label>Note (who / why)</label><input id="gNote" placeholder="e.g. VIP reseller · telegram @bunny" maxlength="120" /></div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ghost gold" id="genBtn">⚡ GENERATE KEYS</button>
        <button class="ghost" id="copyAll">⧉ COPY GENERATED</button>
      </div>
      <div class="keyout" id="keyOut"></div>
    </div>

    <div class="panel">
      <h3>Registry <span class="hint" id="kCount">—</span></h3>
      <div class="frow">
        <div class="field"><label>Search</label><input id="kq" placeholder="key or note" /></div>
        <div class="field"><label>Status</label><select id="kst">
          <option value="all">All</option><option value="UNUSED">Unused</option><option value="IN USE">In use</option>
          <option value="EXPIRED">Expired</option><option value="REVOKED">Revoked</option>
        </select></div>
      </div>
      <div class="tbl-wrap"><table class="kt">
        <thead><tr><th>Key</th><th>Plan</th><th>Status</th><th>Expires in</th><th>Devices</th><th>Logins</th><th>Note</th><th>Actions</th></tr></thead>
        <tbody id="kBody"><tr><td colspan="8" style="color:var(--dim)">loading…</td></tr></tbody>
      </table></div>
    </div>
  `;
}

function paintKeyTable(keys) {
  const body = $('#kBody');
  if (!body) return;
  const cnt = $('#kCount');
  if (cnt) cnt.textContent = keys.length + ' rows';
  body.innerHTML = keys.length ? keys.map((k) => `
    <tr>
      <td><span class="mono-x">${esc(k.key)}</span> ${k.online ? '<span class="dot-on"></span>' : ''}</td>
      <td>${esc(k.plan || '')}</td>
      <td><span class="st ${k.status.replace(' ', '')}">${esc(k.status)}</span></td>
      <td style="color:var(--muted)">${left(k.createdAt, k.expiresAt)}</td>
      <td>${k.devicesCount}</td>
      <td>${k.logins || 0}</td>
      <td style="color:var(--dim);max-width:140px;overflow:hidden;text-overflow:ellipsis">${esc(k.note || '—')}</td>
      <td>
        <div class="rowacts">
          <button class="act" data-copy="${esc(k.key)}">⧉</button>
          <button class="act ${k.revoked ? 'mint' : 'bad'}" data-act="revoke" data-key="${esc(k.key)}" data-on="${k.revoked ? '0' : '1'}">${k.revoked ? 'unrevoke' : 'revoke'}</button>
          <button class="act warn" data-act="extend" data-key="${esc(k.key)}">+7D</button>
          <button class="act" data-act="reset-device" data-key="${esc(k.key)}">unlock</button>
          <button class="act bad" data-act="delete" data-key="${esc(k.key)}">del</button>
        </div>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" style="color:var(--dim)">No keys match.</td></tr>';

  $$('#kBody [data-copy]').forEach((b) => (b.onclick = () => copy(b.dataset.copy)));
  $$('#kBody [data-act]').forEach((b) => {
    b.onclick = async () => {
      const act = b.dataset.act;
      if (act === 'delete' && !confirm('Delete key ' + b.dataset.key + '?')) return;
      const body2 = act === 'revoke'
        ? { action: b.dataset.on === '1' ? 'revoke' : 'unrevoke' }
        : act === 'extend' ? { action: 'extend', plan: '7D' } : { action: act };
      try {
        await sys(`/keys/${encodeURIComponent(b.dataset.key)}/action`, { method: 'POST', body: body2 });
        toast('Done: ' + act, 'ok');
        loadKeys($('#kq')?.value || '', $('#kst')?.value || 'all').then((r) => paintKeyTable(r.keys));
        refreshAll();
      } catch (e) { toast(e.message, 'err'); }
    };
  });
}

function bindKeys() {
  $('#genBtn').onclick = async () => {
    const body = {
      count: parseInt($('#gCount').value, 10) || 1,
      plan: $('#gPlan').value,
      prefix: $('#gPrefix').value,
      maxDevices: parseInt($('#gDev').value, 10) || 1,
      note: $('#gNote').value
    };
    try {
      const r = await sys('/keys/generate', { method: 'POST', body });
      const out = $('#keyOut');
      out.innerHTML = r.created.map((k) => `<div class="keychip" data-k="${esc(k.key)}">${esc(k.key)}</div>`).join('');
      CACHE.generated = r.created.map((k) => k.key);
      $$('#keyOut .keychip').forEach((c) => (c.onclick = () => copy(c.dataset.k)));
      toast(r.created.length + ' key(s) generated ✓', 'ok');
      loadKeys($('#kq')?.value || '', $('#kst')?.value || 'all').then((res) => paintKeyTable(res.keys));
      refreshAll();
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#copyAll').onclick = () => {
    if (!CACHE.generated || !CACHE.generated.length) return toast('Generate keys first', 'err');
    copy(CACHE.generated.join('\n'));
  };
  const doSearch = () => loadKeys($('#kq').value, $('#kst').value).then((r) => paintKeyTable(r.keys));
  $('#kq').oninput = () => { clearTimeout(window.__kq); window.__kq = setTimeout(doSearch, 260); };
  $('#kst').onchange = doSearch;
}

function paneEngine() {
  const s = CACHE.settings || {};
  const e = s.engine || {};
  const tfs = CACHE.timeframes || [];
  const force = e.force || {};
  return `
    <div class="panel">
      <h3>Engine core <span class="hint">all computation runs on the server</span></h3>
      <div class="frow">
        <div class="field"><label>Confidence floor (flag below)</label><input id="minConf" type="number" min="50" max="99" value="${e.minConfidence ?? 60}" /></div>
        <div class="field"><label>Bunny core math</label><select id="coreMath">
          <option value="0" ${!e.disableCoreMath ? 'selected' : ''}>ENABLED</option>
          <option value="1" ${e.disableCoreMath ? 'selected' : ''}>DISABLED</option>
        </select></div>
      </div>
      <button class="ghost gold" id="saveEngine">💾 SAVE ENGINE CONFIG</button>
    </div>

    <div class="panel">
      <h3>Force next result <span class="hint">silent override (admin-only, never shown to users)</span></h3>
      <div class="frow">
        <div class="field"><label>Timeframe</label><select id="fTf">
          <option value="ALL">ALL</option>${tfs.map((t) => `<option value="${t.id}">${t.id} · ${esc(t.label)}</option>`).join('')}
        </select></div>
        <div class="field"><label>Verdict</label><select id="fSize">
          <option value="BIG">BIG</option><option value="SMALL">SMALL</option>
        </select></div>
        <div class="field"><label>Periods</label><input id="fPer" type="number" min="1" max="20" value="1" /></div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ghost warn" id="forceBtn">🔒 APPLY FORCE</button>
        <button class="ghost" id="clearForce">✖ CLEAR ALL FORCE</button>
      </div>
      <div class="hint" style="margin-top:10px;font-size:9.5px;color:var(--muted)">
        Active: ${Object.keys(force).length ? Object.entries(force).map(([k, v]) => `<b style="color:var(--gold)">${k}</b>→${v.size}×${v.periods}`).join(' · ') : 'none'}
      </div>
    </div>

    <div class="panel">
      <h3>Signature bank <span class="hint">uncheck to disarm a pattern</span></h3>
      <div class="pat-grid" id="patGrid">
        ${(CACHE.patterns || []).map((p) => `
          <label class="pat-item">
            <input type="checkbox" data-pat="${esc(p.id)}" ${(e.disabledPatterns || []).includes(p.id) ? '' : 'checked'} />
            <span>${esc(p.name)}</span><span class="t">${p.tier}</span>
          </label>`).join('')}
      </div>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <button class="ghost mint" id="savePat">💾 SAVE ARMED SET</button>
        <button class="ghost" id="allPat">✓ ARM ALL</button>
      </div>
    </div>

    <div class="panel">
      <h3>Engine sandbox <span class="hint">test any digit sequence (newest first)</span></h3>
      <div class="frow">
        <div class="field" style="grid-column:1/-1"><label>Digits</label><input id="simNums" placeholder="7 2 9 4 4 8 1 5 9" /></div>
      </div>
      <button class="ghost gold" id="simBtn">▶ RUN ENGINE</button>
      <div class="sim-out" id="simOut">—</div>
    </div>

    <div class="panel">
      <h3>Scoreboard</h3>
      <button class="ghost bad" id="resetStats">⟲ RESET GLOBAL STATS</button>
    </div>
  `;
}

function bindEngine() {
  $('#saveEngine').onclick = async () => {
    try {
      await sys('/settings', { method: 'PUT', body: { engine: { minConfidence: parseInt($('#minConf').value, 10), disableCoreMath: $('#coreMath').value === '1' } } });
      toast('Engine config saved ✓', 'ok');
      refreshAll();
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#forceBtn').onclick = async () => {
    try {
      const r = await sys('/engine/force', { method: 'POST', body: { tf: $('#fTf').value, size: $('#fSize').value, periods: parseInt($('#fPer').value, 10) || 1 } });
      toast('Force armed: ' + JSON.stringify(r.force), 'ok');
      await loadSettings(); render('engine');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#clearForce').onclick = async () => {
    try {
      await sys('/engine/force', { method: 'POST', body: { tf: 'ALL', size: 'CLEAR' } });
      toast('Force cleared', 'ok');
      await loadSettings(); render('engine');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#savePat').onclick = async () => {
    const disabled = $$('#patGrid input').filter((i) => !i.checked).map((i) => i.dataset.pat);
    try {
      await sys('/settings', { method: 'PUT', body: { engine: { disabledPatterns: disabled } } });
      toast(`Armed ${72 - disabled.length}/72 signatures ✓`, 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#allPat').onclick = () => $$('#patGrid input').forEach((i) => (i.checked = true));
  $('#simBtn').onclick = async () => {
    try {
      const r = await sys('/simulate', { method: 'POST', body: { numbers: $('#simNums').value } });
      const p = r.result;
      $('#simOut').textContent =
        `VERDICT   : ${p.size}\nNUMBERS   : ${p.numbers.join(' , ')}\nCONFIDENCE: ${p.confidence}%\nPATTERN   : ${p.patternName}\nDETAIL    : ${p.patternDetail}\nSOURCE    : ${p.source} · PRI ${p.pattern.priority}\nCROSS     : ${p.crossCheck}\nMATCHES   : ${p.matchCount}\nVOTES     : ${p.votes.big} BIG / ${p.votes.small} SMALL (${p.votes.share}% share)\nSEQUENCE  : ${p.seq}`;
    } catch (e) { $('#simOut').textContent = '⚠ ' + e.message; }
  };
  $('#resetStats').onclick = async () => {
    if (!confirm('Reset the global win/loss scoreboard?')) return;
    try { await sys('/stats/reset', { method: 'POST' }); toast('Scoreboard reset', 'ok'); refreshAll(); } catch (e) { toast(e.message, 'err'); }
  };
}

function paneApp() {
  const s = CACHE.settings || {};
  const tfs = CACHE.timeframes || [];
  const sw = (id, on, t, sub) => `<div class="swrow"><div><div class="t">${t}</div><div class="s">${sub}</div></div>
    <div class="switch ${on ? 'on' : ''}" id="${id}"></div></div>`;
  return `
    <div class="panel">
      <h3>Branding & broadcast</h3>
      <div class="frow">
        <div class="field"><label>App name</label><input id="sName" value="${esc(s.appName || '')}" /></div>
        <div class="field"><label>Tagline</label><input id="sTag" value="${esc(s.tagline || '')}" /></div>
      </div>
      <div class="field"><label>Ticker announcement</label><textarea id="sAnn">${esc(s.announcement || '')}</textarea></div>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <button class="ghost gold" id="saveBrand">💾 SAVE + BROADCAST</button>
      </div>
    </div>

    <div class="panel">
      <h3>Switches</h3>
      ${sw('swAnn', s.announcementEnabled !== false, 'Countdown ticker', 'show the announcement bar')}
      ${sw('swReg', s.registrationOpen !== false, 'Key registration', 'allow new keys to log in')}
      ${sw('swMaint', !!s.maintenance, 'Maintenance mode', 'freeze every client with a message')}
      ${sw('swSnd', s.soundsDefault !== false, 'Sound default', 'new users start with sound on')}
      ${sw('swVoice', s.voiceDefault !== false, 'Voice default', 'spoken result calls')}
      ${sw('swAnim', s.animationsDefault !== false, 'Animated emojis default', 'floating emoji layer')}
      <div class="field" style="margin-top:12px"><label>Maintenance message</label><input id="sMaintMsg" value="${esc(s.maintenanceMsg || '')}" /></div>
      <button class="ghost gold" id="saveSw" style="margin-top:12px">💾 SAVE SWITCHES</button>
    </div>

    <div class="panel">
      <h3>Timeframes</h3>
      ${tfs.map((t) => `<div class="swrow"><div><div class="t">${t.emoji} ${esc(t.label)}</div><div class="s">${t.seconds}s engine cadence</div></div>
        <div class="switch ${(s.timeframes || {})[t.id] !== false ? 'on' : ''}" data-tfsw="${t.id}"></div></div>`).join('')}
      <button class="ghost gold" id="saveTf" style="margin-top:12px">💾 SAVE TIMEFRAMES</button>
    </div>

    <div class="panel">
      <h3>Feature visibility</h3>
      ${['history', 'stats', 'patterns', 'consensus', 'trendChart'].map((f) => `
        <div class="swrow"><div><div class="t">${f}</div><div class="s">show this module to users</div></div>
        <div class="switch ${(s.features || {})[f] !== false ? 'on' : ''}" data-feat="${f}"></div></div>`).join('')}
      <button class="ghost gold" id="saveFeat" style="margin-top:12px">💾 SAVE FEATURES</button>
    </div>

    <div class="panel">
      <h3>Vault &amp; export <span class="hint" id="vaultInfo">own encrypted storage</span></h3>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ghost" data-exp="keys">⤓ KEYS CSV</button>
        <button class="ghost" data-exp="history">⤓ HISTORY CSV</button>
        <button class="ghost" data-exp="audit">⤓ AUDIT CSV</button>
        <button class="ghost mint" data-vault="backup">🔐 VAULT BACKUP (.enc)</button>
        <button class="ghost" data-vault="export">⤓ FULL JSON</button>
        <button class="ghost warn" id="vaultRestore">⬆ RESTORE VAULT</button>
        <button class="ghost" id="vaultBoot">⧉ BOOTSTRAP ENV (free hosts)</button>
        <input id="vaultFile" type="file" accept=".enc,text/plain" style="display:none" />
      </div>
    </div>
  `;
}

function bindApp() {
  const onClick = (id, fn) => { const n = $(id); if (n) n.onclick = fn; };
  $$('.switch').forEach((s) => {
    s.onclick = () => s.classList.toggle('on');
  });
  onClick('#saveBrand', async () => {
    try {
      await sys('/settings', { method: 'PUT', body: { appName: $('#sName').value, tagline: $('#sTag').value } });
      await sys('/broadcast', { method: 'POST', body: { announcement: $('#sAnn').value, enabled: $('#swAnn').classList.contains('on') } });
      toast('Branding saved ✓', 'ok');
      refreshAll();
    } catch (e) { toast(e.message, 'err'); }
  });
  onClick('#saveSw', async () => {
    try {
      await Promise.all([
        sys('/settings', { method: 'PUT', body: {
          announcementEnabled: $('#swAnn').classList.contains('on'),
          registrationOpen: $('#swReg').classList.contains('on'),
          soundsDefault: $('#swSnd').classList.contains('on'),
          voiceDefault: $('#swVoice').classList.contains('on'),
          animationsDefault: $('#swAnim').classList.contains('on'),
          maintenanceMsg: $('#sMaintMsg').value
        } }),
        sys('/maintenance', { method: 'POST', body: { on: $('#swMaint').classList.contains('on'), msg: $('#sMaintMsg').value } })
      ]);
      toast('Switches saved ✓', 'ok');
      refreshAll();
    } catch (e) { toast(e.message, 'err'); }
  });
  onClick('#saveTf', async () => {
    const tf = {};
    $$('[data-tfsw]').forEach((s) => (tf[s.dataset.tfsw] = s.classList.contains('on')));
    try { await sys('/settings', { method: 'PUT', body: { timeframes: tf } }); toast('Timeframes saved ✓', 'ok'); refreshAll(); }
    catch (e) { toast(e.message, 'err'); }
  });
  onClick('#saveFeat', async () => {
    const f = {};
    $$('[data-feat]').forEach((s) => (f[s.dataset.feat] = s.classList.contains('on')));
    try { await sys('/settings', { method: 'PUT', body: { features: f } }); toast('Features saved ✓', 'ok'); refreshAll(); }
    catch (e) { toast(e.message, 'err'); }
  });
  $$('[data-vault]').forEach((b) => {
    b.onclick = () => {
      const kind = b.dataset.vault;
      fetch('/api/sys/vault/' + kind, { headers: { Authorization: 'Bearer ' + ADMIN } })
        .then((r) => r.blob())
        .then((blob) => {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'bunny-vault-' + Date.now() + (kind === 'backup' ? '.enc' : '.json');
          a.click();
          setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        })
        .catch(() => toast('Vault download failed', 'err'));
    };
  });
  const vb = $('#vaultBoot');
  if (vb) vb.onclick = async () => {
    try {
      const r = await fetch('/api/sys/vault/bootstrap', { headers: { Authorization: 'Bearer ' + ADMIN } });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || 'failed');
      await navigator.clipboard.writeText(j.b64).catch(() => {});
      toast(`Bootstrap string copied (${j.kb} KB) → paste in VAULT_BOOTSTRAP_B64 env var`, 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  const vr = $('#vaultRestore');
  if (vr) vr.onclick = () => $('#vaultFile').click();
  const vf = $('#vaultFile');
  if (vf) vf.onchange = async () => {
    const f = vf.files && vf.files[0];
    if (!f) return;
    if (!confirm('Restore vault from "' + f.name + '"? Current data will be replaced.')) return;
    try {
      const buf = await f.arrayBuffer();
      const r = await fetch('/api/sys/vault/restore', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + ADMIN, 'Content-Type': 'application/octet-stream' },
        body: buf
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || 'restore failed');
      toast(j.message || 'Vault restored ✓', 'ok');
      await refreshAll(); render('app');
    } catch (e) { toast(e.message, 'err'); }
  };
  fetch('/api/sys/vault', { headers: { Authorization: 'Bearer ' + ADMIN } })
    .then((r) => r.json())
    .then((j) => {
      const n = $('#vaultInfo');
      if (n && j.vault) n.textContent = `${j.vault.algorithm} · ${(j.vault.bytes / 1024).toFixed(1)} KB · ${j.counts.keys} keys`;
    })
    .catch(() => {});

  $$('[data-exp]').forEach((b) => {
    b.onclick = () => {
      fetch('/api/sys/export?type=' + b.dataset.exp, { headers: { Authorization: 'Bearer ' + ADMIN } })
        .then((r) => r.blob())
        .then((blob) => {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'bunny-team-' + b.dataset.exp + '.csv';
          a.click();
          setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        })
        .catch(() => toast('Export failed', 'err'));
    };
  });
}

async function loadAudit() {
  const r = await sys('/audit');
  CACHE.audit = r.audit || [];
}

function paneAudit() {
  const a = CACHE.audit || [];
  return `
    <div class="panel">
      <h3>Audit trail <span class="hint">${a.length} events · immutable order</span></h3>
      <div style="max-height:60vh;overflow:auto">
        ${a.map((e) => `
          <div class="audit-row">
            <span class="when">${dt(e.ts)}</span>
            <span class="kind">${esc(e.kind)}</span>
            <span class="det">${esc(JSON.stringify(e).slice(0, 160))}</span>
          </div>`).join('') || '<div class="empty">No events yet.</div>'}
      </div>
    </div>`;
}
function bindAudit() { /* read only */ }

function paneSecurity() {
  return `
    <div class="panel">
      <h3>Rotate master key <span class="hint">this is the only credential for this console</span></h3>
      <div class="frow">
        <div class="field"><label>Current master key</label><input id="pCur" type="password" autocomplete="off" /></div>
        <div class="field"><label>New master key (8+)</label><input id="pNew" type="password" autocomplete="new-password" /></div>
      </div>
      <button class="ghost gold" id="pSave">🔐 UPDATE MASTER KEY</button>
    </div>
    <div class="panel">
      <h3>Hardening checklist</h3>
      <div class="audit-row"><span class="when">1</span><span class="kind">VAULT</span><span class="det">Data is your own encrypted file (<b>AES-256-GCM</b>) on this server. No third-party database, no cloud.</span></div>
      <div class="audit-row"><span class="when">2</span><span class="kind">BACKUP</span><span class="det">Take a vault backup from the App tab weekly and keep it off-server — the .enc file is useless without the key.</span></div>
      <div class="audit-row"><span class="when">3</span><span class="kind">KEYS</span><span class="det">Master key = <b>only</b> console credential. Rotate it here periodically; never share it in chat.</span></div>
      <div class="audit-row"><span class="when">4</span><span class="kind">CONSOLE</span><span class="det">ADMIN_PATH is the only route serving this panel. Change it to your private phrase in .env.</span></div>
      <div class="audit-row"><span class="when">5</span><span class="kind">SECRETS</span><span class="det">SESSION_SECRET / DATA_SECRET long random strings in .env — never committed to git.</span></div>
    </div>
  `;
}
function bindSecurity() {
  const b = $('#pSave');
  if (b) b.onclick = async () => {
    try {
      const r = await sys('/password', { method: 'POST', body: { current: $('#pCur').value, next: $('#pNew').value } });
      toast(r.message || 'Master key updated ✓', 'ok');
      $('#pCur').value = ''; $('#pNew').value = '';
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ════════════════ wiring ════════════════ */
$('#gateBtn').onclick = login;
$('#ap').addEventListener('keydown', (e) => { if (e.key === 'Enter') login(); });
$('#btnExit').onclick = () => exitConsole('Signed out.');
$('#btnRefresh').onclick = async () => { await refreshAll(); render(TAB); toast('Synced ✓', 'ok'); };
$$('.sys-tab').forEach((b) => (b.onclick = () => { render(b.dataset.tab); if (b.dataset.tab === 'overview') refreshAll().then(() => render('overview')); }));

setInterval(() => { if (ADMIN && TAB === 'overview') refreshAll().then(() => render('overview')); }, 15000);

(async () => {
  if (!ADMIN) return;
  try {
    const r = await fetch('/api/sys/me', { headers: { Authorization: 'Bearer ' + ADMIN } });
    if (!r.ok) throw new Error('expired');
    const j = await r.json();
    ME = { label: j.label, usingDefault: j.usingDefault };
    openConsole();
  } catch {
    exitConsole('Session expired — authenticate again.');
  }
})();
