#!/bin/sh
# BUNNY TEAM — self-healing launcher (installs deps if missing, restarts on crash)
cd "$(dirname "$0")" || exit 1
if [ ! -d node_modules/express ]; then
  echo "[run] installing dependencies…"
  npm install --omit=dev --no-audit --no-fund >/dev/null 2>&1 || npm install --no-audit --no-fund >/dev/null 2>&1
fi
while true; do
  node src/index.js
  code=$?
  echo "[run] server exited (code $code) — restarting in 2s"
  sleep 2
done
