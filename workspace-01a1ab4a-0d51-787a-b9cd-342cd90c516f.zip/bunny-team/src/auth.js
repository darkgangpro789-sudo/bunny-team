import crypto from 'node:crypto';

const B64 = (buf) => Buffer.from(buf).toString('base64url');

/* ───────── password hashing (scrypt, no external deps) ───────── */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  if (!stored || typeof stored !== 'string') return false;
  const [scheme, salt, hash] = stored.split('$');
  if (scheme !== 'scrypt' || !salt || !hash) return false;
  const test = crypto.scryptSync(String(password), salt, 64).toString('hex');
  const a = Buffer.from(test, 'hex');
  const b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ───────── signed tokens ───────── */
export function signToken(payload, secret, ttlSeconds) {
  const body = { ...payload, iat: Date.now(), exp: Date.now() + ttlSeconds * 1000 };
  const data = B64(JSON.stringify(body));
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

export function verifyToken(token, secret) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [data, sig] = token.split('.');
  const expect = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  const a = Buffer.from(sig || '');
  const b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const body = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    if (!body.exp || body.exp < Date.now()) return null;
    return body;
  } catch {
    return null;
  }
}

/* ───────── key generation ───────── */
const ALPHABET = 'ACDEFGHJKLMNPQRTUVWXY34679'; // no look-alikes

export function randomKey(prefix = 'BT') {
  const chunk = (n) =>
    Array.from({ length: n }, () => ALPHABET[crypto.randomInt(0, ALPHABET.length)]).join('');
  return `${prefix}-${chunk(4)}-${chunk(4)}`;
}

export function newDeviceId() {
  return 'DEV-' + crypto.randomBytes(5).toString('hex').toUpperCase();
}

/* ───────── tiny in-memory rate limiter ───────── */
const buckets = new Map();

export function rateLimit(bucket, id, limit, windowMs) {
  const now = Date.now();
  const arr = (buckets.get(bucket + ':' + id) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  buckets.set(bucket + ':' + id, arr);
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (!v.length || now - v[v.length - 1] > windowMs) buckets.delete(k);
  }
  return arr.length <= limit;
}

export const PLAN_HOURS = {
  '1H': 1,
  '6H': 6,
  '1D': 24,
  '7D': 24 * 7,
  '30D': 24 * 30,
  '1Y': 24 * 365,
  LIFE: null
};

export function expiryFor(plan, from = Date.now()) {
  const h = PLAN_HOURS[plan];
  if (h === undefined) return null;
  if (h === null) return null;
  return from + h * 3600 * 1000;
}

export const maskKey = (k) => (k ? k.slice(0, 6) + '••••' + k.slice(-2) : '');
