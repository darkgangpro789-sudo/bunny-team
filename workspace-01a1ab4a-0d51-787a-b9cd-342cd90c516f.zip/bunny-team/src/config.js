import 'dotenv/config';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '..');

const bool = (v, d = false) =>
  v === undefined || v === null || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  host: process.env.HOST || '0.0.0.0',
  nodeEnv: process.env.NODE_ENV || 'development',

  /* ── hidden console — ONE master key, nothing else ── */
  adminPath: (process.env.ADMIN_PATH || '/bunny-console-9x7').replace(/\/+$/, ''),
  adminKey: process.env.ADMIN_KEY || 'RUP@ADHIKARY',       // 🔐 the only console credential
  adminLabel: process.env.ADMIN_LABEL || 'RUP',            // shown in the console header
  ownerKey: process.env.OWNER_KEY || '',                   // optional: a VIP key that also opens the console

  /* ── secrets ── */
  sessionSecret: process.env.SESSION_SECRET || '',
  dataSecret: process.env.DATA_SECRET || process.env.SESSION_SECRET || '',
  sessionHours: parseInt(process.env.SESSION_HOURS || '12', 10),
  adminSessionHours: parseInt(process.env.ADMIN_SESSION_HOURS || '8', 10),

  /* ── own data store (encrypted vault on this server) ── */
  dataDir: process.env.DATA_DIR || path.join(ROOT, 'var'),
  dataFile: process.env.DATA_FILE || path.join(process.env.DATA_DIR || path.join(ROOT, 'var'), 'bunny-vault.enc'),
  backupFile: process.env.BACKUP_FILE || path.join(process.env.DATA_DIR || path.join(ROOT, 'var'), 'bunny-vault.backup.enc'),
  vaultRounds: parseInt(process.env.VAULT_ROUNDS || '12000', 10),

  /* ── draw feed ── */
  feedBase: process.env.FEED_BASE || 'https://draw.ar-lottery01.com',
  feedProxy: process.env.FEED_PROXY || '',                 // e.g. https://api.allorigins.win/raw?url={url}
  feedTimeout: parseInt(process.env.FEED_TIMEOUT || '7000', 10),
  allowSyntheticFeed: bool(process.env.ALLOW_SYNTHETIC_FEED, true),
  pollMs: parseInt(process.env.POLL_MS || '2500', 10),

  /* ── engine ── */
  defaultTimeframe: process.env.DEFAULT_TF || '1M',
  trustProxy: bool(process.env.TRUST_PROXY, true)
};

export function assertConfig() {
  const warnings = [];
  if (!config.sessionSecret) {
    warnings.push('SESSION_SECRET not set — a random one is generated per vault boot (sessions drop on restart).');
  }
  if (!config.dataSecret) {
    warnings.push('DATA_SECRET not set — vault key is derived from the generated session secret. Set it for permanent encryption.');
  }
  if (!process.env.ADMIN_KEY) {
    warnings.push('ADMIN_KEY not set — falling back to the built-in master key. Change it in .env before going public.');
  }
  return warnings;
}
