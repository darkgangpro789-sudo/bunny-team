/**
 * BUNNY TEAM — MASTER PREDICTION ENGINE (server-side only)
 * ------------------------------------------------------------------
 * Combines every logic branch of the 3 source engines:
 *   1. Dragon-V3 pattern bank  -> 72 signatures (SIG + CFM) with priority tiers
 *   2. CRACKED-MODE rules      -> streak / ABAB / AABB / SBB / BSS
 *   3. Priyanka consensus      -> 15 independent algorithm voters
 *   +  BUNNY CORE MATH         -> sum-weighted digit + period modulo model
 *   +  Markov trend fallback   -> transition matrix + frequency number ranking
 *
 * The whole engine runs on the server. The browser never receives the rules,
 * only the final sealed prediction for the active period.
 */
import { PATTERNS } from './patterns.js';

export const TF_LIST = [
  { id: '30S', label: 'WinGo 30 Sec', seconds: 30, code: '10005', emoji: '⚡' },
  { id: '1M', label: 'WinGo 1 Min', seconds: 60, code: '10001', emoji: '🕐' },
  { id: '3M', label: 'WinGo 3 Min', seconds: 180, code: '10002', emoji: '🕒' },
  { id: '5M', label: 'WinGo 5 Min', seconds: 300, code: '10003', emoji: '🕔' }
];

export const getTF = (id) => TF_LIST.find((t) => t.id === id) || TF_LIST[1];
export const getSize = (n) => (parseInt(n, 10) >= 5 ? 'BIG' : 'SMALL');
export const sideChar = (n) => (parseInt(n, 10) >= 5 ? 'B' : 'S');
export const opposite = (s) => (s === 'BIG' ? 'SMALL' : 'BIG');

/* ───────────────────────── periods & timers ───────────────────────── */
export function getCurrentPeriod(tf, time = Date.now()) {
  const d = new Date(time);
  const dateStr =
    d.getUTCFullYear() +
    String(d.getUTCMonth() + 1).padStart(2, '0') +
    String(d.getUTCDate()).padStart(2, '0');
  const secs = d.getUTCHours() * 3600 + d.getUTCMinutes() * 60 + d.getUTCSeconds();
  const periodNum = Math.floor(secs / tf.seconds) + 1;
  return `${dateStr}${tf.code}${String(periodNum).padStart(4, '0')}`;
}

export function nextPeriodOf(period) {
  try {
    const head = period.slice(0, -4);
    const tail = parseInt(period.slice(-4), 10);
    if (isNaN(tail)) return String(BigInt(period) + 1n);
    return head + String(tail + 1).padStart(4, '0');
  } catch {
    return period;
  }
}

export function getCountdown(tf, time = Date.now()) {
  const secs = Math.floor(time / 1000);
  const left = tf.seconds - (secs % tf.seconds);
  return left === tf.seconds ? tf.seconds : left;
}

/* ───────────────────────── number model ───────────────────────── */
const modelState = {
  freq: Array(10).fill(0),
  transitions: Array(10).fill(null).map(() => Array(10).fill(0))
};

function updateModel(nums) {
  modelState.freq = Array(10).fill(0);
  modelState.transitions = Array(10).fill(null).map(() => Array(10).fill(0));
  for (let i = 0; i < nums.length; i++) {
    const n = nums[i];
    if (n >= 0 && n <= 9) {
      modelState.freq[n]++;
      if (i + 1 < nums.length) {
        const older = nums[i + 1];
        if (older >= 0 && older <= 9) modelState.transitions[older][n]++;
      }
    }
  }
}

function rankNumbers(cand, nums, favSize) {
  const scores = cand.map((n) => {
    let s = 5.0;
    s += nums.slice(0, 20).filter((x) => x === n).length * 14;
    if (nums.length > 0) {
      const row = modelState.transitions[nums[0]];
      const sum = row ? row.reduce((a, b) => a + b, 0) : 0;
      if (sum > 0 && row[n] > 0) s += (row[n] / sum) * 25;
    }
    if (getSize(n) === favSize) s += 15;
    if (nums.slice(0, 3).includes(n)) s += 10;
    return { num: n, score: s };
  });
  return scores.sort((a, b) => b.score - a.score).map((x) => x.num);
}

function generatePairs(predSize, nums) {
  const same = predSize === 'BIG' ? [5, 6, 7, 8, 9] : [0, 1, 2, 3, 4];
  const opp = predSize === 'BIG' ? [0, 1, 2, 3, 4] : [5, 6, 7, 8, 9];
  const rS = rankNumbers(same, nums, predSize);
  const rO = rankNumbers(opp, nums, opposite(predSize));
  const favNum = rS[0] ?? (predSize === 'BIG' ? 7 : 2);
  let oppNum = rO[0] ?? (predSize === 'BIG' ? 2 : 7);
  const nums2 = [favNum, oppNum].sort((a, b) => a - b);
  return { favNum, oppNum, numbers: nums2 };
}

/* ───────────────────────── BUNNY CORE MATH ───────────────────────── */
export function bunnyCoreMath(nums, period) {
  if (!nums || nums.length < 3) return null;
  const pInt = parseInt(String(period).slice(-3), 10) || 0;
  const sum = ((nums[0] || 0) * 3 + (nums[1] || 0) * 2 + (nums[2] || 0) + pInt) % 10;
  const size = sum >= 5 ? 'BIG' : 'SMALL';
  const conf = 90 + (sum === 0 || sum === 9 ? 9 : sum === 4 || sum === 5 ? 4 : 7);
  return {
    src: 'BNY',
    id: 'BUNNY-CORE',
    name: '🐰 BUNNY CORE MATH',
    pri: 96,
    conf,
    size,
    detail: `Σ(3·${nums[0]}+2·${nums[1]}+${nums[2]}+P) mod 10 = ${sum}`,
    seq: `Σ+P=${sum}`
  };
}

/* ───────────────────────── pattern scan ───────────────────────── */
export function detectAllMatches(sizes, disabled = []) {
  if (!sizes || sizes.length < 2) return [];
  const hits = [];
  const off = new Set(disabled);
  for (const p of PATTERNS) {
    if (off.has(p.id)) continue;
    try {
      if (p.test(sizes)) {
        const pred = p.predict(sizes);
        hits.push({
          src: p.src,
          id: p.id,
          pri: p.pri,
          name: p.name,
          size: pred.size,
          conf: pred.conf,
          detail: pred.detail,
          seq: sizes.slice(0, Math.min(sizes.length, 8)).join('')
        });
      }
    } catch {
      /* a malformed signature must never break the engine */
    }
  }
  return hits;
}

/* ───────────────────────── 15 consensus algorithms ───────────────────────── */
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function bigRate(nums, n) {
  const w = nums.slice(0, n);
  if (!w.length) return 0.5;
  return w.filter((x) => x >= 5).length / w.length;
}

export const ALGO_NAMES = [
  'Markov 1st-Order', 'Markov 2nd-Order', 'Digit Topology', 'Quantum Entropy',
  'Dynamic Streak Pivot', 'N-Gram Memory', 'Bayesian Posterior', 'Simple Moving Avg',
  'Fibonacci Sequence', 'Golden Ratio Modulo', 'Tri-State Joint', 'Run-Length Harmonic',
  'Poisson Deficit', 'Shannon Entropy', 'Fisher Information'
];

function consensusVotes(nums, sizes, period) {
  const votes = [];
  const push = (i, size, conf, note) =>
    votes.push({ name: ALGO_NAMES[i], index: i + 1, size, conf: clamp(Math.round(conf), 50, 96), note });

  /* 1 — Markov 1st order (digit transitions) */
  {
    const row = modelState.transitions[nums[0]] || Array(10).fill(0);
    const big = row.slice(5).reduce((a, b) => a + b, 0);
    const small = row.slice(0, 5).reduce((a, b) => a + b, 0);
    const tot = big + small;
    const p = tot ? big / tot : 0.5;
    push(0, p >= 0.5 ? 'BIG' : 'SMALL', 58 + Math.abs(p - 0.5) * 70, `P(BIG|${nums[0]})=${(p * 100).toFixed(0)}%`);
  }

  /* 2 — Markov 2nd order */
  {
    let b = 0, s = 0;
    const key = nums[0] + '-' + nums[1];
    for (let i = 0; i + 2 < nums.length; i++) {
      if (nums[i] + '-' + nums[i + 1] === key) {
        if (nums[i + 2] >= 5) b++; else s++;
      }
    }
    const tot = b + s;
    const p = tot ? b / tot : 0.5;
    push(1, p >= 0.5 ? 'BIG' : 'SMALL', tot ? 60 + Math.abs(p - 0.5) * 60 : 55, `pair ${key} → ${b}B/${s}S`);
  }

  /* 3 — Digit topology (frequency deficit) */
  {
    const f = Array(10).fill(0);
    nums.slice(0, 25).forEach((n) => f[n]++);
    const cold = f.indexOf(Math.min(...f));
    push(2, getSize(cold), 62, `cold digit → ${cold}`);
  }

  /* 4 — Quantum entropy of the digit stream */
  {
    const f = Array(10).fill(0);
    nums.slice(0, 20).forEach((n) => f[n]++);
    const tot = Math.min(nums.length, 20) || 1;
    let H = 0;
    f.forEach((c) => { if (c) { const p = c / tot; H -= p * Math.log2(p); } });
    const size = H > 3.05 ? opposite(getSize(nums[0])) : getSize(nums[0]);
    push(3, size, 55 + Math.abs(H - 3) * 20, `H=${H.toFixed(2)} bits`);
  }

  /* 5 — Dynamic streak pivot */
  {
    let len = 1;
    for (let i = 1; i < sizes.length && sizes[i] === sizes[0]; i++) len++;
    const size = len >= 4 ? opposite(sizes[0]) : sizes[0];
    push(4, size, 60 + len * 5, `run ${sizes[0]} ×${len}`);
  }

  /* 6 — N-gram memory */
  {
    const gram = sizes.slice(0, 3).join('');
    let b = 0, s = 0;
    for (let i = 0; i + 3 < sizes.length; i++) {
      if (sizes.slice(i, i + 3).join('') === gram) {
        if (sizes[i + 3] === 'B') b++; else s++;
      }
    }
    const tot = b + s;
    const size = tot ? (b >= s ? 'BIG' : 'SMALL') : opposite(sizes[0]);
    push(5, size, tot ? 62 + Math.abs(b - s) * 6 : 54, `gram ${gram} → ${b}B/${s}S`);
  }

  /* 7 — Bayesian posterior (Beta(2,2) prior) */
  {
    const br = bigRate(nums, 20);
    const n = Math.min(nums.length, 20);
    const post = (br * n + 2) / (n + 4);
    push(6, post >= 0.5 ? 'BIG' : 'SMALL', 56 + Math.abs(post - 0.5) * 60, `posterior ${(post * 100).toFixed(1)}%`);
  }

  /* 8 — Simple moving average */
  {
    const w = nums.slice(0, 10);
    const avg = w.length ? w.reduce((a, b) => a + b, 0) / w.length : 4.5;
    push(7, avg >= 4.5 ? 'BIG' : 'SMALL', 55 + Math.abs(avg - 4.5) * 14, `SMA ${avg.toFixed(2)}`);
  }

  /* 9 — Fibonacci weighting */
  {
    const fib = [1, 1, 2, 3, 5, 8, 13, 21];
    let acc = 0, wsum = 0;
    nums.slice(0, 8).forEach((n, i) => { acc += n * fib[i]; wsum += fib[i]; });
    const v = wsum ? acc / wsum : 4.5;
    push(8, v >= 4.5 ? 'BIG' : 'SMALL', 54 + Math.abs(v - 4.5) * 12, `fib ${v.toFixed(2)}`);
  }

  /* 10 — Golden ratio modulo */
  {
    const seed = nums.slice(0, 5).reduce((a, b, i) => a + b * (i + 1), 0);
    const v = Math.floor((seed * 1.61803398875) % 10);
    push(9, getSize(v), 56, `φ·seed mod10 → ${v}`);
  }

  /* 11 — Tri-state joint (parity + size + period) */
  {
    const p = parseInt(String(period).slice(-2), 10) || 0;
    let sc = 0;
    if (nums[0] % 2 === 0) sc++; else sc--;
    if (sizes[0] === 'B') sc++;
    if ((p + nums[0]) % 2 === 0) sc++;
    push(10, sc >= 0 ? 'BIG' : 'SMALL', 55 + Math.abs(sc) * 7, `tri-state score ${sc}`);
  }

  /* 12 — Run-length harmonic */
  {
    const groups = [];
    sizes.forEach((s) => {
      const last = groups[groups.length - 1];
      if (last && last.s === s) last.len++;
      else groups.push({ s, len: 1 });
    });
    const avg = groups.length ? groups.reduce((a, g) => a + g.len, 0) / groups.length : 2;
    const size = groups[0] && groups[0].len > avg ? opposite(sizes[0]) : sizes[0];
    push(11, size, 56 + Math.abs(avg - 2) * 6, `avg run ${avg.toFixed(2)}`);
  }

  /* 13 — Poisson deficit */
  {
    const n = Math.min(nums.length, 30);
    const expected = n * 0.5;
    const actual = nums.slice(0, n).filter((x) => x >= 5).length;
    push(12, actual < expected ? 'BIG' : 'SMALL', 54 + Math.abs(actual - expected) * 2.5, `exp ${expected} vs ${actual}`);
  }

  /* 14 — Shannon entropy of sizes */
  {
    const n = Math.min(sizes.length, 20);
    const b = sizes.slice(0, n).filter((s) => s === 'B').length;
    const p = n ? b / n : 0.5;
    const H = p === 0 || p === 1 ? 0 : -(p * Math.log2(p) + (1 - p) * Math.log2(1 - p));
    push(13, H < 0.8 ? (p > 0.5 ? 'SMALL' : 'BIG') : (p >= 0.5 ? 'BIG' : 'SMALL'), 52 + (1 - H) * 30, `size-H ${H.toFixed(2)}`);
  }

  /* 15 — Fisher information slope */
  {
    const a = bigRate(nums, 5), b = bigRate(nums, 20);
    const slope = a - b;
    push(14, slope >= 0 ? 'BIG' : 'SMALL', 57 + Math.abs(slope) * 45, `slope ${slope.toFixed(2)}`);
  }

  return votes;
}

/* ───────────────────────── trend fallback ───────────────────────── */
export function trendEngine(nums) {
  const sizes = nums.map(sideChar);
  updateModel(nums);
  const asSize = (c) => (c === 'B' ? 'BIG' : 'SMALL');
  if (sizes.length < 2) {
    const p = generatePairs('BIG', nums);
    return { size: 'BIG', conf: 88, name: 'TREND INIT', detail: 'Warm-up', ...p };
  }
  let streakSize = sizes[0], streakLen = 1;
  for (let i = 1; i < sizes.length; i++) {
    if (sizes[i] === streakSize) streakLen++;
    else break;
  }
  if (streakLen >= 2) {
    const pairs = generatePairs(asSize(streakSize), nums);
    return {
      size: asSize(streakSize),
      conf: Math.min(95, 82 + streakLen * 3),
      name: 'STREAK CONTINUE ×' + streakLen,
      detail: asSize(streakSize) + ' ×' + streakLen + ' → CONTINUE',
      ...pairs
    };
  }
  const row = modelState.transitions[nums[0]] || Array(10).fill(0);
  const bigSum = row.slice(5).reduce((a, b) => a + b, 0);
  const smallSum = row.slice(0, 5).reduce((a, b) => a + b, 0);
  const size = bigSum >= smallSum ? 'BIG' : 'SMALL';
  const pairs = generatePairs(size, nums);
  return { size, conf: 86, name: 'MARKOV CORE', detail: 'TRANSITION → ' + size, ...pairs };
}

/* ───────────────────────── MASTER ───────────────────────── */
export function masterPrediction(period, numsNewestFirst, opts = {}) {
  const nums = (numsNewestFirst || []).slice(0, 100).map((n) => parseInt(n, 10)).filter((n) => !isNaN(n));
  const sides = nums.map(sideChar);
  const disabled = opts.disabledPatterns || [];
  const minConf = opts.minConfidence ?? 0;

  updateModel(nums);

  const allMatches = detectAllMatches(sides, disabled);
  const core = bunnyCoreMath(nums, period);
  if (core && !opts.disableCoreMath) allMatches.push(core);

  allMatches.sort((a, b) => b.pri - a.pri || b.conf - a.conf);

  const sigBest = allMatches.find((m) => m.src === 'SIG') || null;
  const cfmBest = allMatches.find((m) => m.src === 'CFM') || null;
  const coreBest = allMatches.find((m) => m.src === 'BNY') || null;
  const best = allMatches[0];

  let votes = [];
  try {
    votes = consensusVotes(nums, sides, period);
  } catch { votes = []; }

  const bigWeight = votes.filter((v) => v.size === 'BIG').reduce((a, v) => a + v.conf, 0);
  const smallWeight = votes.filter((v) => v.size === 'SMALL').reduce((a, v) => a + v.conf, 0);
  const totalWeight = bigWeight + smallWeight || 1;
  const consensusSize = bigWeight === smallWeight ? null : bigWeight > smallWeight ? 'BIG' : 'SMALL';
  const consensusShare = Math.round((Math.max(bigWeight, smallWeight) / totalWeight) * 100);

  let finalSize, patternName, patternDetail, source, confidence, priority, patternId, seq = '';

  if (best) {
    finalSize = best.size;
    patternName = best.name;
    patternDetail = best.detail;
    source = best.src;
    confidence = best.conf;
    priority = best.pri;
    patternId = best.id;
    seq = best.seq;

    /* consensus arbitration: a weak pattern cannot overrule a strong vote */
    if (consensusSize && consensusSize !== finalSize && confidence < 92 && consensusShare >= 68) {
      finalSize = consensusSize;
      patternName = `${best.name} ⚔ CONSENSUS OVERRIDE`;
      patternDetail = `${best.detail} · ${consensusShare}% voters disagreed → ${consensusSize}`;
      confidence = Math.round(Math.min(confidence + 3, consensusShare));
      source = 'CONSENSUS';
    }
  } else {
    const t = trendEngine(nums);
    finalSize = t.size;
    patternName = t.name;
    patternDetail = t.detail;
    source = 'TREND';
    confidence = t.conf;
    priority = 0;
    patternId = 'TREND-FALLBACK';
    seq = sides.slice(0, 8).join('');
  }

  /* confidence blend with consensus agreement */
  if (consensusSize === finalSize) confidence = Math.min(99, confidence + Math.round((consensusShare - 50) / 6));
  else confidence = Math.max(50, confidence - 2);


  const pairs = generatePairs(finalSize, nums);

  const crossCheck =
    sigBest && cfmBest
      ? sigBest.size === cfmBest.size ? 'AGREE' : 'CONFLICT'
      : coreBest && best && coreBest.size === best.size ? 'TRIPLE AGREE'
      : 'SINGLE';

  const confidenceFinal = clamp(Math.round(confidence), 50, 99);

  return {
    qualified: confidenceFinal >= (minConf || 0),
    size: finalSize,
    numbers: pairs.numbers,
    favNum: pairs.favNum,
    oppNum: pairs.oppNum,
    confidence: confidenceFinal,
    pattern: { id: patternId, name: patternName, detail: patternDetail, priority, src: source },
    patternName,
    patternDetail,
    source,
    crossCheck,
    seq: seq || sides.slice(0, 8).join(''),
    levels: { current: 1, multiplier: '1X', status: 'LEVEL 1 (1X)' },
    votes: {
      big: votes.filter((v) => v.size === 'BIG').length,
      small: votes.filter((v) => v.size === 'SMALL').length,
      share: consensusShare,
      size: consensusSize,
      list: votes
    },
    matches: allMatches.slice(0, 6),
    matchCount: allMatches.length,
    lockedAt: Date.now()
  };
}

/* ───────────────────────── result resolution ───────────────────────── */
export function resolveOutcome(pred, number) {
  const size = getSize(number);
  const jackpot = pred && (number === pred.favNum || number === pred.oppNum);
  if (jackpot) return { outcome: 'JACKPOT', size, win: true };
  if (pred && pred.size === size) return { outcome: 'WIN', size, win: true };
  return { outcome: 'LOSS', size, win: false };
}

export function levelFor(lossStreak) {
  if (lossStreak >= 2) return { current: 3, multiplier: '8X', status: 'LEVEL 3 (8X)' };
  if (lossStreak === 1) return { current: 2, multiplier: '3X', status: 'LEVEL 2 (3X)' };
  return { current: 1, multiplier: '1X', status: 'LEVEL 1 (1X)' };
}
