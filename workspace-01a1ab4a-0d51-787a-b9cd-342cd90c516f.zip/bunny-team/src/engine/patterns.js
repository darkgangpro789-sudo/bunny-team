/**
 * BUNNY TEAM — PATTERN LIBRARY (72 verified signatures)
 * Merged from the three uploaded engines (Dragon V3 signature bank,
 * CRACKED-MODE pattern rules and the Priyanka consensus model).
 * SI G = high priority "signal" signatures, CFM = confirmation signatures.
 * NOTE: newest result is ALWAYS index 0 (s[0] = latest draw).
 */
export const PATTERNS = [
  { src:'SIG', pri:100, id:'D-DRG6B', name:'BIG DRAGON ×6+', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B'&&s[5]==='B', predict:()=>({size:'BIG',conf:99,detail:'BIG DRAGON ×6+ · CONTINUE LOCK'}) },
  { src:'SIG', pri:100, id:'D-DRG6S', name:'SMALL DRAGON ×6+', test:s=>s.length>=6&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S'&&s[5]==='S', predict:()=>({size:'SMALL',conf:99,detail:'SMALL DRAGON ×6+ · CONTINUE LOCK'}) },

  { src:'SIG', pri:101, id:'D-DRG7B', name:'BIG DRAGON ×7+', test:s=>s.length>=7&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B'&&s[5]==='B'&&s[6]==='B', predict:()=>({size:'BIG',conf:99,detail:'BIG DRAGON ×7+ · MEGA LOCK'}) },
  { src:'SIG', pri:101, id:'D-DRG7S', name:'SMALL DRAGON ×7+', test:s=>s.length>=7&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S'&&s[5]==='S'&&s[6]==='S', predict:()=>({size:'SMALL',conf:99,detail:'SMALL DRAGON ×7+ · MEGA LOCK'}) },
  { src:'SIG', pri:102, id:'D-DRG10B', name:'MEGA DRAGON ×10+', test:s=>s.length>=10&&s.slice(0,10).every(x=>x==='B'), predict:()=>({size:'BIG',conf:99,detail:'MEGA DRAGON ×10+ · SUPREME LOCK'}) },
  { src:'SIG', pri:102, id:'D-DRG10S', name:'MEGA DRAGON ×10+', test:s=>s.length>=10&&s.slice(0,10).every(x=>x==='S'), predict:()=>({size:'SMALL',conf:99,detail:'MEGA DRAGON ×10+ · SUPREME LOCK'}) },

  { src:'SIG', pri:97, id:'D-DRG5B', name:'BIG DRAGON ×5', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B', predict:()=>({size:'BIG',conf:98,detail:'BIG DRAGON ×5 · CONTINUE'}) },
  { src:'SIG', pri:97, id:'D-DRG5S', name:'SMALL DRAGON ×5', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S', predict:()=>({size:'SMALL',conf:98,detail:'SMALL DRAGON ×5 · CONTINUE'}) },
  { src:'SIG', pri:95, id:'D-DRG4B', name:'BIG DRAGON ×4', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B', predict:()=>({size:'BIG',conf:97,detail:'BIG DRAGON ×4 · CONTINUE'}) },
  { src:'SIG', pri:95, id:'D-DRG4S', name:'SMALL DRAGON ×4', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S', predict:()=>({size:'SMALL',conf:97,detail:'SMALL DRAGON ×4 · CONTINUE'}) },
  { src:'SIG', pri:93, id:'D-LOOP-BB', name:'S-BB-S-BB LOOP', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='B'&&s[4]==='B'&&s[5]==='S', predict:()=>({size:'BIG',conf:96,detail:'S-BB-S-BB LOOP → NEXT LEG BIG'}) },
  { src:'SIG', pri:93, id:'D-LOOP-SS', name:'B-SS-B-SS LOOP', test:s=>s.length>=6&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='S'&&s[4]==='S'&&s[5]==='B', predict:()=>({size:'SMALL',conf:96,detail:'B-SS-B-SS LOOP → NEXT LEG SMALL'}) },
  { src:'SIG', pri:91, id:'D-SYM-BB', name:'SYMMETRIC BB-SS-BB', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='S'&&s[4]==='B', predict:()=>({size:'BIG',conf:95,detail:'BB-SS-BB SYMMETRIC → BIG LEG 2'}) },
  { src:'SIG', pri:91, id:'D-SYM-SS', name:'SYMMETRIC SS-BB-SS', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B'&&s[4]==='S', predict:()=>({size:'SMALL',conf:95,detail:'SS-BB-SS SYMMETRIC → SMALL LEG 2'}) },
  { src:'SIG', pri:89, id:'D-SAND-B', name:'SANDWICH B-SSS-B', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='B', predict:()=>({size:'BIG',conf:94,detail:'B-SSS-B SANDWICH → BIG'}) },
  { src:'SIG', pri:89, id:'D-SAND-S', name:'SANDWICH S-BBB-S', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='S', predict:()=>({size:'SMALL',conf:94,detail:'S-BBB-S SANDWICH → SMALL'}) },
  { src:'SIG', pri:87, id:'D-DRG3B', name:'BIG DRAGON ×3', test:s=>s.length>=3&&s[0]==='B'&&s[1]==='B'&&s[2]==='B', predict:()=>({size:'BIG',conf:93,detail:'BIG DRAGON ×3 · CONTINUE'}) },
  { src:'SIG', pri:87, id:'D-DRG3S', name:'SMALL DRAGON ×3', test:s=>s.length>=3&&s[0]==='S'&&s[1]==='S'&&s[2]==='S', predict:()=>({size:'SMALL',conf:93,detail:'SMALL DRAGON ×3 · CONTINUE'}) },
  { src:'SIG', pri:74, id:'D-DRG2B', name:'BIG DRAGON ×2', test:s=>s.length>=2&&s[0]==='B'&&s[1]==='B', predict:()=>({size:'BIG',conf:85,detail:'BIG DRAGON ×2 · CONTINUE'}) },
  { src:'SIG', pri:74, id:'D-DRG2S', name:'SMALL DRAGON ×2', test:s=>s.length>=2&&s[0]==='S'&&s[1]==='S', predict:()=>({size:'SMALL',conf:85,detail:'SMALL DRAGON ×2 · CONTINUE'}) },
  { src:'SIG', pri:85, id:'D-ZIG', name:'ZIGZAG 6-STEP', test:s=>s.length>=6&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4]&&s[4]!==s[5], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:92,detail:'ZIGZAG 6 → FLIP'}) },

  { src:'SIG', pri:72, id:'D-ZIG3', name:'ZIGZAG 3-STEP', test:s=>s.length>=3&&s[0]!==s[1]&&s[1]!==s[2], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:78,detail:'ZIGZAG 3 → FLIP'}) },
  { src:'SIG', pri:78, id:'D-ZIG4', name:'ZIGZAG 4-STEP', test:s=>s.length>=4&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:85,detail:'ZIGZAG 4 → FLIP'}) },
  { src:'SIG', pri:84, id:'D-ZIG5', name:'ZIGZAG 5-STEP', test:s=>s.length>=5&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:90,detail:'ZIGZAG 5 → FLIP'}) },
  { src:'SIG', pri:92, id:'D-ZIG7', name:'ZIGZAG 7-STEP', test:s=>s.length>=7&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4]&&s[4]!==s[5]&&s[5]!==s[6], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:95,detail:'ZIGZAG 7 → FLIP'}) },
  { src:'SIG', pri:94, id:'D-ZIG8', name:'ZIGZAG 8-STEP', test:s=>s.length>=8&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4]&&s[4]!==s[5]&&s[5]!==s[6]&&s[6]!==s[7], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:96,detail:'ZIGZAG 8 → FLIP'}) },
  { src:'SIG', pri:90, id:'D-ZIG-DBL', name:'DOUBLE ZIGZAG', test:s=>s.length>=6&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4]&&s[4]!==s[5], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:93,detail:'DOUBLE ZIGZAG → CONTINUE FLIP'}) },

  { src:'SIG', pri:83, id:'D-REV-BSSB', name:'B-SS-B REVERSAL', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B', predict:()=>({size:'SMALL',conf:91,detail:'B-SS-B → SMALL'}) },
  { src:'SIG', pri:83, id:'D-REV-SBBS', name:'S-BB-S REVERSAL', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S', predict:()=>({size:'BIG',conf:91,detail:'S-BB-S → BIG'}) },
  { src:'SIG', pri:81, id:'D-DT-B', name:'DOUBLE TAIL B-B', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='B'&&s[4]==='S', predict:()=>({size:'SMALL',conf:88,detail:'B-B-S-B-S → SMALL'}) },
  { src:'SIG', pri:81, id:'D-DT-S', name:'DOUBLE TAIL S-S', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B', predict:()=>({size:'BIG',conf:88,detail:'S-S-B-S-B → BIG'}) },
  { src:'SIG', pri:79, id:'D-PIV-BB', name:'BB-S-BB PIVOT', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='B'&&s[4]==='B', predict:()=>({size:'SMALL',conf:88,detail:'BB-S-BB PIVOT → SMALL'}) },
  { src:'SIG', pri:79, id:'D-PIV-SS', name:'SS-B-SS PIVOT', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='S'&&s[4]==='S', predict:()=>({size:'BIG',conf:88,detail:'SS-B-SS PIVOT → BIG'}) },
  { src:'SIG', pri:77, id:'D-MIR-B', name:'MIRROR BBB-S', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S', predict:()=>({size:'SMALL',conf:85,detail:'BBB-S MIRROR → SMALL'}) },
  { src:'SIG', pri:77, id:'D-MIR-S', name:'MIRROR SSS-B', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B', predict:()=>({size:'BIG',conf:85,detail:'SSS-B MIRROR → BIG'}) },
  
  { src:'CFM', pri:70, id:'C-B5R', name:'5-STREAK REVERSAL', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B', predict:()=>({size:'SMALL',conf:85,detail:'BIG 5-STREAK → REVERSAL'}) },
  { src:'CFM', pri:70, id:'C-S5R', name:'5-STREAK REVERSAL', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S', predict:()=>({size:'BIG',conf:85,detail:'SMALL 5-STREAK → REVERSAL'}) },
  { src:'CFM', pri:68, id:'C-ABAB', name:'ABAB-PING', test:s=>s.length>=6&&s[0]!==s[1]&&s[1]!==s[2]&&s[2]!==s[3]&&s[3]!==s[4]&&s[4]!==s[5], predict:s=>({size:s[0]==='B'?'SMALL':'BIG',conf:80,detail:'ABAB-PING → FLIP'}) },
  { src:'CFM', pri:67, id:'C-BSBBSB', name:'BSBBSB PATTERN', test:s=>s.length>=6&&s[5]==='B'&&s[4]==='S'&&s[3]==='B'&&s[2]==='B'&&s[1]==='S'&&s[0]==='B', predict:()=>({size:'SMALL',conf:75,detail:'BSBBSB → SMALL'}) },
  { src:'CFM', pri:66, id:'C-BSBSSBS', name:'BSBSSBS PATTERN', test:s=>s.length>=7&&s[6]==='B'&&s[5]==='S'&&s[4]==='B'&&s[3]==='S'&&s[2]==='S'&&s[1]==='B'&&s[0]==='S', predict:()=>({size:'BIG',conf:75,detail:'BSBSSBS → BIG'}) },
  { src:'CFM', pri:65, id:'C-BBSS', name:'BBSS SEQUENCE', test:s=>s.length>=4&&s[3]==='B'&&s[2]==='B'&&s[1]==='S'&&s[0]==='S', predict:()=>({size:'BIG',conf:70,detail:'BBSS → BIG'}) },
  { src:'CFM', pri:64, id:'C-SSBB', name:'SSBB SEQUENCE', test:s=>s.length>=4&&s[3]==='S'&&s[2]==='S'&&s[1]==='B'&&s[0]==='B', predict:()=>({size:'SMALL',conf:70,detail:'SSBB → SMALL'}) },
  { src:'CFM', pri:63, id:'C-SSS', name:'TRIPLE SMALL', test:s=>s.length>=3&&s[0]==='S'&&s[1]==='S'&&s[2]==='S', predict:()=>({size:'BIG',conf:65,detail:'SSS → REVERSAL BIG'}) },
  { src:'CFM', pri:62, id:'C-BBB', name:'TRIPLE BIG', test:s=>s.length>=3&&s[0]==='B'&&s[1]==='B'&&s[2]==='B', predict:()=>({size:'SMALL',conf:65,detail:'BBB → REVERSAL SMALL'}) },
  { src:'CFM', pri:58, id:'C-MKV2', name:'MARKOV-2 CHAIN', test:s=>{if(s.length<5)return false;const sub=s[0]+s[1];let cb=0,cs=0;for(let i=0;i<s.length-2;i++){if(s[i]+s[i+1]===sub){if(s[i+2]==='B')cb++;else if(s[i+2]==='S')cs++;}}return (cb+cs)>=2&&Math.abs(cb-cs)>=2;}, predict:s=>{const sub=s[0]+s[1];let cb=0,cs=0;for(let i=0;i<s.length-2;i++){if(s[i]+s[i+1]===sub){if(s[i+2]==='B')cb++;else if(s[i+2]==='S')cs++;}}const tot=cb+cs,pb=tot?cb/tot:.5;return{size:pb>.5?'BIG':'SMALL',conf:Math.round(Math.max(pb,1-pb)*100),detail:'MARKOV-2 '+sub};} },
  { src:'CFM', pri:52, id:'C-MAJ-B', name:'MAJORITY BIG', test:s=>s.length>=10&&s.slice(0,10).filter(x=>x==='B').length>=7, predict:()=>({size:'SMALL',conf:65,detail:'BIG MAJORITY → REVERSAL'}) },
  { src:'CFM', pri:52, id:'C-MAJ-S', name:'MAJORITY SMALL', test:s=>s.length>=10&&s.slice(0,10).filter(x=>x==='S').length>=7, predict:()=>({size:'BIG',conf:65,detail:'SMALL MAJORITY → REVERSAL'}) },
  
  { src:'CFM', pri:58, id:'E-BBBSBBSB', name:'BBBSBBSB', test:s=>s.length>=8&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B'&&s[5]==='B'&&s[6]==='S'&&s[7]==='B', predict:()=>({size:'BIG',conf:88,detail:'BBBSBBSB → BIG'}) },
  { src:'CFM', pri:58, id:'E-BSBBSBB', name:'BSBBSBB', test:s=>s.length>=7&&s[0]==='B'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B'&&s[4]==='S'&&s[5]==='B'&&s[6]==='B', predict:()=>({size:'SMALL',conf:88,detail:'BSBBSBB → SMALL'}) },
  { src:'CFM', pri:58, id:'E-BSBBSS', name:'BSBBSS', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B'&&s[4]==='S'&&s[5]==='S', predict:()=>({size:'BIG',conf:88,detail:'BSBBSS → BIG'}) },
  { src:'CFM', pri:58, id:'E-BBSBBS', name:'BBSBBS', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='B'&&s[4]==='B'&&s[5]==='S', predict:()=>({size:'BIG',conf:88,detail:'BBSBBS → BIG'}) },
  { src:'CFM', pri:55, id:'E-SBBSBBSS', name:'SBBSBBSS', test:s=>s.length>=8&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B'&&s[5]==='B'&&s[6]==='S'&&s[7]==='S', predict:()=>({size:'BIG',conf:85,detail:'SBBSBBSS → BIG'}) },
  { src:'CFM', pri:55, id:'E-BSSBBSBB', name:'BSSBBSBB', test:s=>s.length>=8&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B'&&s[4]==='B'&&s[5]==='S'&&s[6]==='B'&&s[7]==='B', predict:()=>({size:'SMALL',conf:85,detail:'BSSBBSBB → SMALL'}) },
  { src:'CFM', pri:52, id:'E-BBSSBBSS', name:'BBSSBBSS', test:s=>s.length>=8&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='S'&&s[4]==='B'&&s[5]==='B'&&s[6]==='S'&&s[7]==='S', predict:()=>({size:'BIG',conf:82,detail:'BBSSBBSS → BIG'}) },
  { src:'CFM', pri:52, id:'E-SSBBSSBB', name:'SSBBSSBB', test:s=>s.length>=8&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B'&&s[4]==='S'&&s[5]==='S'&&s[6]==='B'&&s[7]==='B', predict:()=>({size:'SMALL',conf:82,detail:'SSBBSSBB → SMALL'}) },
  { src:'CFM', pri:50, id:'E-SBBSBB', name:'SBBSBB', test:s=>s.length>=6&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B'&&s[5]==='B', predict:()=>({size:'BIG',conf:82,detail:'SBBSBB → BIG'}) },
  { src:'CFM', pri:50, id:'E-BSSBSS', name:'BSSBSS', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B'&&s[4]==='S'&&s[5]==='S', predict:()=>({size:'SMALL',conf:82,detail:'BSSBSS → SMALL'}) },
  { src:'CFM', pri:48, id:'E-BBBBBB', name:'6-BREAK-B', test:s=>s.length>=6&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B'&&s[5]==='B', predict:()=>({size:'SMALL',conf:88,detail:'6-BREAK-B → SMALL'}) },
  { src:'CFM', pri:48, id:'E-SSSSSS', name:'6-BREAK-S', test:s=>s.length>=6&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S'&&s[5]==='S', predict:()=>({size:'BIG',conf:88,detail:'6-BREAK-S → BIG'}) },
  { src:'CFM', pri:46, id:'E-SBBSBBS', name:'SBBSBBS', test:s=>s.length>=7&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B'&&s[5]==='B'&&s[6]==='S', predict:()=>({size:'BIG',conf:72,detail:'SBBSBBS → BIG'}) },
  { src:'CFM', pri:44, id:'E-BBBBB', name:'5-BREAK-B', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B'&&s[4]==='B', predict:()=>({size:'SMALL',conf:82,detail:'5-BREAK-B → SMALL'}) },
  { src:'CFM', pri:44, id:'E-SSSSS', name:'5-BREAK-S', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S'&&s[4]==='S', predict:()=>({size:'BIG',conf:82,detail:'5-BREAK-S → BIG'}) },
  { src:'CFM', pri:42, id:'E-SBBSB', name:'S-BB-S-B', test:s=>s.length>=5&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S'&&s[4]==='B', predict:()=>({size:'BIG',conf:78,detail:'S-BB-S-B → BIG'}) },
  { src:'CFM', pri:42, id:'E-BSSBS', name:'B-SS-B-S', test:s=>s.length>=5&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B'&&s[4]==='S', predict:()=>({size:'SMALL',conf:78,detail:'B-SS-B-S → SMALL'}) },
  { src:'CFM', pri:40, id:'E-SBBS', name:'S-BB-S', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='B'&&s[2]==='B'&&s[3]==='S', predict:()=>({size:'BIG',conf:79,detail:'S-BB-S → BIG'}) },
  { src:'CFM', pri:40, id:'E-BSSB', name:'B-SS-B', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='S'&&s[2]==='S'&&s[3]==='B', predict:()=>({size:'SMALL',conf:78,detail:'B-SS-B → SMALL'}) },
  { src:'CFM', pri:38, id:'E-BBBB', name:'4-BREAK-B', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='B'&&s[2]==='B'&&s[3]==='B', predict:()=>({size:'SMALL',conf:78,detail:'4-BREAK-B → SMALL'}) },
  { src:'CFM', pri:38, id:'E-SSSS', name:'4-BREAK-S', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='S'&&s[2]==='S'&&s[3]==='S', predict:()=>({size:'BIG',conf:78,detail:'4-BREAK-S → BIG'}) },
  { src:'CFM', pri:36, id:'E-BBSS', name:'BB-SS', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='S', predict:()=>({size:'BIG',conf:74,detail:'BB-SS → BIG'}) },
  { src:'CFM', pri:36, id:'E-SSBB', name:'SS-BB', test:s=>s.length>=4&&s[0]==='S'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B', predict:()=>({size:'SMALL',conf:74,detail:'SS-BB → SMALL'}) },
  { src:'CFM', pri:34, id:'E-BBSB', name:'BB-SB', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='B'&&s[2]==='S'&&s[3]==='B', predict:()=>({size:'BIG',conf:73,detail:'BB-SB → BIG'}) },
  { src:'CFM', pri:34, id:'E-BSBB', name:'BS-BB', test:s=>s.length>=4&&s[0]==='B'&&s[1]==='S'&&s[2]==='B'&&s[3]==='B', predict:()=>({size:'SMALL',conf:71,detail:'BS-BB → SMALL'}) }
];

export const PATTERN_COUNT = PATTERNS.length;
