/**
 * BUNNY TEAM — draw feed.
 * Tries the official WinGo history endpoints (server side, with proxy fallback).
 * If the host is unreachable from the server's network, it degrades to a
 * deterministic synthetic feed so the product stays fully operable and testable.
 * Feed health is reported to the admin console (nothing is faked silently).
 */
import { config } from './config.js';
import { getCurrentPeriod, getTF, TF_LIST } from './engine/index.js';

const API_PATH = (tfId) => `/WinGo/WinGo_${tfId}/GetHistoryIssuePage.json?pageSize=50&pageNo=1`;

const normalise = (raw) => {
  const arr = raw && raw.data && raw.data.list ? raw.data.list : raw && raw.list ? raw.list : [];
  if (!Array.isArray(arr)) return [];
  return arr
    .map((it) => {
      const period = String(it.issueNumber || it.periodNumber || it.period || it.issue || '').replace(/\D/g, '');
      const nRaw = it.number ?? it.result ?? it.openNumber ?? it.premium;
      const number = parseInt(nRaw, 10);
      if (!period || !Number.isInteger(number) || number < 0 || number > 9) return null;
      return { period, number };
    })
    .filter(Boolean)
    .sort((a, b) => (a.period < b.period ? 1 : a.period > b.period ? -1 : 0));
};

async function tryJson(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), config.feedTimeout);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      cache: 'no-store',
      headers: {
        Accept: 'application/json, text/plain, */*',
        'User-Agent':
          'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Mobile Safari/537.36',
        Referer: config.feedBase + '/',
        Origin: config.feedBase
      }
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (!text.trim().startsWith('{') && !text.trim().startsWith('[')) return null;
    return JSON.parse(text);
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

const hash32 = (str) => {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
};

/** deterministic per-period pseudo draw (stable across restarts & clients) */
function syntheticList(tf, time = Date.now()) {
  const out = [];
  // latest drawn period = the one that just closed
  const current = getCurrentPeriod(tf, time - tf.seconds * 1000);
  let period = current;
  for (let i = 0; i < 50; i++) {
    const h = hash32(period + '|' + tf.id + '|bunny');
    out.push({ period, number: h % 10 });
    // walk backwards through the period sequence
    const head = period.slice(0, -4);
    let tail = parseInt(period.slice(-4), 10) - 1;
    if (tail < 1) break;
    period = head + String(tail).padStart(4, '0');
  }
  return out;
}

export async function fetchHistory(tfId) {
  const tf = getTF(tfId);
  const path = API_PATH(tf.id);
  const direct = config.feedBase.replace(/\/+$/, '') + path;

  const urls = [direct];
  if (config.feedProxy) {
    urls.push(config.feedProxy.includes('{url}')
      ? config.feedProxy.replace('{url}', encodeURIComponent(direct))
      : config.feedProxy + encodeURIComponent(direct));
  }

  for (const url of urls) {
    const json = await tryJson(url);
    const list = normalise(json);
    if (list.length >= 3) return { list, mode: 'live', source: direct };
  }

  if (!config.allowSyntheticFeed) return { list: [], mode: 'offline', source: direct };
  return { list: syntheticList(tf), mode: 'synthetic', source: 'local-deterministic' };
}

export const ALL_TFS = TF_LIST;
