/**
 * BUNNY TEAM — server entry point
 * • serves the premium client (never the engine)
 * • exposes a token-guarded API
 * • serves the hidden admin console ONLY on ADMIN_PATH
 */
import express from 'express';
import compression from 'compression';
import path from 'node:path';
import fs from 'node:fs';
import { config, ROOT, assertConfig } from './config.js';
import { createStore } from './store/index.js';
import { verifyToken } from './auth.js';
import { LiveEngine } from './live.js';
import { publicRoutes, TF_META } from './routes/public.js';
import { adminRoutes } from './routes/admin.js';

const PUBLIC_DIR = path.join(ROOT, 'public');

const app = express();
app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', 1);
app.use(compression());
app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));

/* ── security headers ── */
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob:",
      "font-src 'self' data:",
      "connect-src 'self'",
      "media-src 'self' blob:",
      "frame-ancestors *",
      "base-uri 'self'",
      "form-action 'self'"
    ].join('; ')
  );
  next();
});

const boot = await (async () => {
  const { store, mode, sessionSecret, settings } = await createStore();
  const live = new LiveEngine({ store, settings });
  await live.init();
  live.start();
  return { store, mode, sessionSecret, settings, live };
})();

app.locals.ctx = boot;
const ctx = { store: boot.store, live: boot.live, sessionSecret: boot.sessionSecret, mode: boot.mode };

/* ── token parsing ── */
app.use((req, res, next) => {
  const hdr = req.headers.authorization || '';
  const tok = hdr.startsWith('Bearer ') ? hdr.slice(7).trim() : '';
  if (tok) {
    const payload = verifyToken(tok, boot.sessionSecret);
    if (payload) {
      if (payload.scope === 'user') req.user = payload;
      if (payload.scope === 'admin') req.admin = payload;
    }
  }
  /* owner key opens the console too */
  const adminKey = req.headers['x-admin-token'];
  if (adminKey && !req.admin) {
    const p = verifyToken(String(adminKey), boot.sessionSecret);
    if (p && p.scope === 'admin') req.admin = p;
  }
  next();
});

/* ── async handlers must never crash the process ── */
function autoCatch(router) {
  const wrap = (l) => {
    const h = l.handle;
    if (typeof h === 'function' && h.constructor && h.constructor.name === 'AsyncFunction') {
      l.handle = (req, res, next) => Promise.resolve(h(req, res, next)).catch(next);
    }
  };
  (router.stack || []).forEach((layer) => {
    if (layer.route && Array.isArray(layer.route.stack)) layer.route.stack.forEach(wrap);
  });
  return router;
}

/* ── api ── */
app.use('/api', autoCatch(publicRoutes(ctx)));
app.use('/api/sys', autoCatch(adminRoutes(ctx)));
app.use('/api', (req, res) => res.status(404).json({ ok: false, code: 'NOT_FOUND' }));

/* ── never expose the shell files directly (console lives on the secret path) ── */
app.use((req, res, next) => {
  const p = req.path.toLowerCase();
  if (p === '/console.html' || p === '/index.html' || p === '/console' || p === '/admin') {
    return res.status(404).send('Not found');
  }
  next();
});

/* ── static client assets only ── */
app.use(
  express.static(PUBLIC_DIR, {
    index: false,
    setHeaders: (res, p) => {
      if (/\.(js|css)$/.test(p)) res.setHeader('Cache-Control', 'public, max-age=300');
      if (p.endsWith('console.html')) res.setHeader('Cache-Control', 'no-store');
    }
  })
);

/* ── hidden admin console (secret path only) ── */
app.get(config.adminPath, (req, res) => {
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(PUBLIC_DIR, 'console.html'));
});
app.get(config.adminPath + '/*', (req, res) => {
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.sendFile(path.join(PUBLIC_DIR, 'console.html'));
});

/* ── app shell ── */
app.get('/', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

/* ── health (no data leak) ── */
app.get('/healthz', (req, res) => res.json({ ok: true, store: boot.mode, engine: boot.live.running }));

/* ── error handler (JSON, never leaks internals) ── */
app.use((err, req, res, next) => {
  console.error('[http]', req.method, req.originalUrl, '→', err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ ok: false, code: 'SERVER', message: 'Server hiccup — try again.' });
});

/* ── 404 ── */
app.use((req, res) => res.status(404).send('Not found'));

const server = app.listen(config.port, config.host, () => {
  const lines = [
    '',
    '  ╔══════════════════════════════════════════════════════╗',
    '  ║            🐰  B U N N Y   T E A M  🐰               ║',
    '  ║      premium prediction intelligence — online         ║',
    '  ╚══════════════════════════════════════════════════════╝',
    `   app        : http://${config.host}:${config.port}`,
    `   console    : http://${config.host}:${config.port}${config.adminPath}   (hidden)`,
    `   vault      : ${boot.mode}`,
    `   timeframes : ${TF_META.map((t) => t.id).join(' · ')}`,
    ''
  ];
  console.log(lines.join('\n'));
  assertConfig().forEach((w) => console.warn('  ⚠ ' + w));
});

const shutdown = async () => {
  boot.live.stop();
  await boot.store.close?.().catch(() => {});
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

/* keep the engine alive — log, never die on a stray promise */
process.on('unhandledRejection', (e) => console.error('[warn] unhandledRejection:', e && e.message ? e.message : e));
process.on('uncaughtException', (e) => console.error('[warn] uncaughtException:', e && e.message ? e.message : e));

export { app, boot };
