/**
 * BUNNY TEAM — LiveEngine
 * One server-side loop polls the draw feed, seals ONE prediction per period
 * (identical for every client), resolves it when the draw lands and keeps the
 * global scoreboard. Nothing about the engine is shipped to the browser.
 */
import { config } from './config.js';
import { fetchHistory } from './feed.js';
import {
  getTF, TF_LIST, getCurrentPeriod, nextPeriodOf, getCountdown,
  masterPrediction, resolveOutcome, levelFor, getSize
} from './engine/index.js';

const MAX_RESULTS = 240;
const MAX_PREDICTIONS = 60;

const colourOf = (n) => (n === 0 || n === 5 ? 'violet' : n % 2 === 0 ? 'red' : 'green');

export class LiveEngine {
  constructor({ store, settings }) {
    this.store = store;
    this.settings = settings;
    this.state = new Map();     // tf -> { buf: [], preds: Map, feed }
    this.timer = null;
    this.running = false;
    this.lastTickAt = 0;
    this._settingsAt = 0;
  }

  /* ─────────────────────── boot ─────────────────────── */
  async init() {
    for (const tf of TF_LIST) {
      const buf = [];
      const preds = new Map();
      try {
        const res = (await this.store.get(`results/${tf.id}`)) || {};
        Object.values(res)
          .map((r) => ({ ...r, size: r.size || getSize(r.number) }))
          .sort((a, b) => (a.period < b.period ? 1 : -1))
          .slice(0, MAX_RESULTS)
          .forEach((r) => buf.push(r));
      } catch { /* fresh node */ }
      try {
        const pr = (await this.store.get(`predictions/${tf.id}`)) || {};
        Object.entries(pr)
          .slice(-MAX_PREDICTIONS)
          .forEach(([period, p]) => preds.set(period, p));
      } catch { /* fresh node */ }
      this.state.set(tf.id, {
        buf,
        preds,
        feed: { mode: 'booting', at: 0, ok: 0, fail: 0, source: '' }
      });
    }
    setInterval(() => this.refreshSettings().catch(() => {}), 15000);
  }

  async refreshSettings() {
    if (Date.now() - this._settingsAt < 5000) return this.settings;
    const s = await this.store.get('settings');
    if (s) this.settings = s;
    this._settingsAt = Date.now();
    return this.settings;
  }

  enabledTimeframes() {
    const tfCfg = (this.settings && this.settings.timeframes) || {};
    return TF_LIST.filter((t) => tfCfg[t.id] !== false);
  }

  start() {
    if (this.running) return;
    this.running = true;
    const loop = async () => {
      if (!this.running) return;
      try {
        await this.tick();
      } catch (err) {
        console.error('[live] tick error:', err.message);
      }
      this.timer = setTimeout(loop, config.pollMs);
    };
    loop();
  }

  stop() {
    this.running = false;
    if (this.timer) clearTimeout(this.timer);
  }

  /* ─────────────────────── one pass ─────────────────────── */
  async tick() {
    this.lastTickAt = Date.now();
    for (const tf of this.enabledTimeframes()) {
      const st = this.state.get(tf.id);
      let feed;
      try {
        feed = await fetchHistory(tf.id);
      } catch {
        feed = { list: [], mode: 'error' };
      }
      st.feed = {
        mode: feed.mode,
        source: feed.source || '',
        at: Date.now(),
        ok: feed.mode === 'live' ? st.feed.ok + 1 : st.feed.ok,
        fail: feed.mode === 'live' ? 0 : st.feed.fail + 1
      };
      if (!feed.list || !feed.list.length) continue;

      /* index existing periods */
      const known = new Set(st.buf.map((r) => r.period));

      /* new draws, oldest first so level tracking stays correct */
      const fresh = feed.list.filter((it) => !known.has(it.period)).sort((a, b) =>
        a.period < b.period ? -1 : 1
      );

      if (fresh.length) {
        const writes = {};
        let wins = 0, losses = 0, jackpots = 0;

        for (const item of fresh) {
          const rec = {
            period: item.period,
            number: item.number,
            size: getSize(item.number),
            colour: colourOf(item.number),
            ts: Date.now()
          };
          const pred = st.preds.get(item.period);
          if (pred && pred.size) {
            const res = resolveOutcome(pred, item.number);
            rec.predSize = pred.size;
            rec.predNumbers = pred.numbers;
            rec.outcome = res.outcome;
            rec.confidence = pred.confidence;
            rec.pattern = pred.patternName;
            if (res.outcome === 'JACKPOT') { jackpots++; wins++; }
            else if (res.outcome === 'WIN') wins++;
            else losses++;
            st.preds.set(item.period, { ...pred, outcome: res.outcome, resolvedAt: Date.now() });
            await this.store.update(`predictions/${tf.id}/${item.period}`, {
              outcome: res.outcome,
              resolvedAt: rec.ts
            }).catch(() => {});
          }
          writes[item.period] = rec;
          st.buf.push(rec);
        }

        st.buf.sort((a, b) => (a.period < b.period ? 1 : -1));
        if (st.buf.length > MAX_RESULTS) st.buf.length = MAX_RESULTS;

        await this.store.update(`results/${tf.id}`, writes).catch((e) =>
          console.error('[live] results write', e.message)
        );

        if (wins || losses) {
          const stats = (await this.store.get('stats')) || { wins: 0, losses: 0, jackpots: 0, total: 0 };
          const next = {
            wins: (stats.wins || 0) + wins,
            losses: (stats.losses || 0) + losses,
            jackpots: (stats.jackpots || 0) + jackpots,
            total: (stats.total || 0) + wins + losses,
            resetAt: stats.resetAt || Date.now(),
            updatedAt: Date.now()
          };
          await this.store.set('stats', next).catch(() => {});
        }
        await this.prune(tf.id, st).catch(() => {});
      }

      /* seal prediction for the next period */
      const latest = st.buf[0];
      if (!latest) continue;
      const target = nextPeriodOf(latest.period);
      if (!st.preds.has(target) || !st.preds.get(target).size) {
        const nums = st.buf.slice(0, 60).map((r) => r.number);
        const cfg = (this.settings && this.settings.engine) || {};
        const pred = masterPrediction(target, nums, {
          disabledPatterns: cfg.disabledPatterns || [],
          minConfidence: cfg.minConfidence ?? 60,
          disableCoreMath: !!cfg.disableCoreMath
        });

        /* admin override ("force next result") */
        const force = (cfg.force && cfg.force[tf.id]) || null;
        if (force && force.size && (force.periods === 0 || force.periods > 0)) {
          pred.size = force.size;
          pred.numbers = force.size === 'BIG' ? [5, 6, 7, 8, 9] : [0, 1, 2, 3, 4];
          pred.favNum = force.size === 'BIG' ? 7 : 2;
          pred.oppNum = force.size === 'BIG' ? 2 : 7;
          pred.forced = true;
          pred.patternName = 'ADMIN LOCK · ' + force.size;
          pred.confidence = Math.max(pred.confidence, 95);
          const left = (force.periods || 1) - 1;
          if (left <= 0) {
            const fs = { ...cfg.force };
            delete fs[tf.id];
            await this.store.update('settings', { engine: { ...cfg, force: fs } }).catch(() => {});
            this.settings.engine = { ...cfg, force: fs };
          } else {
            const fs = { ...cfg.force, [tf.id]: { ...force, periods: left } };
            await this.store.update('settings', { engine: { ...cfg, force: fs } }).catch(() => {});
            this.settings.engine = { ...cfg, force: fs };
          }
        }

        const lossStreak = this.lossStreak(tf.id);
        pred.favNum = pred.favNum;
        pred.level = levelFor(lossStreak);
        pred.period = target;
        pred.tf = tf.id;
        pred.ts = Date.now();

        st.preds.set(target, pred);
        await this.store.set(`predictions/${tf.id}/${target}`, pred).catch((e) =>
          console.error('[live] prediction write', e.message)
        );
      }
    }
  }

  lossStreak(tfId) {
    const st = this.state.get(tfId);
    if (!st) return 0;
    let n = 0;
    for (const r of st.buf) {
      if (!r.outcome) break;
      if (r.outcome === 'LOSS') n++;
      else break;
    }
    return n;
  }

  async prune(tfId, st) {
    const keys = Object.keys((await this.store.get(`results/${tfId}`)) || {});
    if (keys.length <= MAX_RESULTS) return;
    const sorted = keys.sort();
    const excess = sorted.slice(0, keys.length - MAX_RESULTS);
    for (const k of excess) await this.store.remove(`results/${tfId}/${k}`).catch(() => {});
  }

  /* ─────────────────────── read side ─────────────────────── */
  snapshot(tfId, opts = {}) {
    const tf = getTF(tfId);
    const st = this.state.get(tf.id);
    const now = Date.now();
    const currentPeriod = getCurrentPeriod(tf, now);
    const buf = st ? st.buf : [];
    const latest = buf[0] || null;

    let target = latest ? nextPeriodOf(latest.period) : currentPeriod;
    let pred = st ? st.preds.get(target) || null : null;

    /* if the feed is behind the clock, roll the target forward */
    if (st && !pred && currentPeriod > target) {
      target = currentPeriod;
      pred = st.preds.get(target) || null;
    }

    const stats = this.computeStats(buf, opts.since || 0);

    const payload = {
      appName: this.settings.appName,
      tagline: this.settings.tagline,
      announcement: this.settings.announcementEnabled ? this.settings.announcement : '',
      maintenance: !!this.settings.maintenance,
      maintenanceMsg: this.settings.maintenanceMsg,
      serverTime: now,
      tf: { id: tf.id, label: tf.label, seconds: tf.seconds, emoji: tf.emoji },
      timeframes: TF_LIST.map((t) => ({
        id: t.id,
        label: t.label,
        short: t.id,
        emoji: t.emoji,
        enabled: (this.settings.timeframes || {})[t.id] !== false
      })),
      period: target,
      drawnPeriod: latest ? latest.period : null,
      countdown: getCountdown(tf, now),
      feed: {
        mode: st ? st.feed.mode : 'booting',
        health: st && st.feed.mode === 'live' ? 'LIVE' : 'SIMULATION',
        at: st ? st.feed.at : 0
      },
      results: buf.slice(0, 30).map((r) => ({
        period: r.period,
        number: r.number,
        size: r.size,
        colour: r.colour,
        predSize: r.predSize || null,
        outcome: r.outcome || null,
        ts: r.ts
      })),
      prediction: pred
        ? {
            period: pred.period,
            size: pred.size,
            numbers: pred.numbers,
            favNum: pred.favNum,
            oppNum: pred.oppNum,
            confidence: pred.confidence,
            qualified: pred.qualified !== false,
            patternName: pred.patternName,
            patternDetail: pred.patternDetail,
            source: pred.source,
            crossCheck: pred.crossCheck,
            matchCount: pred.matchCount || 0,
            matches: (pred.matches || []).map((m) => ({ name: m.name, size: m.size, conf: m.conf, pri: m.pri })),
            votes: pred.votes
              ? {
                  big: pred.votes.big,
                  small: pred.votes.small,
                  share: pred.votes.share,
                  size: pred.votes.size,
                  list: (pred.votes.list || []).map((v) => ({ name: v.name, size: v.size, conf: v.conf }))
                }
              : null,
            level: pred.level,
            lockedAt: pred.ts,
            outcome: pred.outcome || null
          }
        : null,
      stats,
      features: this.settings.features,
      sounds: { on: this.settings.soundsDefault, voice: this.settings.voiceDefault }
    };
    return payload;
  }

  computeStats(buf, since = 0) {
    const resolved = buf.filter((r) => r.outcome && (!since || r.ts >= since));
    const wins = resolved.filter((r) => r.outcome === 'WIN' || r.outcome === 'JACKPOT').length;
    const jackpots = resolved.filter((r) => r.outcome === 'JACKPOT').length;
    const losses = resolved.filter((r) => r.outcome === 'LOSS').length;
    const total = wins + losses;
    let streak = 0, type = 'NONE';
    for (const r of resolved) {
      if (r.outcome === 'LOSS') {
        streak = type === 'LOSS' ? streak + 1 : 1;
        type = 'LOSS';
      } else {
        streak = type === 'WIN' ? streak + 1 : 1;
        type = 'WIN';
      }
      break;
    }
    if (resolved.length > 1 && type !== 'NONE') {
      streak = 0;
      for (const r of resolved) {
        const t = r.outcome === 'LOSS' ? 'LOSS' : 'WIN';
        if (t !== type) break;
        streak++;
      }
    }
    return {
      wins, losses, jackpots, total,
      accuracy: total ? Math.round((wins / total) * 100) : 0,
      streak, streakType: type
    };
  }

  history(tfId, since = 0, limit = 60) {
    const tf = getTF(tfId);
    const st = this.state.get(tf.id);
    if (!st) return [];
    return st.buf
      .filter((r) => r.outcome && (!since || r.ts >= since))
      .slice(0, limit)
      .map((r) => ({
        period: r.period,
        number: r.number,
        size: r.size,
        colour: r.colour,
        predSize: r.predSize || null,
        predNumbers: r.predNumbers || null,
        outcome: r.outcome,
        confidence: r.confidence || null,
        pattern: r.pattern || null,
        ts: r.ts
      }));
  }

  feedHealth() {
    const out = {};
    for (const [id, st] of this.state) {
      out[id] = { mode: st.feed.mode, at: st.feed.at, source: st.feed.source, results: st.buf.length, predictions: st.preds.size };
    }
    return out;
  }
}
