import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { config } from '../config.js';
import {
  signToken, verifyPassword, hashPassword, randomKey, expiryFor, rateLimit, PLAN_HOURS
} from '../auth.js';
import { audit } from '../store/index.js';
import { PATTERNS } from '../engine/patterns.js';
import { TF_LIST, getTF, masterPrediction } from '../engine/index.js';

export function adminRoutes(ctx) {
  const { store, live, sessionSecret } = ctx;
  const r = express.Router();

  /* ───────── gate: ONE master key, nothing else ───────── */
  r.post('/auth', async (req, res) => {
    const ip = req.ip || 'x';
    if (!rateLimit('admin', ip, 8, 60_000)) {
      return res.status(429).json({ ok: false, message: 'Too many attempts. Cool down 60s.' });
    }
    const key = String(req.body?.key ?? req.body?.password ?? '').trim();
    if (!key) return res.status(400).json({ ok: false, message: 'Enter the master key.' });

    const rec = (await store.get('admin')) || {};
    const ok = verifyPassword(key, rec.passwordHash);
    if (!ok) {
      await audit(store, { kind: 'CONSOLE_KEY_FAIL', ip });
      return res.status(401).json({ ok: false, message: '❌ Wrong master key.' });
    }
    const token = signToken({ scope: 'admin', u: rec.label || config.adminLabel }, sessionSecret, config.adminSessionHours * 3600);
    await audit(store, { kind: 'CONSOLE_UNLOCK', ip });
    res.json({
      ok: true,
      token,
      label: rec.label || config.adminLabel,
      usingDefault: !!rec.defaultKey,
      hours: config.adminSessionHours
    });
  });

  /* everything below needs an admin token */
  r.use(async (req, res, next) => {
    if (!req.admin) return res.status(401).json({ ok: false, code: 'ADMIN_AUTH' });
    next();
  });

  /* ───────── dashboard ───────── */
  r.get('/overview', async (req, res) => {
    const [settings, keys, stats, audits, meta] = await Promise.all([
      store.get('settings'), store.get('keys'), store.get('stats'), store.get('audit'), store.get('meta')
    ]);
    const list = Object.values(keys || {});
    const now = Date.now();
    const active = list.filter((k) => !k.revoked && (!k.expiresAt || k.expiresAt > now));
    const expired = list.filter((k) => k.expiresAt && k.expiresAt <= now);
    const revoked = list.filter((k) => k.revoked);
    const online = list.filter((k) => k.lastSeen && now - k.lastSeen < 5 * 60 * 1000);
    res.json({
      ok: true,
      store: ctx.mode,
      feed: live.feedHealth(),
      engineLive: live.running,
      counts: {
        keys: list.length,
        active: active.length,
        expired: expired.length,
        revoked: revoked.length,
        online: online.length,
        patterns: PATTERNS.length
      },
      stats: stats || {},
      settings,
      audits: (audits || []).slice(0, 25),
      boot: { createdAt: meta?.createdAt || null, version: meta?.version || 3, node: process.version, uptime: Math.round(process.uptime()) }
    });
  });

  /* ───────── key generator ───────── */
  r.post('/keys/generate', async (req, res) => {
    const count = Math.min(50, Math.max(1, parseInt(req.body?.count || 1, 10)));
    const plan = String(req.body?.plan || '7D').toUpperCase();
    if (!(plan in PLAN_HOURS)) return res.status(400).json({ ok: false, message: 'Unknown plan.' });
    const prefix = String(req.body?.prefix || 'BT').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'BT';
    const note = String(req.body?.note || '').slice(0, 120);
    const maxDevices = Math.min(5, Math.max(1, parseInt(req.body?.maxDevices || 1, 10)));

    const created = [];
    const existing = (await store.get('keys')) || {};
    for (let i = 0; i < count; i++) {
      let key;
      do { key = randomKey(prefix); } while (existing[key]);
      const rec = {
        key, plan, note, maxDevices,
        createdAt: Date.now(),
        expiresAt: expiryFor(plan),
        revoked: false,
        used: false,
        logins: 0,
        devices: {},
        createdBy: req.admin.u || 'admin'
      };
      existing[key] = rec;
      created.push(rec);
    }
    await store.set('keys', existing);
    await audit(store, { kind: 'KEYS_GENERATED', by: req.admin.u, count, plan, keys: created.map((c) => c.key) });
    res.json({ ok: true, created });
  });

  r.get('/keys', async (req, res) => {
    const keys = (await store.get('keys')) || {};
    const now = Date.now();
    const q = String(req.query.q || '').trim().toUpperCase();
    const filter = String(req.query.status || 'all').toUpperCase();
    const list = Object.entries(keys)
      .filter(([k, v]) => (!q || k.includes(q) || (v.note || '').toUpperCase().includes(q)))
      .map(([k, v]) => ({
        ...v,
        key: k,
        status: v.revoked ? 'REVOKED' : v.expiresAt && v.expiresAt <= now ? 'EXPIRED' : v.used ? 'IN USE' : 'UNUSED',
        online: v.lastSeen && now - v.lastSeen < 5 * 60 * 1000,
        devicesCount: Object.keys(v.devices || {}).length
      }))
      .filter((k) => filter === 'ALL' || k.status === filter)
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, total: list.length, keys: list.slice(0, 500) });
  });

  r.post('/keys/:key/action', async (req, res) => {
    const key = String(req.params.key || '').toUpperCase();
    const action = String(req.body?.action || '');
    const rec = await store.get(`keys/${key}`);
    if (!rec) return res.status(404).json({ ok: false, message: 'Key not found.' });

    switch (action) {
      case 'revoke':  await store.update(`keys/${key}`, { revoked: true, revokedAt: Date.now() }); break;
      case 'unrevoke': await store.update(`keys/${key}`, { revoked: false, revokedAt: null }); break;
      case 'extend': {
        const plan = String(req.body?.plan || '7D').toUpperCase();
        const base = Math.max(Date.now(), rec.expiresAt || 0);
        const exp = expiryFor(plan, base);
        await store.update(`keys/${key}`, { expiresAt: plan === 'LIFE' ? null : exp, plan });
        break;
      }
      case 'reset-device':
        await store.update(`keys/${key}`, { devices: {}, deviceId: null });
        break;
      case 'reset-stats':
        await store.update(`keys/${key}`, { statsResetAt: Date.now() });
        break;
      case 'note':
        await store.update(`keys/${key}`, { note: String(req.body?.note || '').slice(0, 120) });
        break;
      case 'delete':
        await store.remove(`keys/${key}`);
        break;
      default:
        return res.status(400).json({ ok: false, message: 'Unknown action.' });
    }
    await audit(store, { kind: 'KEY_' + action.toUpperCase(), by: req.admin.u, key });
    res.json({ ok: true });
  });

  /* ───────── settings / engine control ───────── */
  r.get('/settings', async (req, res) => {
    const settings = (await store.get('settings')) || {};
    res.json({
      ok: true,
      settings,
      patterns: PATTERNS.map((p) => ({ id: p.id, name: p.name, tier: p.src, priority: p.pri })),
      timeframes: TF_LIST
    });
  });

  r.put('/settings', async (req, res) => {
    const cur = (await store.get('settings')) || {};
    const body = req.body || {};
    const next = { ...cur };

    const strKeys = ['appName', 'tagline', 'announcement', 'maintenanceMsg', 'theme', 'keyPrefix'];
    strKeys.forEach((k) => { if (typeof body[k] === 'string') next[k] = body[k].slice(0, 240); });
    const boolKeys = ['announcementEnabled', 'maintenance', 'registrationOpen', 'soundsDefault', 'voiceDefault', 'animationsDefault'];
    boolKeys.forEach((k) => { if (typeof body[k] === 'boolean') next[k] = body[k]; });
    if (body.timeframes && typeof body.timeframes === 'object') {
      next.timeframes = { ...(cur.timeframes || {}) };
      TF_LIST.forEach((t) => { next.timeframes[t.id] = body.timeframes[t.id] !== false; });
    }
    if (body.features && typeof body.features === 'object') next.features = { ...(cur.features || {}), ...body.features };
    if (body.engine && typeof body.engine === 'object') {
      const e = { ...(cur.engine || {}) };
      if (body.engine.minConfidence !== undefined) {
        e.minConfidence = Math.min(99, Math.max(50, parseInt(body.engine.minConfidence, 10) || 60));
      }
      if (Array.isArray(body.engine.disabledPatterns)) e.disabledPatterns = body.engine.disabledPatterns.slice(0, 200);
      if (typeof body.engine.disableCoreMath === 'boolean') e.disableCoreMath = body.engine.disableCoreMath;
      next.engine = e;
    }
    if (typeof body.maxDevices === 'number') next.maxDevices = Math.min(5, Math.max(1, body.maxDevices));

    await store.set('settings', next);
    live.settings = next;
    await audit(store, { kind: 'SETTINGS_UPDATE', by: req.admin.u, keys: Object.keys(body) });
    res.json({ ok: true, settings: next });
  });

  /* force the next result for a timeframe (silent, admin-only) */
  r.post('/engine/force', async (req, res) => {
    const settings = (await store.get('settings')) || {};
    const tf = String(req.body?.tf || '').toUpperCase();
    const size = String(req.body?.size || '').toUpperCase();
    const periods = Math.min(20, Math.max(1, parseInt(req.body?.periods || 1, 10)));
    const engine = { ...(settings.engine || {}), force: { ...((settings.engine || {}).force || {}) } };
    if (size === 'CLEAR' || size === '') {
      delete engine.force[tf];
      if (tf === 'ALL') engine.force = {};
    } else {
      if (!['BIG', 'SMALL'].includes(size)) return res.status(400).json({ ok: false, message: 'size must be BIG/SMALL/CLEAR' });
      const targets = tf === 'ALL' ? TF_LIST.map((t) => t.id) : [tf];
      targets.forEach((t) => { engine.force[t] = { size, periods, createdAt: Date.now(), by: req.admin.u }; });
    }
    await store.update('settings', { engine });
    live.settings = { ...settings, engine };
    await audit(store, { kind: 'ENGINE_FORCE', by: req.admin.u, tf, size, periods });
    res.json({ ok: true, force: engine.force });
  });

  /* reset global scoreboard */
  r.post('/stats/reset', async (req, res) => {
    await store.set('stats', { wins: 0, losses: 0, jackpots: 0, total: 0, resetAt: Date.now() });
    await store.update('settings', { resultsResetAt: Date.now() });
    await audit(store, { kind: 'STATS_RESET', by: req.admin.u });
    res.json({ ok: true });
  });

  /* broadcast ticker + maintenance */
  r.post('/broadcast', async (req, res) => {
    const announcement = String(req.body?.announcement || '').slice(0, 240);
    const enabled = req.body?.enabled !== false;
    await store.update('settings', { announcement, announcementEnabled: enabled });
    await audit(store, { kind: 'BROADCAST', by: req.admin.u, announcement });
    res.json({ ok: true });
  });

  r.post('/maintenance', async (req, res) => {
    const on = !!req.body?.on;
    const msg = String(req.body?.msg || '').slice(0, 240);
    const patch = { maintenance: on };
    if (msg) patch.maintenanceMsg = msg;
    await store.update('settings', patch);
    await audit(store, { kind: 'MAINTENANCE', by: req.admin.u, on });
    res.json({ ok: true, maintenance: on });
  });

  /* master key rotation */
  r.post('/password', async (req, res) => {
    const cur = String(req.body?.current || '');
    const next = String(req.body?.next || '');
    if (next.length < 8) return res.status(400).json({ ok: false, message: 'New master key must be 8+ characters.' });
    const rec = (await store.get('admin')) || {};
    if (!verifyPassword(cur, rec.passwordHash)) {
      return res.status(403).json({ ok: false, message: 'Current master key is wrong.' });
    }
    await store.update('admin', {
      passwordHash: hashPassword(next),
      defaultKey: false,
      updatedAt: Date.now(),
      tokenVersion: crypto.randomInt(1, 1e9)
    });
    await audit(store, { kind: 'MASTER_KEY_CHANGE', by: req.admin.u });
    res.json({ ok: true, message: 'Master key updated. Re-open the console and log in again.' });
  });

  /* audit trail + CSV exports */
  r.get('/audit', async (req, res) => {
    res.json({ ok: true, audit: (await store.get('audit')) || [] });
  });

  r.get('/export', async (req, res) => {
    const type = String(req.query.type || 'keys');
    const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    let rows = [];
    if (type === 'keys') {
      const keys = (await store.get('keys')) || {};
      rows = [['key', 'plan', 'note', 'createdAt', 'expiresAt', 'revoked', 'used', 'logins', 'devices', 'lastSeen']];
      Object.entries(keys).forEach(([k, v]) => rows.push([
        k, v.plan, v.note || '', v.createdAt ? new Date(v.createdAt).toISOString() : '',
        v.expiresAt ? new Date(v.expiresAt).toISOString() : 'LIFE', v.revoked ? 'yes' : 'no',
        v.used ? 'yes' : 'no', v.logins || 0, Object.keys(v.devices || {}).length,
        v.lastSeen ? new Date(v.lastSeen).toISOString() : ''
      ]));
    } else if (type === 'history') {
      rows = [['tf', 'period', 'number', 'size', 'predSize', 'outcome', 'confidence', 'pattern', 'time']];
      TF_LIST.forEach((tf) => {
        live.history(tf.id, 0, 240).forEach((h) => rows.push([
          tf.id, h.period, h.number, h.size, h.predSize || '', h.outcome || '', h.confidence || '', h.pattern || '',
          new Date(h.ts).toISOString()
        ]));
      });
    } else if (type === 'audit') {
      const a = (await store.get('audit')) || [];
      rows = [['time', 'kind', 'by', 'detail']];
      a.forEach((e) => rows.push([new Date(e.ts).toISOString(), e.kind, e.by || '', JSON.stringify(e)]));
    } else {
      return res.status(400).json({ ok: false, message: 'Unknown export type.' });
    }
    const csv = rows.map((row) => row.map(csvCell).join(',')).join('\n');
    await audit(store, { kind: 'EXPORT', by: req.admin.u, type });
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="bunny-team-${type}-${Date.now()}.csv"`);
    res.send(csv);
  });

  /* live engine probe */
  r.get('/feed', async (req, res) => {
    res.json({ ok: true, feed: live.feedHealth(), running: live.running, lastTick: live.lastTickAt });
  });

  r.post('/simulate', async (req, res) => {
    const nums = String(req.body?.numbers || '')
      .split(/[^0-9]/).filter(Boolean).map(Number).slice(0, 100);
    if (nums.length < 3) return res.status(400).json({ ok: false, message: 'At least 3 digits needed (newest first).' });
    const period = String(req.body?.period || 'SIM' + Date.now()).slice(0, 24);
    res.json({ ok: true, result: masterPrediction(period, nums, {}) });
  });

  r.get('/me', async (req, res) => {
    const rec = (await store.get('admin')) || {};
    res.json({ ok: true, label: rec.label || config.adminLabel, usingDefault: !!rec.defaultKey, updatedAt: rec.updatedAt || null });
  });

  /* ───────── own vault: info, live backup, full export ───────── */
  r.get('/vault', async (req, res) => {
    const keys = (await store.get('keys')) || {};
    res.json({
      ok: true,
      vault: store.info(),
      counts: {
        keys: Object.keys(keys).length,
        predictions: Object.keys((await store.get('predictions')) || {}).length,
        audit: ((await store.get('audit')) || []).length
      }
    });
  });

  r.get('/vault/backup', async (req, res) => {
    try {
      await store.flushNow?.();
      const file = store.file;
      await audit(store, { kind: 'VAULT_BACKUP', by: req.admin.u });
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="bunny-vault-${Date.now()}.enc"`);
      fs.createReadStream(file).pipe(res);
    } catch (e) {
      res.status(500).json({ ok: false, message: 'Backup failed: ' + e.message });
    }
  });

  r.post('/vault/restore', express.raw({ type: ['application/octet-stream', 'text/plain', '*/*'], limit: '16mb' }), async (req, res) => {
    try {
      const buf = req.body;
      if (!buf || !buf.length) return res.status(400).json({ ok: false, message: 'No file received.' });
      const info = await store.importEncrypted(buf.toString('utf8'));
      await audit(store, { kind: 'VAULT_RESTORE', by: req.admin.u, keys: info.keys });
      res.json({ ok: true, message: `Vault restored · ${info.keys} keys recovered. Restart the server to be safe.` });
    } catch (e) {
      res.status(400).json({ ok: false, message: 'Restore failed: ' + e.message });
    }
  });

  r.get('/vault/bootstrap', async (req, res) => {
    try {
      const zlib = await import('node:zlib');
      const core = await store.coreSnapshot();
      const b64 = zlib.gzipSync(Buffer.from(JSON.stringify(core), 'utf8')).toString('base64');
      await audit(store, { kind: 'VAULT_BOOTSTRAP_EXPORT', by: req.admin.u, kb: Math.round(b64.length / 1024) });
      res.json({
        ok: true,
        b64,
        kb: Math.round(b64.length / 1024),
        keys: Object.keys(core.keys || {}).length,
        fits: b64.length < 60000
      });
    } catch (e) {
      res.status(500).json({ ok: false, message: e.message });
    }
  });

  r.get('/vault/export', async (req, res) => {
    await audit(store, { kind: 'VAULT_EXPORT', by: req.admin.u });
    const snap = await store.rawSnapshot();
    delete snap.meta?.sessionSecret;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="bunny-vault-${Date.now()}.json"`);
    res.send(JSON.stringify(snap, null, 2));
  });

  return r;
}
