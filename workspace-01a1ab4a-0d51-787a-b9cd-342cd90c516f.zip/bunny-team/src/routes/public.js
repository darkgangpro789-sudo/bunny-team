import express from 'express';
import { config } from '../config.js';
import { signToken, rateLimit } from '../auth.js';
import { PATTERNS } from '../engine/patterns.js';
import { masterPrediction, TF_LIST, getTF } from '../engine/index.js';

export function publicRoutes(ctx) {
  const { store, live, sessionSecret } = ctx;
  const r = express.Router();

  const keyStatus = (rec) => {
    if (!rec) return 'INVALID';
    if (rec.revoked) return 'REVOKED';
    if (rec.expiresAt && Date.now() > rec.expiresAt) return 'EXPIRED';
    return 'ACTIVE';
  };

  /* ── login with VIP key ── */
  r.post('/auth/login', async (req, res) => {
    const ip = req.ip || 'x';
    if (!rateLimit('login', ip, 25, 60_000)) {
      return res.status(429).json({ ok: false, code: 'RATE_LIMIT', message: 'Too many attempts. Wait a minute.' });
    }
    const key = String(req.body?.key || '').trim().toUpperCase().replace(/\s+/g, '');
    const deviceId = String(req.body?.deviceId || '').trim().slice(0, 40) || 'DEV-UNKNOWN';
    if (!key) return res.status(400).json({ ok: false, code: 'EMPTY', message: 'Enter your access key.' });

    const settings = (await store.get('settings')) || {};
    if (settings.registrationOpen === false && !(await store.get(`keys/${key}`))) {
      return res.status(403).json({ ok: false, code: 'CLOSED', message: 'Registration is closed by the admin.' });
    }

    const isOwner = config.ownerKey && key === String(config.ownerKey).toUpperCase();
    const rec = await store.get(`keys/${key}`);
    const status = isOwner ? 'ACTIVE' : keyStatus(rec);

    if (status === 'INVALID') {
      return res.status(401).json({ ok: false, code: 'INVALID', message: '❌ Invalid access key.' });
    }
    if (status === 'REVOKED') {
      return res.status(403).json({ ok: false, code: 'REVOKED', message: '🚫 This key was revoked by the admin.' });
    }
    if (status === 'EXPIRED') {
      return res.status(403).json({ ok: false, code: 'EXPIRED', message: '⌛ This key has expired.' });
    }

    if (!isOwner) {
      const devices = rec.devices || (rec.deviceId ? { [rec.deviceId]: { firstSeen: rec.createdAt || Date.now() } } : {});
      const limit = Math.max(1, parseInt(rec.maxDevices || settings.maxDevices || 1, 10));
      if (!devices[deviceId]) {
        if (Object.keys(devices).length >= limit) {
          return res.status(409).json({
            ok: false,
            code: 'DEVICE_LIMIT',
            message: `🔒 This key is locked to ${limit} device${limit > 1 ? 's' : ''}. Ask the admin to reset it.`
          });
        }
        devices[deviceId] = { firstSeen: Date.now() };
      }
      devices[deviceId].lastSeen = Date.now();
      await store.update(`keys/${key}`, {
        devices,
        deviceId: Object.keys(devices)[0],
        used: true,
        lastSeen: Date.now(),
        logins: (rec.logins || 0) + 1
      });
    } else {
      await store.update(`keys/${key}`, { lastSeen: Date.now() }).catch(() => {});
    }

    const token = signToken({ k: key, d: deviceId, scope: 'user', owner: !!isOwner }, sessionSecret, config.sessionHours * 3600);
    const adminToken = isOwner
      ? signToken({ scope: 'admin', u: 'owner' }, sessionSecret, config.adminSessionHours * 3600)
      : null;

    res.json({
      ok: true,
      token,
      adminToken,
      profile: {
        key: key.slice(0, 6) + '••' + key.slice(-2),
        plan: rec?.plan || (isOwner ? 'OWNER' : 'VIP'),
        expiresAt: isOwner ? null : rec?.expiresAt || null,
        owner: !!isOwner
      }
    });
  });

  /* ── session check (revocation aware) ── */
  r.post('/auth/check', async (req, res) => {
    const s = req.user;
    if (!s) return res.status(401).json({ ok: false, code: 'SESSION' });
    const settings = (await store.get('settings')) || {};
    res.json({
      ok: true,
      profile: { key: s.k.slice(0, 6) + '••' + s.k.slice(-2), owner: !!s.owner },
      maintenance: !!settings.maintenance
    });
  });

  /* ── master state for the app ── */
  r.get('/state', async (req, res) => {
    if (!req.user) return res.status(401).json({ ok: false, code: 'SESSION' });
    const tfId = String(req.query.tf || config.defaultTimeframe).toUpperCase();
    const tf = getTF(tfId);
    const settings = (await store.get('settings')) || {};
    const keyRec = req.user.owner ? null : await store.get(`keys/${req.user.k}`);
    if (!req.user.owner) {
      if (!keyRec) return res.status(403).json({ ok: false, code: 'REVOKED', message: 'Key deleted by admin.' });
      if (keyRec.revoked) return res.status(403).json({ ok: false, code: 'REVOKED', message: 'Key revoked by admin.' });
      if (keyRec.expiresAt && Date.now() > keyRec.expiresAt) {
        return res.status(403).json({ ok: false, code: 'EXPIRED', message: 'Key expired.' });
      }
    }
    const snap = live.snapshot(tf.id);
    if (settings.maintenance) {
      snap.maintenance = true;
      snap.maintenanceMsg = settings.maintenanceMsg;
    }
    if (!(settings.features || {}).consensus) snap.prediction && (snap.prediction.votes = null);
    if (!(settings.features || {}).patterns) snap.prediction && (snap.prediction.matches = []);
    snapshotGuard(snap);
    res.json({ ok: true, state: snap });
  });

  /* ── paginated history ── */
  r.get('/history', async (req, res) => {
    if (!req.user) return res.status(401).json({ ok: false, code: 'SESSION' });
    const tfId = getTF(String(req.query.tf || config.defaultTimeframe)).id;
    const limit = Math.min(120, Math.max(5, parseInt(req.query.limit || '60', 10)));
    let since = 0;
    if (!req.user.owner) {
      const rec = await store.get(`keys/${req.user.k}`);
      if (!rec) return res.status(403).json({ ok: false, code: 'REVOKED' });
      since = Math.max(rec.createdAt || 0, rec.statsResetAt || 0);
    }
    const items = live.history(tfId, since, limit);
    const stats = live.computeStats(
      (live.state.get(tfId)?.buf) || [],
      since
    );
    res.json({ ok: true, items, stats });
  });

  /* ── pattern catalogue (names only, logic stays on the server) ── */
  r.get('/patterns', async (req, res) => {
    if (!req.user) return res.status(401).json({ ok: false, code: 'SESSION' });
    const list = PATTERNS.map((p) => ({ id: p.id, name: p.name, tier: p.src, priority: p.pri }));
    res.json({ ok: true, count: list.length, patterns: list });
  });

  /* ── admin-only sandbox: run the engine on custom digits ── */
  r.post('/engine/simulate', async (req, res) => {
    if (!req.admin) return res.status(401).json({ ok: false, code: 'ADMIN' });
    const nums = String(req.body?.numbers || '')
      .split(/[^0-9]/)
      .filter(Boolean)
      .map(Number)
      .slice(0, 100);
    const period = String(req.body?.period || 'SIM0001');
    if (nums.length < 3) return res.status(400).json({ ok: false, message: 'Give at least 3 digits (newest first).' });
    res.json({ ok: true, result: masterPrediction(period, nums, {}) });
  });

  return r;
}

function snapshotGuard(snap) {
  if (snap.prediction) {
    delete snap.prediction.forced;
    if (snap.prediction.patternName && snap.prediction.patternName.startsWith('ADMIN LOCK')) {
      snap.prediction.patternName = 'CONSENSUS LOCK';
    }
  }
  return snap;
}

export const TF_META = TF_LIST;
