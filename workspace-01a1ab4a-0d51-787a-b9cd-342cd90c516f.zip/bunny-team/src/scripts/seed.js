/**
 * BUNNY TEAM — key seeder (CLI)
 * usage: node src/scripts/seed.js 5 7D "reseller batch"
 *        node src/scripts/seed.js 1 LIFE
 */
import { createStore } from '../store/index.js';
import { randomKey, expiryFor } from '../auth.js';

const [, , countArg = '1', plan = '7D', note = 'seed'] = process.argv;
const count = Math.min(50, Math.max(1, parseInt(countArg, 10) || 1));

const { store, mode } = await createStore();
const keys = (await store.get('keys')) || {};
const created = [];

for (let i = 0; i < count; i++) {
  let k;
  do { k = randomKey('BT'); } while (keys[k]);
  keys[k] = {
    key: k,
    plan,
    note,
    maxDevices: 1,
    createdAt: Date.now(),
    expiresAt: expiryFor(plan),
    revoked: false,
    used: false,
    logins: 0,
    devices: {},
    createdBy: 'seed'
  };
  created.push(k);
}

await store.set('keys', keys);
await store.close?.();

console.log(`store: ${mode}`);
console.log(`created ${created.length} key(s) · plan ${plan}`);
created.forEach((k) => console.log('  ' + k));
