import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { config } from '../config.js';
import { hashPassword } from '../auth.js';
import { VaultStore } from './vault.js';

export const DEFAULT_SETTINGS = {
  appName: 'BUNNY TEAM',
  tagline: 'PREMIUM PREDICTION INTELLIGENCE',
  announcement: '🐰 Welcome to BUNNY TEAM — the engine is locked and live. Play responsibly.',
  announcementEnabled: true,
  maintenance: false,
  maintenanceMsg: '🛠️ BUNNY TEAM is upgrading the engine. Back in a few minutes.',
  registrationOpen: true,
  soundsDefault: true,
  voiceDefault: true,
  animationsDefault: true,
  theme: 'bunny-gold',
  timeframes: { '30S': true, '1M': true, '3M': true, '5M': true },
  engine: {
    minConfidence: 60,
    disabledPatterns: [],
    disableCoreMath: false,
    force: {},            // { '1M': { size:'BIG', periods:3, createdAt } }
    fallbackSize: 'BIG'
  },
  keyPrefix: 'BT',
  maxDevices: 1,
  features: { history: true, stats: true, patterns: true, consensus: true, trendChart: true },
  resultsResetAt: 0
};

export async function createStore() {
  fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });

  const store = new VaultStore({
    file: config.dataFile,
    backupFile: config.backupFile,
    secret: config.dataSecret,
    keyFile: path.join(config.dataDir, '.vaultkey')
  });
  await store.ready();
  const mode = 'vault (AES-256-GCM, self-hosted)';

  /* ── vault meta + session secret ── */
  let meta = (await store.get('meta')) || {};
  const patch = {};
  if (!meta.sessionSecret) patch.sessionSecret = config.sessionSecret || crypto.randomBytes(32).toString('hex');
  if (!meta.createdAt) patch.createdAt = Date.now();
  if (!meta.vaultId) patch.vaultId = 'BT-' + crypto.randomBytes(6).toString('hex').toUpperCase();
  patch.version = 2;
  if (Object.keys(patch).length) {
    meta = { ...meta, ...patch };
    await store.set('meta', meta);
  }
  const sessionSecret = config.sessionSecret || crypto.randomBytes(32).toString('hex');

  /* ── settings defaults ── */
  const settings = (await store.get('settings')) || {};
  const merged = {
    ...DEFAULT_SETTINGS,
    ...settings,
    timeframes: { ...DEFAULT_SETTINGS.timeframes, ...(settings.timeframes || {}) },
    engine: { ...DEFAULT_SETTINGS.engine, ...(settings.engine || {}) },
    features: { ...DEFAULT_SETTINGS.features, ...(settings.features || {}) }
  };
  if (!settings.appName) await store.set('settings', merged);

  /* ── the ONE master key ── */
  const adminNode = (await store.get('admin')) || {};
  if (!adminNode.passwordHash) {
    await store.set('admin', {
      label: config.adminLabel,
      passwordHash: hashPassword(config.adminKey),
      defaultKey: !process.env.ADMIN_KEY,
      updatedAt: Date.now(),
      bootstrapped: true
    });
    console.log('  🔐 console master key active (set ADMIN_KEY in .env to change it)');
  }

  /* ── global stats node ── */
  if (!(await store.get('stats'))) {
    await store.set('stats', { wins: 0, losses: 0, jackpots: 0, total: 0, resetAt: Date.now() });
  }

  return { store, mode, sessionSecret, settings: merged, meta };
}

export async function audit(store, entry) {
  const log = (await store.get('audit')) || [];
  log.unshift({ ...entry, ts: Date.now() });
  await store.set('audit', log.slice(0, 600));
}
