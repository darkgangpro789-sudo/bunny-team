/**
 * BUNNY TEAM — OWN DATA VAULT (no third-party database)
 * ------------------------------------------------------
 * Everything lives in one file on this server, encrypted at rest with
 * AES-256-GCM. The encryption key comes from DATA_SECRET (or a private
 * key-file generated on first boot, mode 0600) — nothing leaves the machine.
 *
 * Writes are atomic (tmp → fsync → rename) and a rolling backup copy is kept
 * so a crash can never destroy the key registry.
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';

const ALGO = 'aes-256-gcm';
const clone = (v) => (v === undefined || v === null ? null : JSON.parse(JSON.stringify(v)));
const norm = (p) => String(p || '').replace(/^\/+|\/+$/g, '');
const segsOf = (p) => norm(p).split('/').filter(Boolean);

function deepGet(tree, p) {
  let cur = tree;
  for (const seg of segsOf(p)) {
    if (!cur || typeof cur !== 'object') return null;
    cur = cur[seg];
  }
  return cur === undefined ? null : cur;
}

function deepSet(tree, p, value) {
  const segs = segsOf(p);
  if (!segs.length) return value ?? {};
  let cur = tree;
  for (let i = 0; i < segs.length - 1; i++) {
    if (typeof cur[segs[i]] !== 'object' || cur[segs[i]] === null) cur[segs[i]] = {};
    cur = cur[segs[i]];
  }
  const last = segs[segs.length - 1];
  if (value === null) delete cur[last];
  else cur[last] = value;
  return tree;
}

function keyFromSecret(secret, rounds) {
  return crypto.scryptSync(String(secret), 'bunny-team-vault-v2', 32, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

export class VaultStore {
  constructor({ file, backupFile, secret, keyFile }) {
    this.file = file;
    this.backupFile = backupFile || file + '.backup';
    this.keyFile = keyFile;
    this.key = this._resolveKey(secret, keyFile);
    this.tree = {};
    this.kind = 'vault';
    this._timer = null;
    this._flushes = 0;
    this._ready = this._load();
  }

  _resolveKey(secret, keyFile) {
    if (secret && String(secret).length >= 16) return keyFromSecret(secret);
    /* no DATA_SECRET → private key file next to the vault (0600) */
    try {
      fs.mkdirSync(path.dirname(keyFile), { recursive: true });
      if (fs.existsSync(keyFile)) {
        const raw = fs.readFileSync(keyFile, 'utf8').trim();
        if (raw.length >= 32) return Buffer.from(raw, 'hex');
      }
      const generated = crypto.randomBytes(32);
      fs.writeFileSync(keyFile, generated.toString('hex'), { mode: 0o600 });
      console.warn('[vault] DATA_SECRET missing — generated a private key file:', keyFile);
      return generated;
    } catch (err) {
      console.warn('[vault] key file unavailable, using ephemeral key:', err.message);
      return crypto.randomBytes(32);
    }
  }

  async _load() {
    await fsp.mkdir(path.dirname(this.file), { recursive: true }).catch(() => {});
    for (const candidate of [this.file, this.backupFile]) {
      if (!fs.existsSync(candidate)) continue;
      try {
        this.tree = this._decrypt(await fsp.readFile(candidate, 'utf8'));
        if (candidate !== this.file) console.warn('[vault] primary unreadable — recovered from backup');
        return;
      } catch (err) {
        console.warn('[vault] cannot open', path.basename(candidate) + ':', err.message);
      }
    }
    this.tree = {};
    /* free hosts wipe the disk on sleep/redeploy → optional cold restore from env */
    const boot = process.env.VAULT_BOOTSTRAP_B64;
    if (boot && boot.length > 40) {
      try {
        const payload = zlib.gunzipSync(Buffer.from(boot, 'base64')).toString('utf8');
        /* two formats: {__core:true,...} (compact) or a full encrypted vault blob */
        if (payload.trim().startsWith('{')) {
          const core = JSON.parse(payload);
          if (!core.__core) throw new Error('unknown bootstrap payload');
          this.tree = this._fromCore(core);
        } else {
          this.tree = this._decrypt(payload);
        }
        console.log('[vault] cold-boot restore →', Object.keys(this.tree.keys || {}).length, 'keys,',
          Object.keys(this.tree.settings || {}).length, 'settings nodes');
        await this._flush();
        return;
      } catch (e) {
        console.warn('[vault] VAULT_BOOTSTRAP_B64 rejected:', e.message);
        this.tree = {};
      }
    }
    await this._flush();
  }

  _decrypt(payload) {
    const buf = Buffer.from(String(payload).trim(), 'base64');
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const data = buf.subarray(28);
    const d = crypto.createDecipheriv(ALGO, this.key, iv);
    d.setAuthTag(tag);
    return JSON.parse(Buffer.concat([d.update(data), d.final()]).toString('utf8') || '{}');
  }

  _encrypt(tree) {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv(ALGO, this.key, iv);
    const enc = Buffer.concat([c.update(Buffer.from(JSON.stringify(tree), 'utf8')), c.final()]);
    return Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64');
  }

  async _flush() {
    const payload = this._encrypt(this.tree);
    const tmp = this.file + '.tmp';
    const fh = await fsp.open(tmp, 'w', 0o600);
    try {
      await fh.writeFile(payload, 'utf8');
      await fh.sync();
    } finally {
      await fh.close();
    }
    await fsp.rename(tmp, this.file);

    /* rolling backup — every 10th write */
    this._flushes++;
    if (this._flushes % 10 === 1) {
      await fsp.copyFile(this.file, this.backupFile).then(() => fsp.chmod(this.backupFile, 0o600)).catch(() => {});
    }
  }

  _queue() {
    if (this._timer) clearTimeout(this._timer);
    this._timer = setTimeout(() => {
      this._timer = null;
      this._flush().catch((e) => console.error('[vault] flush failed:', e.message));
    }, 100);
  }

  async ready() { return this._ready; }

  async get(p) {
    await this._ready;
    return clone(deepGet(this.tree, p));
  }

  async set(p, value) {
    await this._ready;
    if (!norm(p)) this.tree = clone(value) || {};
    else deepSet(this.tree, p, clone(value));
    this._queue();
    return clone(value);
  }

  async update(p, patch) {
    await this._ready;
    const cur = deepGet(this.tree, p);
    const base = cur && typeof cur === 'object' && !Array.isArray(cur) ? cur : {};
    const merged = { ...base, ...clone(patch) };
    deepSet(this.tree, p, merged);
    this._queue();
    return clone(merged);
  }

  async remove(p) {
    await this._ready;
    deepSet(this.tree, p, null);
    this._queue();
  }

  /* ── compact bootstrap: durable state only (results/predictions are rebuilt from the feed) ── */
  async coreSnapshot() {
    await this._ready;
    const t = this.tree;
    return {
      __core: true,
      v: 1,
      exportedAt: Date.now(),
      meta: { createdAt: t.meta?.createdAt, version: t.meta?.version, vaultId: t.meta?.vaultId },
      admin: t.admin || {},
      settings: t.settings || {},
      stats: t.stats || {},
      keys: t.keys || {},
      audit: (t.audit || []).slice(0, 60)
    };
  }

  _fromCore(core) {
    const tree = {};
    if (core.meta) tree.meta = core.meta;
    if (core.admin) tree.admin = core.admin;
    if (core.settings) tree.settings = core.settings;
    if (core.stats) tree.stats = core.stats;
    if (core.keys) tree.keys = core.keys;
    if (core.audit) tree.audit = core.audit;
    return tree;
  }

  /* admin helpers */
  /** validate + import an encrypted vault backup (same DATA_SECRET required) */
  async importEncrypted(payload) {
    await this._ready;
    const tree = this._decrypt(payload);            // throws if wrong key / corrupt
    if (!tree || typeof tree !== 'object') throw new Error('backup is empty or invalid');
    this.tree = tree;
    await this.flushNow();
    return { keys: Object.keys(tree.keys || {}).length, settings: !!tree.settings };
  }

  async flushNow() {
    await this._ready;
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    await this._flush();
  }

  async rawSnapshot() {
    await this._ready;
    return clone(this.tree);
  }

  info() {
    let bytes = 0;
    try { bytes = fs.statSync(this.file).size; } catch { /* ignore */ }
    return {
      kind: this.kind,
      file: path.basename(this.file),
      bytes,
      encrypted: true,
      algorithm: 'AES-256-GCM',
      backups: fs.existsSync(this.backupFile)
    };
  }

  async close() {
    if (this._timer) clearTimeout(this._timer);
    await this._flush().catch(() => {});
  }
}
