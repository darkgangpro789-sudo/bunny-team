/** dev-only smoke test for the hidden console UI */
import fs from 'node:fs';
import { JSDOM } from 'jsdom';

const html = fs.readFileSync(new URL('../public/console.html', import.meta.url), 'utf8');
const dom = new JSDOM(html, { url: 'http://localhost:3000/bunny-console-9x7', runScripts: 'outside-only', pretendToBeVisual: true });
const { window } = dom;
const noop = () => {};
const json = (obj, status = 200) => Promise.resolve({ ok: status < 400, status, json: () => Promise.resolve(obj), blob: () => Promise.resolve(new window.Blob(['a,b'])) });

const settings = {
  appName: 'BUNNY TEAM', tagline: 'PREMIUM', announcement: 'hello', announcementEnabled: true, maintenance: false,
  maintenanceMsg: 'upgrading', registrationOpen: true, soundsDefault: true, voiceDefault: true, animationsDefault: true,
  timeframes: { '30S': true, '1M': true, '3M': false, '5M': true },
  engine: { minConfidence: 60, disabledPatterns: ['E-BSSB'], disableCoreMath: false, force: { '3M': { size: 'BIG', periods: 2 } } },
  features: { history: true, stats: true, patterns: true, consensus: true, trendChart: true }, maxDevices: 1
};
const keys = [{ key: 'BT-AAAA-BBBB', plan: '7D', status: 'IN USE', createdAt: Date.now() - 86400000, expiresAt: Date.now() + 5 * 86400000, devicesCount: 1, logins: 4, note: 'vip', revoked: false, online: true }];

window.fetch = (url, opts = {}) => {
  const u = String(url);
  if (u.includes('/api/sys/auth')) {
    const b = JSON.parse(opts.body || '{}');
    if (b.key !== 'RUP@ADHIKARY') return json({ ok: false, message: '❌ Wrong master key.' }, 401);
    return json({ ok: true, token: 'ADMIN', label: 'RUP', usingDefault: false });
  }
  if (u.includes('/api/sys/overview')) return json({
    ok: true, store: 'firebase', engineLive: true,
    feed: { '1M': { mode: 'live', at: Date.now(), results: 40, predictions: 2 }, '3M': { mode: 'synthetic', at: Date.now(), results: 12, predictions: 1 } },
    counts: { keys: 3, active: 2, expired: 1, revoked: 0, online: 1, patterns: 72 },
    stats: { wins: 20, losses: 10, jackpots: 3, total: 30 }, settings, audits: [{ ts: Date.now(), kind: 'KEYS_GENERATED', by: 'bunny' }],
    boot: { createdAt: Date.now() - 3600000, node: 'v20.20.2', uptime: 120 }
  });
  if (u.includes('/api/sys/keys/generate')) return json({ ok: true, created: [{ key: 'BT-NEW1-2345' }, { key: 'BT-NEW2-6789' }] });
  if (u.includes('/api/sys/keys')) return json({ ok: true, total: 1, keys });
  if (u.includes('/api/sys/settings')) return json({ ok: true, settings, patterns: [{ id: 'D-DRG6B', name: 'BIG DRAGON ×6+', tier: 'SIG', priority: 100 }, { id: 'E-BSSB', name: 'B-SS-B', tier: 'CFM', priority: 40 }], timeframes: [{ id: '1M', label: 'WinGo 1 Min', seconds: 60, emoji: '🕐' }] });
  if (u.includes('/api/sys/audit')) return json({ ok: true, audit: [{ ts: Date.now(), kind: 'ADMIN_LOGIN', by: 'bunny' }] });
  if (u.includes('/api/sys/me')) return json({ ok: true, label: 'RUP', usingDefault: false });
  if (u.includes('/api/sys/vault')) return json({ ok: true, vault: { algorithm: 'AES-256-GCM', bytes: 8192 }, counts: { keys: 3 } });
  if (u.includes('/api/sys/simulate')) return json({ ok: true, result: { size: 'BIG', numbers: [4, 9], confidence: 91, patternName: 'BIG DRAGON', patternDetail: 'x', source: 'SIG', crossCheck: 'AGREE', matchCount: 4, votes: { big: 10, small: 5, share: 66 }, pattern: { priority: 100 }, seq: 'BBBBSS' } });
  return json({ ok: true });
};

const errors = [];
window.addEventListener('error', (e) => errors.push(e.message));
const origErr = console.error;
console.error = (...a) => errors.push(a.join(' '));

window.eval(fs.readFileSync(new URL('../public/console.js', import.meta.url), 'utf8').replace(/^import .*$/gm, ''));

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const $ = (s) => window.document.querySelector(s);

await wait(250);
$('#ap').value = 'bad';
$('#gateBtn').click();
await wait(200);
console.log('bad login   :', $('#gateMsg').textContent);

$('#ap').value = 'RUP@ADHIKARY';
$('#gateBtn').click();
await wait(500);
console.log('console open:', !$('#sys').hidden, '|', $('#sysFeed').textContent);

for (const tab of ['keys', 'engine', 'app', 'audit', 'security', 'overview']) {
  window.document.querySelector(`.sys-tab[data-tab="${tab}"]`).click();
  await wait(400);
  console.log(`tab ${tab.padEnd(9)}:`, $('#pane').children.length + ' blocks');
}

/* key generator */
window.document.querySelector('.sys-tab[data-tab="keys"]').click();
await wait(400);
$('#gCount').value = '2';
$('#genBtn').click();
await wait(300);
console.log('generated  :', window.document.querySelectorAll('#keyOut .keychip').length, 'chips');
console.log('key rows   :', window.document.querySelectorAll('#kBody tr').length);

/* simulate */
window.document.querySelector('.sys-tab[data-tab="engine"]').click();
await wait(400);
$('#simNums').value = '1 2 3 4 5';
$('#simBtn').click();
await wait(250);
console.log('sim output :', $('#simOut').textContent.split('\n')[0]);

console.error = origErr;
console.log('\nJS errors:', errors.length ? errors : 'none ✅');
process.exit(errors.length ? 1 : 0);
