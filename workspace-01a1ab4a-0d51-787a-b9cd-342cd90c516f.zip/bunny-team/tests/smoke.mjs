/**
 * dev-only smoke test: boots public/index.html in jsdom with a stubbed canvas /
 * audio / fetch, runs the client, performs a login and renders every page.
 * run: node tests/smoke.mjs
 */
import fs from 'node:fs';
import { JSDOM } from 'jsdom';

const html = fs.readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
const dom = new JSDOM(html, { url: 'http://localhost:3000/', runScripts: 'outside-only', pretendToBeVisual: true });
const { window } = dom;

/* stubs */
const noop = () => {};
window.HTMLCanvasElement.prototype.getContext = () => ({
  clearRect: noop, beginPath: noop, arc: noop, fill: noop, createRadialGradient: () => ({ addColorStop: noop }),
  createLinearGradient: () => ({ addColorStop: noop }), fillRect: noop, set fillStyle(v) {}, get fillStyle() { return ''; }
});
class FakeAC {
  constructor() { this.currentTime = 0; this.state = 'running'; this.sampleRate = 44100; this.destination = {}; }
  createOscillator() { return { type: '', frequency: { setValueAtTime: noop, exponentialRampToValueAtTime: noop }, connect: (n) => n, start: noop, stop: noop }; }
  createGain() { return { gain: { setValueAtTime: noop, exponentialRampToValueAtTime: noop, value: 1 }, connect: (n) => n }; }
  createBiquadFilter() { return { type: '', frequency: { setValueAtTime: noop, value: 0 }, Q: { value: 0 }, connect: (n) => n }; }
  createBuffer(ch, len) { return { getChannelData: () => new Float32Array(len) }; }
  createBufferSource() { return { buffer: null, connect: (n) => n, start: noop }; }
  resume() { return Promise.resolve(); }
}
window.AudioContext = FakeAC;
window.speechSynthesis = { speak: noop, cancel: noop };
window.SpeechSynthesisUtterance = class { constructor(t) { this.text = t; } };

/* fake API: mirror of what the server returns */
const KEY = process.argv[2] || 'BT-TEST-KEY1';
const DEVICE = 'DEV-SMOKE';
const state = {
  appName: 'BUNNY TEAM', tagline: 'x', announcement: 'Test announcement 🐰', maintenance: false,
  serverTime: Date.now(), tf: { id: '1M', label: 'WinGo 1 Min', seconds: 60, emoji: '🕐' },
  timeframes: [
    { id: '30S', label: 'WinGo 30 Sec', short: '30S', emoji: '⚡', enabled: true },
    { id: '1M', label: 'WinGo 1 Min', short: '1M', emoji: '🕐', enabled: true },
    { id: '3M', label: 'WinGo 3 Min', short: '3M', emoji: '🕒', enabled: true },
    { id: '5M', label: 'WinGo 5 Min', short: '5M', emoji: '🕔', enabled: true }
  ],
  period: '20261105100011234', drawnPeriod: '20261105100011233', countdown: 42,
  feed: { mode: 'synthetic', health: 'SIMULATION', at: Date.now() },
  results: Array.from({ length: 8 }, (_, i) => ({
    period: '2026110510001' + (1233 - i), number: [3, 7, 1, 9, 0, 5, 2, 8][i], size: [3, 1, 0, 2].includes([3, 7, 1, 9, 0, 5, 2, 8][i]) ? 'SMALL' : 'BIG',
    colour: 'red', predSize: 'BIG', outcome: i === 0 ? 'WIN' : i === 1 ? 'LOSS' : i === 2 ? 'JACKPOT' : null, ts: Date.now() - i * 60000
  })),
  prediction: {
    period: '20261105100011234', size: 'BIG', numbers: [4, 9], favNum: 9, oppNum: 4, confidence: 87,
    patternName: 'BIG DRAGON ×4', patternDetail: 'continue', source: 'SIG', crossCheck: 'AGREE', matchCount: 3,
    matches: [{ name: 'BIG DRAGON ×4', size: 'BIG', conf: 97, pri: 95 }, { name: 'S-BB-S-BB LOOP', size: 'BIG', conf: 96, pri: 93 }],
    votes: { big: 9, small: 6, share: 60, size: 'BIG', list: Array.from({ length: 15 }, (_, i) => ({ name: 'Algo ' + i, size: i % 2 ? 'BIG' : 'SMALL', conf: 60 + i })) },
    level: { current: 1, multiplier: '1X', status: 'LEVEL 1 (1X)' }, lockedAt: Date.now(), outcome: null, qualified: true
  },
  stats: { wins: 12, losses: 5, jackpots: 2, total: 17, accuracy: 71, streak: 2, streakType: 'WIN' },
  features: { history: true, stats: true, patterns: true, consensus: true },
  sounds: { on: true, voice: true }
};

const json = (obj, status = 200) => Promise.resolve({
  ok: status < 400, status, json: () => Promise.resolve(obj)
});

window.fetch = (url, opts = {}) => {
  const u = String(url);
  if (u.includes('/api/auth/login')) {
    const body = JSON.parse(opts.body || '{}');
    if (body.key !== KEY) return json({ ok: false, code: 'INVALID', message: '❌ Invalid access key.' }, 401);
    return json({ ok: true, token: 'TOKEN', profile: { key: 'BT-TEST••Y1', plan: '30D' } });
  }
  if (u.includes('/api/state')) return json({ ok: true, state });
  if (u.includes('/api/history')) return json({ ok: true, items: state.results.filter((r) => r.outcome).map((r) => ({ ...r, predNumbers: '4,9', confidence: 87, pattern: 'BIG DRAGON' })), stats: state.stats });
  if (u.includes('/api/patterns')) return json({ ok: true, count: 2, patterns: [{ id: 'D-DRG6B', name: 'BIG DRAGON ×6+', tier: 'SIG', priority: 100 }, { id: 'C-ABAB', name: 'ABAB-PING', tier: 'CFM', priority: 68 }] });
  return json({ ok: false }, 404);
};

/* capture client errors */
const errors = [];
window.addEventListener('error', (e) => errors.push('window.onerror: ' + e.message));
const origErr = console.error;
console.error = (...a) => { errors.push('console.error: ' + a.join(' ')); };

/* load client */
const appSrc = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
window.eval(appSrc.replace(/^import .*$/gm, ''));

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const $ = (s) => window.document.querySelector(s);

await wait(300);
console.log('login screen visible:', !$('#loginScreen').hidden);

/* wrong key */
$('#keyInput').value = 'WRONG-KEY';
$('#loginBtn').click();
await wait(200);
console.log('invalid key msg     :', $('#loginStatus').textContent);

/* right key */
$('#keyInput').value = KEY;
$('#loginBtn').click();
await wait(1200);
console.log('app visible         :', !$('#app').hidden);
console.log('hero verdict        :', $('#predSize')?.textContent.trim());
console.log('rings/period        :', $('#ringTime')?.textContent, '|', $('.hero-period')?.textContent.trim().replace(/\s+/g, ' '));
console.log('confidence width    :', $('#confFill')?.style.width);
console.log('tf chips            :', window.document.querySelectorAll('.tf-chip').length);
console.log('live strip cards    :', window.document.querySelectorAll('.mini').length);

for (const p of ['history', 'stats', 'patterns', 'settings', 'home']) {
  window.document.querySelector(`.nav-btn[data-page="${p}"]`).click();
  await wait(260);
  const view = $('#view');
  console.log(`page ${p.padEnd(9)}     :`, view.children.length ? 'rendered ' + view.children.length + ' blocks' : 'EMPTY');
}

/* overlay celebration */
window.document.querySelector('.nav-btn[data-page="home"]').click();
await wait(150);

console.error = origErr;
console.log('\nJS errors:', errors.length ? errors : 'none ✅');
dom.window.close();
process.exit(errors.length ? 1 : 0);
